---
name: oic-architecture-expert
description: >-
  Enterprise architectural blueprint and implementation guide strictly tailored for Oracle Integration Cloud Gen 3 (OIC Gen 3).
  Use this skill whenever architecting, designing, building, refactoring, or optimizing OIC Gen 3 integrations,
  including Project-centric architectures, native Event Mesh (Pub/Sub), synchronous APIs, asynchronous workers,
  Stage File streaming, enterprise error handling, Private Endpoints, and CI/CD deployment channels.
---

# Oracle Integration Cloud (OIC Gen 3) Architecture & Best-Practices Blueprint

This skill provides an enterprise architectural standard and implementation guide designed **exclusively for Oracle Integration Cloud Gen 3 (OIC Gen 3)**.

---

## 1. The Gen 3 Paradigm Shift: Core Architectural Pillars

OIC Gen 3 deprecates the fragmented assets of earlier generations in favor of a unified, enterprise-grade architecture:

```
+-----------------------------------------------------------------------------------+
|                            OIC GEN 3 PROJECT                                      |
|                                                                                   |
|  +--------------------+  +--------------------+  +-----------------------------+  |
|  |    INTEGRATIONS    |  |    CONNECTIONS     |  |         EVENT MESH          |  |
|  | - Sync APIs        |  | - REST / SOAP      |  | - Native Gen 3 Events       |  |
|  | - Async Workers    |  | - ERP / HCM Cloud  |  | - Cross-Integration Pub/Sub |  |
|  | - Batch/Scheduled  |  | - DB / Salesforce  |  | - Decoupled Architecture    |  |
|  +--------------------+  +--------------------+  +-----------------------------+  |
|                                                                                   |
|  +--------------------+  +--------------------+  +-----------------------------+  |
|  |   JS LIBRARIES     |  |      LOOKUPS       |  |   CONFIGURABLE PROPERTIES   |  |
|  | - ES6+ Data Logic  |  | - Domain Value     |  | - Zero-Hardcoding           |  |
|  | - Complex RegEx    |  |   Mappings (DVM)   |  | - Environment-Agnostic      |  |
|  +--------------------+  +--------------------+  +-----------------------------+  |
|                                                                                   |
|  +-----------------------------------------------------------------------------+  |
|  |           DEPLOYMENT CHANNELS & PROFILES (Automated Lifecycle CI/CD)        |  |
|  +-----------------------------------------------------------------------------+  |
+-----------------------------------------------------------------------------------+
```

### Key Gen 3 Differentiators to Always Apply:
1. **Projects as the Unit of Isolation & Delivery**: All integrations, connections, lookups, libraries, and events must be encapsulated inside **Gen 3 Projects**. Never build loose, unassigned integrations.
2. **Native Event Mesh (Pub/Sub)**: Use Gen 3 Events to decouple integrations within and across projects without provisioning external message brokers like Kafka or OCI Streaming for standard enterprise workflows.
3. **Configurable Properties over Lookup Hacks**: Replace legacy DVM workarounds with native **Project and Integration Configurable Properties** for environment-specific thresholds, URLs, and toggles.
4. **JavaScript (ES6+) Libraries**: Offload heavy array manipulations, regex parsing, and cryptographic checks from the XSLT mapper into native Gen 3 JavaScript libraries.
5. **Private Endpoints (OCI Ingress/Egress)**: Direct private VCN peering eliminates the need for Connectivity Agents when targeting cloud databases, OCI compute, or peered cloud VPCs.

---

## 2. Gen 3 Architectural Decision Matrix

```
                                  [Inbound Trigger]
                                         |
               +-------------------------+-------------------------+
               |                                                   |
       [Real-Time / Low Latency]                             [High Volume / Slow Backend]
               |                                                   |
       Payload < 10MB?                                       Need Fire & Forget?
      /               \                                     /                   \
   [YES]              [NO]                               [YES]                  [NO]
     |                  |                                  |                      |
Synchronous REST API    Offload to OCI Object Storage /  Gen 3 Event Publish   Scheduled Orchestration
(SLA < 3s, Max 300s)    Stage File Action with Chunking  (Pub/Sub Worker)      (Batch FBDI, SFTP Chunking)
```

### Pattern Selection for Gen 3:

| Pattern | Latency SLA | Max Payload | Gen 3 Components Used | Best For |
| :--- | :--- | :--- | :--- | :--- |
| **Synchronous REST API** | < 3 sec (Max 300s) | < 10 MB | REST Trigger, Return Action, Scopes | Real-time queries, mobile/portal APIs, instant schema validation. |
| **Sync Facade + Event Worker** | Immediate (HTTP 202) | < 10 MB trigger | REST Trigger -> Gen 3 Event Publish -> Subscribe Worker | Offloading long-running transactions (> 5s) while giving instant client response. |
| **Native Gen 3 Event Pub/Sub** | Sub-second | Event schema (< 1MB) | Gen 3 Event Definition, Publish Action, Event Trigger | Decoupling domains (e.g. Order Placed -> Inventory, Billing, CRM). |
| **Scheduled Batch Streaming** | Scheduled Window | Up to 1 GB | Schedule Trigger, FTP Adapter, Stage File (Read in Segments) | SFTP bank files, high-volume CSV/XML feeds, payroll data. |
| **Oracle Fusion Cloud FBDI** | Minutes | Multi-GB (ZIP) | Stage File (ZIP/Unzip), ERP Adapter (`importBulkData`), Callback | Mass data loads into Oracle Fusion Cloud (ERP, HCM, SCM). |

---

## 3. Core Implementation Guardrails in Gen 3

### A. Payload & Memory Protection
1. **The 10 MB Platform Ceiling**: REST and SOAP request/response bodies have a strict 10 MB limit.
2. **Stage File Streaming**:
   - **Mandatory Chunking**: Always use **"Read File in Segments"** (100–500 records per chunk) for files > 10 MB or files of variable size.
   - **Forbid "Read Entire File"**: Loading unbounded files directly into memory causes JVM garbage collection pauses and OOM faults.
   - **Mandatory Local Disk Cleanup**: Invoke **`Delete File`** on temporary Stage File artifacts in both the main flow and inside Fault Handlers.
3. **Variable Scoping**:
   - Prefer **Scope-level variables** over Global variables to prevent state leakage and optimize garbage collection.
   - Avoid modifying global variables inside `For-Each` loops.

### B. Parallel Processing in Gen 3
- Leverage the native **Parallel Action** in Gen 3 when calling independent external services (e.g., simultaneously querying Customer Profile, Credit Score, and Loyalty Points).
- Join results before mapping to the final response.

---

## 4. Enterprise Fault Handling & Resilience in Gen 3

```
+-----------------------------------------------------------------------------------+
| GLOBAL FAULT HANDLER (Project / Integration Level)                                |
|  - Catches all unhandled faults                                                   |
|  - Calls Common Error Service via Gen 3 Event or Async REST                       |
|  - Formats RFC 7807 Problem Details response for synchronous callers              |
+-----------------------------------------------------------------------------------+
       ^
       | (escalates unhandled faults)
+-----------------------------------------------------------------------------------+
| SCOPE FAULT HANDLERS (Local Component Level)                                      |
|  - Catches APIInvocationFault, TimeoutFault                                        |
|  - Executes Exponential Backoff for transient faults (HTTP 429, 502, 503, 504)    |
|  - Swallows benign errors or supplies fallback responses                           |
+-----------------------------------------------------------------------------------+
```

### Key Fault Handling Rules:
1. **Classify Transient vs. Non-Transient Faults**:
   - **Transient** (Network glitches, HTTP 429, 502, 503, 504): Implement exponential backoff retry loops.
   - **Non-Transient** (HTTP 400, 401, 403, 404, 422, schema validation): Fail fast without blind retries; send to Dead Letter Queue (DLQ).
2. **RFC 7807 Standard Error Format**: All synchronous REST triggers in Gen 3 must return RFC 7807 Problem Details (`type`, `title`, `status`, `detail`, `instanceId`, `correlationId`).

---

## 5. Security & Connectivity in Gen 3

### A. Authentication & Credentials
- Inbound REST: Enforce **OAuth 2.0 (Client Credentials Grant)** with Identity Domains (IAM).
- Outbound: Secure credentials directly in Connection resources or OCI Vault.
- Never log passwords, tokens, or PII into the Activity Stream.

### B. Network Connectivity (Private Endpoints vs Connectivity Agent)
- **OCI Private Endpoints**: Use native Gen 3 Private Endpoints to connect directly to Autonomous Database (ATP), Oracle DB Systems, and private OCI subnets without installing an agent.
- **Connectivity Agent (On-Premises)**: Deploy agent groups in High Availability (HA) dual-node clusters with JVM tuned to `-Xms2048m -Xmx4096m`.

---

## 6. Deep-Dive Gen 3 Reference Manuals

Consult the dedicated reference manuals in the [`references/`](./references/) folder:
- [Gen 3 Architectural Patterns & Recipe Catalog](./references/architectural-patterns.md): Complete blueprints for Sync, Async, Event Mesh, Stage File, and FBDI.
- [Gen 3 Enterprise Error Handling & Resilience](./references/error-handling-framework.md): 3-tier fault architecture, backoff loops, DLQ patterns, and RFC 7807 specs.
- [Gen 3 Performance & Payload Sizing Limits](./references/performance-and-payload-tuning.md): Hard thresholds, memory limits, JavaScript library tuning, and Private Endpoints.
- [Gen 3 Naming, Governance & Project Lifecycle](./references/naming-and-governance-standards.md): Project packaging (`.par`), Deployment Channels, Configurable Properties, and CI/CD.
- [Gen 3 Production Readiness Checklist](./references/production-readiness-checklist.md): 25-point verification checklist tailored for OIC Gen 3 go-live.
