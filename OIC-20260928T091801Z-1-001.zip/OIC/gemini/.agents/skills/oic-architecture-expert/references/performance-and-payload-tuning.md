# OIC Gen 3 Performance & Payload Sizing Limits

Achieving sub-second response times and rock-solid stability in Oracle Integration Cloud Gen 3 (OIC Gen 3) requires understanding platform resource boundaries, memory mechanics, and tuning levers.

---

## 1. OIC Gen 3 Platform Limits Reference Matrix

| Feature / Metric | Gen 3 Limit | Architectural Impact / Recommendation |
| :--- | :--- | :--- |
| **Synchronous Invocation Timeout** | 300 seconds (5 min) | **Hard limit**. If a downstream system takes > 3s under load, switch to Sync Facade + Event Worker. |
| **Inline Message Payload (Trigger/Invoke)** | 10 MB | **Hard limit**. Payloads > 10 MB fail immediately. Use Stage File streaming, OCI Object Storage, or SFTP. |
| **Stage File Processing Limit** | 1 GB | Supported on local scratch disk. **Must use "Read File in Segments"** for files > 10 MB. |
| **Direct FTP/SFTP File Streaming** | 100 MB | Direct streaming between endpoints without staging. |
| **Local Temporary Disk Space** | Dynamic per pod | Shared across integrations. Always execute **Delete File** in Stage File actions. |
| **Activity Stream Retention** | 32 days | Production audit logs expire after 32 days. Export to OCI Logging or SIEM for long-term audit compliance. |
| **Max Tracking Business Identifiers** | 3 (1 Primary, 2 Secondary) | Always populate all 3 for fast query indexing in the Gen 3 Monitoring console. |
| **Custom JavaScript Execution Timeout** | 5 seconds | JavaScript functions must be lightweight; avoid infinite loops or blocking operations. |

---

## 2. Memory Footprint & Garbage Collection (GC) Optimization

Inside OIC Gen 3, XML and JSON documents processed by the visual mapper are parsed into an in-memory Document Object Model (DOM) tree.

### The Memory Multiplier Effect:
A raw 10 MB JSON or XML file can expand into **50 MB to 100 MB** of active JVM heap memory when parsed with metadata, namespace nodes, and tracking context.

### Gen 3 Memory Rules:
1. **Always Use Stage File Chunking**:
   - For files > 10 MB or files of variable size, use **"Read File in Segments"** (100–500 records per segment).
   - This ensures only a few kilobytes of DOM are resident in memory at any millisecond.
2. **Prefer Scope Variables over Global Variables**:
   - Gen 3 introduces **Scope-level variables**. Unlike global variables (which persist throughout the entire integration instance), Scope variables are immediately eligible for Garbage Collection once the scope completes.
3. **Avoid Accumulating State in Loops**:
   - Never build large strings or JSON arrays via `concat()` or variable append inside a loop.
   - Use **Stage File: Write File** with "Append to existing file" enabled to write output directly to disk.

---

## 3. High-Performance Data Mapping & XSLT Tuning

The OIC Gen 3 mapper compiles into standard XSLT stylesheets executed by high-performance transformation engines.

### Anti-Patterns to Eliminate:
* **Nested `For-Each` Loops ($O(N \times M)$ Complexity)**:
  - Traversing 1,000 parent lines each searching 1,000 child lines without keys requires **1,000,000 evaluations**.
  - **Remedy**: Use XSLT Keys (`<xsl:key>`) in the code view for $O(1)$ index lookups:
    ```xml
    <xsl:key name="kLinesByHeader" match="InvoiceLine" use="HeaderID"/>
    <!-- Lookup using key() -->
    <xsl:for-each select="key('kLinesByHeader', current()/HeaderID)">
        ...
    </xsl:for-each>
    ```
* **Redundant Absolute XPath Queries**:
  - Repeatedly querying `/n1:Root/n1:Order/n1:Customer/n1:Address` forces the engine to traverse from the root each time.
  - Store repetitive node references in local `<xsl:variable>` tags.

---

## 4. Offloading Heavy Compute to Gen 3 JavaScript Libraries

OIC Gen 3 allows creating custom JavaScript (ES6+) libraries directly inside Projects. Use JavaScript rather than complex XSLT hacks for:
- Regular expression parsing and string tokenization
- Date math, working day calculations, and timezone transformations
- Hashing (SHA-256), checksum validation, and Base64 encoding
- Array sorting, filtering, and deduplication

### Example: High-Speed Deduplication Library in Gen 3
```javascript
/**
 * Deduplicates an array of objects based on a specific key
 * @param {Array} records - Array of records from source
 * @param {string} keyField - Field name to deduplicate on
 * @returns {Array} Deduplicated array
 */
function deduplicateRecords(records, keyField) {
    if (!Array.isArray(records)) return [];
    const seen = new Set();
    return records.filter(item => {
        const val = item[keyField];
        if (seen.has(val)) {
            return false;
        }
        seen.add(val);
        return true;
    });
}
```

---

## 5. Connectivity Architecture: OCI Private Endpoints vs. Connectivity Agent

OIC Gen 3 introduces **native OCI Private Endpoints**, simplifying network architecture:

```
+-----------------------------------------------------------------------------------+
| TARGET INFRASTRUCTURE               | CONNECTIVITY MECHANISM                      |
+-------------------------------------+---------------------------------------------+
| OCI Autonomous Database (ATP / ADW) | Native Gen 3 Private Endpoint (No Agent)    |
| Oracle Cloud DB System / Exadata CS | Native Gen 3 Private Endpoint (No Agent)    |
| Private VMs in OCI VCN              | Native Gen 3 Private Endpoint (No Agent)    |
| On-Premises Oracle EBS / SAP / DB   | Connectivity Agent (HA Dual-Node Cluster)   |
| Third-Party Cloud Private VPC       | FastConnect / VPN + Private Endpoint        |
+-----------------------------------------------------------------------------------+
```

### Connectivity Agent Tuning (for On-Premises):
When the Connectivity Agent is required for on-premise systems:
1. **JVM Heap Sizing**: Edit `bin/Agent_Settings.sh` or `.bat`:
   ```bash
   USER_MEM_ARGS="-Xms2048m -Xmx4096m -XX:+UseG1GC -XX:+ExplicitGCInvokesConcurrent"
   ```
2. **HA Agent Groups**: Deploy at least 2 agent instances across different physical servers for fault tolerance.
3. **Database Adapter**: Always enforce row limits (`ROWNUM <= 2000` or `OFFSET / FETCH NEXT`) and prefer stored procedures over open table queries.
