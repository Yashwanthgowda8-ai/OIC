# OIC Gen 3 Naming Conventions, Governance & Lifecycle Management

In Oracle Integration Cloud Gen 3 (OIC Gen 3), governance and lifecycle management revolve around **Projects**, **Deployment Channels**, and **Configurable Properties**.

---

## 1. Gen 3 Naming Standards

### A. Projects (The Unit of Packaging & Governance)
Format: `[BusinessDomain]_Project` or `[Capability]_Project`

Examples:
- `OrderToCash_Project`
- `ProcureToPay_Project`
- `HumanCapitalManagement_Project`
- `CommonServices_Project`

### B. Integrations (Inside Projects)
Format: `[SOURCE]_[TARGET]_[BUSINESS_ENTITY]_[ACTION]_[PATTERN]`

Examples:
- `SFDC_ERP_ORDER_SYNC_SYNC` (Real-time synchronous REST API)
- `COUPA_ERP_INVOICE_IMPORT_BATCH` (Scheduled batch file import)
- `ERP_WMS_SHIPMENT_EVENT_ASYNC` (Event-driven asynchronous subscriber)
- `PORTAL_OIC_CUSTOMER_LOOKUP_SYNC` (Experience layer API)

### C. Connections
Format: `[SYSTEM]_[PROTOCOL/ADAPTER]_[ENV/ROLE]`

Examples:
- `ORACLE_ERP_CLOUD_DEV` / `ORACLE_ERP_CLOUD_PROD`
- `SALESFORCE_REST_UAT`
- `ATP_DB_PRIVATE_PROD`
- `CORP_BANK_SFTP_DEV`

> **Rule**: Keep Connection names consistent across environments (DEV, TEST, PROD) to ensure seamless automated deployments.

### D. Gen 3 Events
Format: `[BusinessEntity]_[ActionState]_Event`

Examples:
- `Order_Submitted_Event`
- `Invoice_Approved_Event`
- `Employee_Terminated_Event`
- `System_Fault_Occurred_Event`

### E. JavaScript Libraries
Format: `[Domain]_[UtilityName]_Lib`

Examples:
- `Common_DataFormatter_Lib`
- `Security_TokenHelper_Lib`
- `Financial_DateCalculator_Lib`

---

## 2. Configuration Parameterization in Gen 3 (Zero Hardcoding)

Gen 3 replaces legacy lookup workarounds with **native Configurable Properties**.

```
+-----------------------------------------------------------------------------------+
|                           PROJECT CONFIGURABLE PROPERTIES                         |
|  - Shared across all integrations within the Project                              |
|  - Examples:                                                                      |
|    * notifications.ops.email = "prod-integrations@company.com"                    |
|    * sftp.inbound.directory  = "/production/inbound/orders"                       |
|    * batch.chunk.size        = 250                                                |
+-----------------------------------------------------------------------------------+
                                         |
                                         v
+-----------------------------------------------------------------------------------+
|                        INTEGRATION CONFIGURABLE PROPERTIES                        |
|  - Specific to an individual integration flow                                     |
|  - Examples:                                                                      |
|    * api.timeout.seconds     = 15                                                 |
|    * retry.max.attempts      = 3                                                  |
+-----------------------------------------------------------------------------------+
```

### Governance Rules:
1. **Zero Hardcoding**: Hardcoding hostnames, directories, email addresses, or API keys in mappers or assignments is strictly prohibited.
2. **Environment Overrides**: Configurable Properties can be overridden per environment (DEV, TEST, PROD) directly in the OIC Console or via CI/CD pipelines without altering code.

---

## 3. Gen 3 Deployment Channels & CI/CD Lifecycle

OIC Gen 3 introduces **Deployment Channels** and **Deployment Profiles** to manage environments and releases natively:

```
+------------------+         Git Commit / PR         +------------------+
|   DEVELOPMENT    | ------------------------------> |   VERSION CTRL   |
|   OIC Instance   |   Export Project Archive (.par) |   (GitHub / OCI) |
+------------------+                                 +------------------+
                                                              |
                                                    Automated Pipeline
                                                    (OIC REST API / CLI)
                                                              |
                                                              v
+------------------+         Promote / Deploy        +------------------+
|    PRODUCTION    | <------------------------------ |   TEST / STAGE   |
|   OIC Instance   |   Apply PROD Deployment Profile |   OIC Instance   |
+------------------+                                 +------------------+
```

### Gen 3 Release Lifecycle Rules:
1. **Export as Project Archive (`.par`)**: Always export and version control the entire Project package (`.par`), which bundles all integrations, connections, events, lookups, and JS libraries together.
2. **Deployment Profiles**: Use Gen 3 Deployment Profiles to predefine connection mapping and property values per target environment.
3. **Audit Level Standards**:
   - **DEV / TEST**: Set to `Audit Level: Debug` (Trace with Payload) during active feature development.
   - **PRODUCTION**: Set to `Audit Level: Normal` or `Minimal`. Never activate in Production with `Debug` unless actively troubleshooting a live P1 incident.

---

## 4. Role-Based Access Control (RBAC) in Gen 3

Manage access through OCI Identity and Access Management (IAM) Identity Domains:

| Role Name | Permissions | Intended Users |
| :--- | :--- | :--- |
| **`ServiceAdministrator`** | Full instance administration: certificates, network ingress/egress, user policies, and deletion. | Enterprise Cloud Architects (max 2-3 users). |
| **`ServiceDeveloper`** | Create, edit, and test integrations, connections, lookups, and JS libraries within assigned Projects. | Integration Developers. |
| **`ServiceDeployer`** | Import, activate, deactivate, and schedule projects and integrations. Cannot modify source code. | Release / DevOps Engineers. |
| **`ServiceMonitor`** | Read-only access to Observability dashboards, runtime metrics, activity streams, and error queues. | Production Support & Operations. |
