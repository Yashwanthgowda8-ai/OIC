# OIC Gen 3 Enterprise Error Handling & Resilience Framework

This document outlines the standard error classification, fault-handling tiers, retry strategies, and observability patterns designed specifically for **Oracle Integration Cloud Gen 3 (OIC Gen 3)**.

---

## 1. The 3-Tier Fault Architecture in Gen 3

```
+-----------------------------------------------------------------------------------+
| TIER 3: COMMON ERROR HANDLING SERVICE (Project-Level Centralized Integration)     |
|  - Subscribed to "SystemFaultOccurredEvent" or invoked via Async REST             |
|  - Centralized audit logging to ATP Database / OCI Logging / Splunk               |
|  - Dispatches notifications (Email, Slack, MS Teams, PagerDuty)                   |
|  - Auto-creates incident tickets in ServiceNow / Jira                             |
+-----------------------------------------------------------------------------------+
                                         ^
                                         | (Publishes Gen 3 Event or Calls Async REST)
+-----------------------------------------------------------------------------------+
| TIER 2: INTEGRATION GLOBAL FAULT HANDLER (Integration-Level Catch-All)            |
|  - Traps unhandled faults escaping scopes                                         |
|  - Formats canonical RFC 7807 response for synchronous REST triggers              |
|  - Executes compensation / cleanup (deletes temporary Stage files)                |
|  - Dispatches error payload to Tier 3 Common Error Service                        |
+-----------------------------------------------------------------------------------+
                                         ^
                                         | (Escalates unhandled faults)
+-----------------------------------------------------------------------------------+
| TIER 1: SCOPE-LEVEL FAULT HANDLERS (Localized Component Resilience)               |
|  - Wraps risky invokes (External REST, SOAP, DB, ERP, FTP)                        |
|  - Catches APIInvocationFault, TimeoutFault                                        |
|  - Executes localized retry with exponential backoff for transient HTTP errors    |
|  - Swallows benign errors or supplies fallback default values                     |
+-----------------------------------------------------------------------------------+
```

---

## 2. Fault Classification & Decision Tree

Every fault in Gen 3 must be categorized immediately before taking action:

```
                          [Fault Detected]
                                 |
                 Is error transient or non-transient?
                /                                    \
       [Transient Error]                     [Non-Transient Error]
 (HTTP 429 Rate Limit, 502 Bad Gateway,    (HTTP 400 Bad Request, 401/403 Auth,
  HTTP 503 Unavailable, 504 Timeout,        HTTP 404 Not Found, 422 Unprocessable,
  Connection Reset, Socket Timeout)         Schema Validation, Corrupt Data)
               |                                     |
   Execute Exponential Backoff             Do NOT retry blindly!
   (Max 3 to 5 retries)                    Capture full payload & fault context
         /            \                              |
    [Success]     [Exhausted]              Send to Dead Letter Queue (DLQ)
        |              |                             |
    Continue        Escalate to             Format RFC 7807 Response /
    Normal Flow     Global Fault            Notify Admin for manual fix
```

---

## 3. Gen 3 Built-In Fault Variables

Inside any Fault Handler (Scope or Global), OIC Gen 3 automatically populates the `$fault` object:

| Variable | Description | Example Value |
| :--- | :--- | :--- |
| **`$fault.type`** | Fully qualified fault QName | `APIInvocationFault`, `TimeoutFault`, `DataFormatException` |
| **`$fault.code`** | HTTP status code or adapter error code | `504`, `ORA-00001`, `INVALID_CREDENTIALS` |
| **`$fault.reason`** | Short human-readable summary | `Gateway Timeout`, `Unique constraint violated` |
| **`$fault.details`** | Raw payload or stack trace from target system | JSON error response body from external REST API or SOAP Fault XML |

---

## 4. Exponential Backoff Retry Recipe in Gen 3

To handle transient glitches and API rate limits (HTTP 429), configure an exponential backoff loop inside a Scope using Scope variables:

### Variables to Initialize (Scope Variables):
- `v_retryCount` (integer) = `0`
- `v_maxRetries` (integer) = `3`
- `v_waitDuration` (integer, seconds) = `10`
- `v_callSuccessful` (boolean) = `false`

### Orchestration Logic:
```
While (v_callSuccessful = false AND v_retryCount < v_maxRetries)
  |
  +-- [Scope: Invoke External Service]
        |
        +-- [Invoke Action: Call Target API]
        |     |
        |     +-- [Assign: v_callSuccessful = true]
        |
        +-- [Fault Handler: Catch APIInvocationFault]
              |
              +-- [Assign: v_retryCount = v_retryCount + 1]
              +-- [If v_retryCount < v_maxRetries]:
              |     |
              |     +-- [Wait Action: Duration = v_waitDuration seconds]
              |     +-- [Assign: v_waitDuration = v_waitDuration * 2] (10s -> 20s -> 40s)
              |
              +-- [Else (Retries Exhausted)]:
                    |
                    +-- [Rethrow Fault or Route to DLQ]
```

---

## 5. Dead Letter Queue (DLQ) & Error Parking in Gen 3

For asynchronous, event-driven, or scheduled batch integrations, failed transactions must never be lost.

### Architecture:
1. **Error Parking Table (Autonomous Database ATP / OCI Object Storage)**:
   Store failed transaction details:
   - `TRANSACTION_ID` (VARCHAR2(100)): Business key (e.g., OrderNumber)
   - `PROJECT_NAME` (VARCHAR2(100)): Gen 3 Project Name
   - `INTEGRATION_NAME` (VARCHAR2(100)): Integration Identifier
   - `PAYLOAD` (CLOB): Original unmodified request body
   - `ERROR_CODE` (VARCHAR2(50)): `$fault.code`
   - `ERROR_MESSAGE` (VARCHAR2(4000)): `$fault.reason`
   - `STATUS` (VARCHAR2(20)): `PENDING_RETRY`, `MANUAL_REVIEW`, `RESOLVED`
   - `CREATED_DATE` (TIMESTAMP): Time of failure
   - `RETRY_COUNT` (NUMBER): Number of replay attempts
2. **Re-submission Service**:
   Create a scheduled integration in the project (`DLQ_RETRY_PROCESSOR`) that polls `STATUS = 'PENDING_RETRY'`, publishes the payload back to the Gen 3 Event bus or target integration, and marks status as `RESOLVED`.

---

## 6. RFC 7807 Standard Error Response for Gen 3 REST Triggers

All synchronous REST triggers in OIC Gen 3 must format error responses according to the **RFC 7807 (Problem Details for HTTP APIs)** specification:

```json
{
  "type": "https://integration.company.com/errors/RESOURCE-NOT-FOUND",
  "title": "Customer Not Found in Oracle ERP",
  "status": 404,
  "detail": "Customer with AccountNumber 'CUST-99212' does not exist in Fusion Financials.",
  "instance": "/ic/api/integration/v1/flows/rest/CUSTOMER_SYNC_SYNC/1.0/instances/2940192",
  "code": "ERP-CUST-404",
  "correlationId": "CORR-8829104-ABCD",
  "timestamp": "2026-09-27T00:55:00Z"
}
```

### Response Mapping Rules in Gen 3:
- In the REST Trigger configuration, define the fault response schema matching RFC 7807.
- In the Global Fault Handler, map `$fault.code` to the HTTP status code, `$fault.reason` to `title`, and `$fault.details` to `detail`.
- Ensure the `Content-Type` header is set to `application/problem+json` or `application/json`.
