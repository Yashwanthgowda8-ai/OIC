# OIC Gen 3 Architectural Patterns & Recipe Catalog

This guide provides architectural blueprints, component wiring, and step-by-step implementation recipes designed exclusively for **Oracle Integration Cloud Gen 3 (OIC Gen 3)**.

---

## Pattern 1: Synchronous REST API (Real-Time Low-Latency Service)

### When to Use
- Interactive user interfaces (Oracle Visual Builder / VBCS, Mobile Apps, Portals).
- Real-time lookups (e.g., Inventory availability, Price calculation, Address verification).
- Strictly when processing completes in **< 3 seconds** (hard platform timeout is 300s).

### Gen 3 Architecture Diagram
```
[Client App] ---> (HTTPS REST POST/GET) ---> [Gen 3 REST Trigger]
                                                      |
                                            [Validation Scope]
                                                      |
                                         [Target API / Adapter Call]
                                                      |
[Client App] <--- (HTTP 200 OK + Body) <--- [Mapper to Response]
```

### Gen 3 Implementation Guardrails:
1. **Latency SLA**: Design for sub-3-second execution. If downstream services exceed 5 seconds, switch to **Pattern 2 (Sync Facade + Event Worker)**.
2. **Payload Limit**: Enforce < 5 MB payload size (hard platform limit is 10 MB). For large query responses, implement pagination with `limit` and `offset` query parameters.
3. **Structured Error Handling**: Wrap external calls in a Scope. If the downstream service fails, catch the fault and return an RFC 7807 Problem Details response (`404`, `422`, `502`) rather than an unhandled 500 error.

---

## Pattern 2: Sync Facade + Gen 3 Event Worker (Offloading Pattern)

### When to Use
- Client needs an immediate response, but business processing takes between 10 seconds and several hours (e.g., complex order creation, ERP invoice posting, bulk asset registration).

### Gen 3 Architecture Diagram
```
Step 1: Immediate Handshake (Sync Facade Integration)
[Client] ---> (POST /orders) ---> [Gen 3 REST Trigger]
                                         |
                                  [Generate Tracking ID]
                                         |
                                  [Action: Publish Event (e.g. OrderSubmitted)]
                                         |
[Client] <--- (HTTP 202 Accepted + TrackingURL) ---+

Step 2: Background Orchestration (Event-Driven Worker Integration)
[Gen 3 Event Trigger: OrderSubmitted]
       |
  [Validate Payload] ---> [Enrich Data] ---> [Post to Fusion ERP Cloud]
                                                     |
                                            [Update Status Table]
```

### Implementation Steps in Gen 3:
1. **Define the Event in Project**:
   - In the Gen 3 Project, create a new **Event** definition (e.g., `OrderSubmittedEvent`) with a JSON schema representing the order payload and tracking metadata.
2. **Sync Facade Integration**:
   - Expose a REST Trigger with `POST /orders`.
   - Validate payload schema.
   - Use `ora:generateGUID()` to generate a Correlation ID.
   - Add the **Publish** action to publish `OrderSubmittedEvent`.
   - Return **HTTP 202 Accepted** immediately with:
     ```json
     {
       "status": "ACCEPTED",
       "trackingId": "OIC-ORD-2026-9921",
       "message": "Order accepted for asynchronous processing.",
       "statusUrl": "https://<oic-host>/ic/api/integration/v1/flows/rest/GET_ORDER_STATUS/1.0/status/OIC-ORD-2026-9921"
     }
     ```
3. **Event Worker Integration**:
   - Create an integration with an **Event Trigger** subscribed to `OrderSubmittedEvent`.
   - Handles the long-running ERP / CRM orchestration asynchronously.

---

## Pattern 3: Native Gen 3 Event Mesh (Pub/Sub Decoupling)

### When to Use
- Decoupling multiple consuming systems from a single business event.
- For example, when an "InvoiceApproved" event occurs, three independent integrations need to run:
  1. Post to General Ledger
  2. Send Vendor Notification
  3. Archive to Document Management System

### Architecture Blueprint
```
                              [Publisher Integration]
                                         |
                       [Action: Publish "InvoiceApprovedEvent"]
                                         |
                    ===========================================
                          OIC GEN 3 PROJECT EVENT BUS
                    ===========================================
                         /               |               \
                        /                |                \
    [Subscriber 1: GL Sync]  [Subscriber 2: Vendor Email]  [Subscriber 3: Archive]
```

### Gen 3 Advantages:
- **No External Broker Required**: No need to provision OCI Streaming or Apache Kafka for internal OIC workflow decoupling.
- **Independent Lifecycles**: Subscribers can be activated, deactivated, or updated independently without impacting the publisher.
- **Guaranteed At-Least-Once Delivery**: The Gen 3 Event runtime ensures reliable message delivery to all registered subscribers.

---

## Pattern 4: High-Volume File / Batch Streaming (Stage File Chunking)

### When to Use
- Ingesting large files (CSV, XML, Fixed-Width) from SFTP or external sources ranging from 10 MB up to 1 GB (or 100,000+ records).

### The Golden Rule of Stage File in Gen 3:
> **Never use "Read Entire File" on arbitrary or external files.** Always use **"Read File in Segments"** to stream data in manageable chunks.

### Gen 3 Architecture Blueprint
```
[Schedule Trigger]
       |
[FTP Adapter: Download File to OIC Scratch Storage]
       |
[Stage File Action: Read File in Segments] (Chunk size: 100 to 500 records)
       |
[For-Each Segment / Chunk]
       |---> [Mapper: Transform Chunk to Target Batch Format]
       |---> [Target Adapter: Bulk Insert / Batch REST Call]
       |---> [Track Processed Records Count]
       +--- (Next Segment)
       |
[Stage File: Delete Temporary File] (MANDATORY: Protects local disk)
       |
[Send Email / Notification Summary]
```

### Key Configuration Levers:
- **Segment Size**: Configure between **100 and 500 records**. Larger segments increase memory pressure; smaller segments cause excessive HTTP overhead.
- **File Deletion**: Always invoke **`Delete File`** in both the happy path and inside the Global Fault Handler to prevent exhausting the 50 GB tenant scratch storage.

---

## Pattern 5: Oracle Fusion Cloud FBDI (File-Based Data Import)

### When to Use
- High-volume data loading into Oracle Fusion Cloud (ERP, HCM, SCM):
  - GL Daily Rates & Journal Entries
  - AP Invoices & AR Transactions
  - Purchase Orders & Item Masters
  - HCM Worker Data (HDL)

### Gen 3 Orchestration Recipe
```
[Inbound Data Source (SFTP / Database / Object Storage)]
                           |
                  [Stage File: Write CSV]
                           |
            [Stage File: Zip CSV + Manifest File]
                           |
        [Oracle ERP Cloud Adapter: "Import Bulk Data"]
                           |
          +----------------+----------------+
          |                                 |
[Option A: Event Callback]         [Option B: ESS Job Polling]
Fusion raises Business Event       OIC polls ESS Job status
when ESS Job finishes              using While loop + Wait action
          |                                 |
          +----------------+----------------+
                           |
          [Download ERP Execution Logs & Bad Records]
                           |
          [Parse Rejections & Dispatch Business Alert]
```

### Gen 3 Best Practices for FBDI:
1. **Native ERP Cloud Adapter**: Use the native Oracle ERP Cloud Adapter (`importBulkData` operation) which automatically handles UCM upload, ESS Job submission, and security tokens.
2. **Callback over Polling**: For jobs taking > 10 minutes, use the ERP Business Event trigger callback to release OIC worker threads. For short jobs (< 5 minutes), use a `While` loop with a `Wait` action (30s intervals, max 20 iterations).
3. **Execution Log Inspection**: An ESS job returning `SUCCEEDED` only confirms the import process executed; individual rows may have failed validation in the interface tables. Always inspect the execution log ZIP for rejected records.

---

## Pattern 6: Parallel Processing in Gen 3

### When to Use
- Orchestrations that must query multiple independent downstream systems simultaneously to reduce total execution time.

### Gen 3 Parallel Action Blueprint
```
                         [Inbound Customer Request]
                                     |
                          [Action: Parallel Branch]
                         /           |            \
                        /            |             \
              [Branch 1]         [Branch 2]         [Branch 3]
              Invoke CRM      Invoke ERP Billing   Invoke Loyalty
             (Customer Profile) (Outstanding Bal)  (Rewards Points)
                        \            |             /
                         \           |            /
                          [Join & Merge In Mapper]
                                     |
                         [Return Combined Response]
```

### Best Practices:
- Only branch operations that have **zero data dependencies** on one another.
- Ensure all branches wrap calls in Scopes with localized fault handling so one failing service does not unexpectedly kill the other branches.
