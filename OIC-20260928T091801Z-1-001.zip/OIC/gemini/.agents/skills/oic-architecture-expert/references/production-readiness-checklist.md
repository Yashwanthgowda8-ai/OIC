# OIC Gen 3 Production Readiness Checklist (25-Point Verification)

Before promoting any integration or project package into the Production environment on **Oracle Integration Cloud Gen 3 (OIC Gen 3)**, complete this 25-point architectural verification.

---

## 1. Project Architecture & Design

- [ ] **1. Encapsulated in a Gen 3 Project**: The integration belongs to a defined Gen 3 Project (e.g., `OrderToCash_Project`). No unassigned or loose integrations exist.
- [ ] **2. Synchronous Latency SLA (< 3s)**: Real-time synchronous APIs complete execution in under 3 seconds under normal load (platform ceiling is 300s). Workflows with long or variable latency use the Sync Facade + Event Worker pattern.
- [ ] **3. Event Mesh Decoupling**: Asynchronous fan-out workflows leverage native Gen 3 Events (`Publish` / `Subscribe`) within or across Projects rather than point-to-point coupling.
- [ ] **4. Zero Hardcoding**: No environment URLs, directories, server names, credentials, port numbers, or developer emails are hardcoded in assignments, mappers, or JavaScript libraries.
- [ ] **5. Native Configurable Properties**: All environment-dependent parameters are defined as Project or Integration Configurable Properties, ready for deployment profile overrides.

---

## 2. Performance & Memory Management

- [ ] **6. 10 MB Payload Guardrail**: Inbound and outbound inline payloads strictly remain below the 10 MB platform ceiling. Larger files use Stage File chunking or OCI Object Storage.
- [ ] **7. Stage File Segment Chunking**: Any file reading operation on files > 10 MB or files of variable size uses **"Read File in Segments"** (100–500 record chunks). "Read Entire File" is strictly prohibited for unbounded files.
- [ ] **8. Scratch Disk Cleanup**: Every Stage File action has a corresponding `Delete File` invocation executed in both happy path and fault handlers to protect local disk space.
- [ ] **9. Variable Scoping**: Scope-level variables are used in place of global variables wherever possible to enable immediate Garbage Collection.
- [ ] **10. Mapper & XSLT Efficiency**: Deeply nested `For-Each` loops are eliminated or optimized using `<xsl:key>` lookups. Complex string/date transformations are offloaded to Gen 3 JavaScript libraries.

---

## 3. Error Handling & Resilience

- [ ] **11. Scope-Level Fault Handlers**: Risky invocations (REST, SOAP, ERP, DB, FTP) are wrapped in Scopes with dedicated handlers for `APIInvocationFault` and `TimeoutFault`.
- [ ] **12. Global Fault Handler Implemented**: The Global Fault Handler is never blank; it logs the fault context, executes cleanup (deletes temporary files), dispatches alerts, and formats a canonical response.
- [ ] **13. RFC 7807 Error Formatting**: Synchronous REST triggers return standardized problem details (`type`, `title`, `status`, `detail`, `instanceId`, `correlationId`).
- [ ] **14. Exponential Backoff on Transient Errors**: Retry loops with exponential backoff are configured for transient faults (HTTP 429, 502, 503, 504). Non-transient errors fail fast without blind retries.
- [ ] **15. Dead Letter Queue (DLQ) / Error Parking**: Failed transactions in asynchronous or scheduled batch flows are captured in an Autonomous Database (ATP) table or queue for auditable re-submission.

---

## 4. Security & Network Connectivity

- [ ] **16. Inbound OAuth 2.0**: Inbound REST triggers enforce OAuth 2.0 (Client Credentials Grant) with OCI Identity Domains. Basic Authentication is disabled.
- [ ] **17. Field-Level Data Masking**: Sensitive fields (PII, SSN, Credit Card numbers, passwords, salary data) have field masking enabled to prevent display in the tracking UI.
- [ ] **18. Credential Storage**: All external secrets, passwords, and client secrets are stored in Connection definitions or OCI Vault—never logged in Activity Streams.
- [ ] **19. Native OCI Private Endpoints**: Integrations connecting to OCI Autonomous Database (ATP) or private VCN resources use native Gen 3 Private Endpoints rather than Connectivity Agents.
- [ ] **20. Connectivity Agent HA Sizing**: If connecting to on-premises systems, Connectivity Agents are configured in an HA dual-node group with JVM memory set to `-Xms2048m -Xmx4096m`.

---

## 5. Observability & Operations

- [ ] **21. Business Tracking Identifiers Configured**: The Primary Business Identifier is assigned to a unique business key (`OrderNumber`, `InvoiceNumber`, `EmployeeID`). Up to 2 secondary identifiers are populated.
- [ ] **22. Audit Level Set to Normal/Minimal**: The integration is activated with `Audit Level: Normal` or `Minimal`. `Audit Level: Debug` (Trace with Payload) is strictly disabled in Production.
- [ ] **23. Correlation ID Propagation**: End-to-end tracing is preserved by propagating `X-Correlation-Id` or `ECID` through inbound and outbound request headers.
- [ ] **24. Project Archive Versioned**: The complete Project package (`.par`) is committed into Git along with deployment notes and environment variable values.
- [ ] **25. Automated Alerts**: Critical failures dispatch alerts to team distribution lists, Slack/Teams webhooks, or PagerDuty with direct links to the Gen 3 instance tracking URL.
