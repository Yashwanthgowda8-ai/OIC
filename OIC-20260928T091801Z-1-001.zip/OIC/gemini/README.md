# Oracle Integration Cloud Gen 3 (OIC Gen 3) Enterprise Architecture Skill

Welcome to the **Oracle Integration Cloud Gen 3 (OIC Gen 3) Architecture & Best-Practices Repository**.

This repository contains the enterprise skill definition and comprehensive architectural blueprints designed **exclusively for Oracle Integration Cloud Gen 3 (OIC Gen 3)**.

---

## 📁 Repository Structure

```text
OIC/
├── .agents/
│   └── skills/
│       └── oic-architecture-expert/
│           ├── SKILL.md                                 # Primary Gen 3 Skill definition & core architecture rules
│           └── references/
│               ├── architectural-patterns.md            # Sync APIs, Event Mesh, FBDI, Stage File & Parallel processing
│               ├── error-handling-framework.md          # 3-tier fault architecture, backoff loops, DLQ & RFC 7807
│               ├── performance-and-payload-tuning.md    # Memory limits, JS libraries, Private Endpoints & Agent tuning
│               ├── naming-and-governance-standards.md   # Projects (.par), Deployment Channels & Configurable Properties
│               └── production-readiness-checklist.md    # 25-point Gen 3 pre-production verification checklist
└── README.md                                            # Repository overview and quick start guide
```

---

## ⚡ Quick Architectural Reference (OIC Gen 3)

### 1. Projects as First-Class Citizens
* **Unified Packaging (`.par`)**: All integrations, connections, lookups, libraries, and events must be encapsulated inside **Gen 3 Projects**. No unassigned or loose integrations.
* **Deployment Channels**: Leverage Gen 3 Deployment Channels and Deployment Profiles for zero-touch promotion across DEV, TEST, and PROD.

### 2. Architectural Patterns & Event Mesh
* **Synchronous REST APIs**: Real-time services with SLA < 3s (platform ceiling is 300s). Keep payloads < 5MB.
* **Sync Facade + Event Worker**: Client receives immediate `HTTP 202 Accepted` with a tracking URL while an Event-driven worker processes heavy workflows in the background.
* **Native Event Mesh (Pub/Sub)**: Decouple integrations using native Gen 3 Events within and across Projects—no external Kafka broker required for standard decoupling.
* **High-Volume Streaming**: Files > 10MB must use **Stage File: Read File in Segments** (100–500 record chunks). Never use "Read Entire File" on unconstrained files. Always invoke `Delete File`.
* **Parallel Processing**: Utilize the native Gen 3 Parallel Action for concurrent, independent service calls.

### 3. Error Handling & Resilience
* **3-Tier Fault Architecture**: Scope-level fault handlers catch specific transient faults (`APIInvocationFault`, `TimeoutFault`), Global Fault Handler acts as an integration-level catch-all, and Project Common Error Service handles alerts and DLQ persistence.
* **Transient vs Non-Transient Faults**: Exponential backoff retry for transient faults (HTTP 429, 502, 503, 504). Immediate failure and alert for non-transient faults (HTTP 400, 401, 422).
* **RFC 7807 Standard**: Format synchronous error responses with `type`, `title`, `status`, `detail`, `instanceId`, and `correlationId`.

### 4. Performance, Compute & Connectivity
* **10 MB Hard Ceiling**: Never pass inline payloads > 10 MB in memory.
* **Gen 3 JavaScript Libraries (ES6+)**: Offload complex string transformations, regex parsing, and cryptographic checks from the mapper to native JS libraries.
* **OCI Private Endpoints**: Connect directly to Autonomous Databases (ATP) and private OCI subnets without installing Connectivity Agents.
* **Scope Variables**: Use Scope-level variables instead of global variables to minimize memory snapshot overhead.

### 5. Governance & Zero-Hardcoding
* **Configurable Properties**: Define Project and Integration Configurable Properties for environment-specific thresholds and endpoints (replaces legacy DVM hacks).
* **Production Audit Level**: Set to `Audit Level: Normal` or `Minimal`. Never activate in Production with `Debug` / `Trace with Payload`.

---

## 🚀 How to Use this Skill in Antigravity

This skill is registered at [`.agents/skills/oic-architecture-expert/SKILL.md`](file:///.agents/skills/oic-architecture-expert/SKILL.md). When working with Antigravity:
- The AI coding assistant automatically activates this skill when designing, building, or reviewing OIC Gen 3 integrations.
- You can consult the detailed reference manuals in the `references/` directory for code templates, schemas, and checklist reviews.
