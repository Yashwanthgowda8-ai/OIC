---
name: oic-gen3-mastery
description: >-
  Comprehensive OIC Gen 3 architecture, anti-pattern avoidance, and implementation mastery skill.
  Use this skill whenever designing, building, debugging, reviewing, or operating Oracle Integration Cloud Gen 3 integrations.
  Covers API-led 3-layer topology, saga/compensation patterns, anti-pattern detection, OCI-native observability,
  AI-augmented development (Document Understanding, mapping suggestions, Agentic AI), multi-project governance,
  and operational runbook templates. Created by Claude Opus.
---

# OIC Gen 3 Architecture Mastery — by Claude Opus

> **Philosophy**: The best integration architecture is invisible. It doesn't draw attention to itself—it just works, recovers from failures gracefully, and scales without human intervention. This skill teaches you to build integrations that operate at that level.

---

## 1. The Mental Model: Think in Layers, Not in Flows

The single biggest architectural mistake in OIC is treating each integration as an isolated flow. Instead, think of your entire OIC Gen 3 landscape as a **three-layer API fabric**:

```
┌─────────────────────────────────────────────────────────────────────┐
│                      EXPERIENCE LAYER                               │
│  Consumer-specific APIs shaped for Mobile, Portal, Partner, IoT     │
│  ● Lightweight REST facades   ● Response shaping & filtering       │
│  ● Rate limiting via OCI API Gateway   ● OAuth 2.0 scoped access  │
├─────────────────────────────────────────────────────────────────────┤
│                       PROCESS LAYER                                 │
│  Business workflow orchestration — the "brains"                     │
│  ● Saga/Compensation flows   ● Data enrichment & aggregation       │
│  ● Gen 3 Event Mesh (Pub/Sub)  ● Conditional routing & rules      │
│  ● Parallel fan-out/fan-in    ● Correlation ID propagation         │
├─────────────────────────────────────────────────────────────────────┤
│                       SYSTEM LAYER                                  │
│  Atomic adapters wrapping each backend — the "plumbing"             │
│  ● Oracle Fusion ERP/HCM/SCM  ● Salesforce / Workday / SAP        │
│  ● ATP / On-prem DB via Agent ● SFTP / Object Storage / Kafka     │
│  ● Pagination, retry, idempotency baked in at this layer           │
└─────────────────────────────────────────────────────────────────────┘
```

### Why Layers Matter in Gen 3 Projects:
Each layer maps to a **Gen 3 Project**. This gives you:
- **Independent deployment**: Upgrade the ERP System adapter without touching the Experience API.
- **Blast radius containment**: A bug in one Project cannot cascade to another.
- **Team ownership**: System layer owned by backend team, Experience layer by API/frontend team.

| Layer | Project Naming | Example |
| :--- | :--- | :--- |
| Experience | `EXP_[Domain]_Project` | `EXP_OrderPortal_Project` |
| Process | `PROC_[Workflow]_Project` | `PROC_OrderToCash_Project` |
| System | `SYS_[Backend]_Project` | `SYS_FusionERP_Project` |
| Shared | `SHARED_[Capability]_Project` | `SHARED_ErrorHandling_Project` |

---

## 2. The Anti-Pattern Catalog — What NOT to Do

Before discussing what to build, internalize what to avoid. These are the integration killers:

### 🚫 Anti-Pattern #1: The Chatty Loop
**Symptom**: A `For-Each` loop that makes one REST/SOAP call per record.
**Impact**: 10,000 records = 10,000 HTTP round-trips = 45+ minutes + rate limiting.
**Fix**: Batch records into chunks of 100–500 and use bulk/batch APIs. If the target has no batch API, accumulate records via Stage File and use a single bulk insert.

### 🚫 Anti-Pattern #2: Synchronous Everything
**Symptom**: A client-facing API that calls ERP, waits for invoice creation, calls WMS, waits for shipment, then responds.
**Impact**: Chain of 4 synchronous calls × 3s each = 12s response time, with any single failure killing the entire chain.
**Fix**: Return `HTTP 202 Accepted` immediately. Publish a Gen 3 Event. Let the Process layer orchestrate the downstream calls asynchronously.

### 🚫 Anti-Pattern #3: God Integration
**Symptom**: A single integration with 200+ actions that handles validation, transformation, multi-system posting, error handling, and notifications in one monolithic flow.
**Impact**: Impossible to debug, impossible to reuse, impossible to unit test.
**Fix**: Decompose into child integrations. Each integration should do exactly one thing well (Single Responsibility Principle).

### 🚫 Anti-Pattern #4: Read Entire File on Unknown Data
**Symptom**: Using `Stage File: Read Entire File` on an SFTP-sourced CSV without knowing the file size.
**Impact**: A 50 MB CSV expands to ~250–500 MB in JVM heap → `OutOfMemoryError` → pod restart → all concurrent integrations on that pod fail.
**Fix**: **Always** use `Read File in Segments` (200–500 records/chunk).

### 🚫 Anti-Pattern #5: Global Variables Inside Loops
**Symptom**: Appending to a global string variable with `concat()` inside a 5,000-iteration loop.
**Impact**: OIC creates an immutable state snapshot on every assignment → 5,000 snapshots → GC thrashing → OOM.
**Fix**: Use `Stage File: Write File` with append mode. Or use a Gen 3 JavaScript library for in-memory aggregation (within the 5-second JS timeout).

### 🚫 Anti-Pattern #6: Empty Global Fault Handler
**Symptom**: Global Fault Handler has zero actions.
**Impact**: The integration silently fails. No alert, no log, no error response. The business discovers it hours later when data is missing.
**Fix**: Every Global Fault Handler must: (1) log context, (2) clean up temp files, (3) publish error event to `SHARED_ErrorHandling_Project`, (4) return RFC 7807 response if synchronous.

---

## 3. Saga & Compensation Patterns for Distributed Transactions

When an integration spans multiple backends (ERP + CRM + WMS), you cannot use traditional database transactions. Use the **Orchestration Saga** pattern:

```
                    ┌──────────────────────────────────────────┐
                    │        SAGA ORCHESTRATOR (OIC)           │
                    │     (Process Layer Integration)          │
                    └──────┬──────────┬──────────┬─────────────┘
                           │          │          │
                Step 1     │  Step 2  │  Step 3  │
              Reserve      │  Charge  │  Confirm │
              Inventory    │  Payment │  Shipment│
                    ▼          ▼          ▼
              [WMS API]   [Payment API] [ERP API]
                    │          │          │
                    │          │     ✘ FAILURE!
                    │          │
             ┌──────┴──────────┴──────────────────┐
             │      COMPENSATING TRANSACTIONS      │
             │   Step 2 Undo: Refund Payment       │
             │   Step 1 Undo: Release Inventory    │
             └─────────────────────────────────────┘
```

### Implementation in OIC Gen 3:
1. **Track Saga State**: Use scope-level boolean variables: `v_inventoryReserved`, `v_paymentCharged`, `v_shipmentConfirmed`.
2. **Wrap Each Step in a Scope**: Each step has its own fault handler.
3. **In the Global Fault Handler**: Check which steps succeeded and execute compensating calls in reverse:
   ```
   If v_paymentCharged = true  → Invoke Refund API
   If v_inventoryReserved = true → Invoke Release Inventory API
   ```
4. **Idempotency Keys**: Pass a unique `idempotency-key` header on every downstream call so that retries don't create duplicates.

---

## 4. Gen 3 Event Mesh — The Right Way to Decouple

Gen 3 Events are not just "async calls." They are an architectural commitment to loose coupling.

### Event Design Principles:
1. **Events carry facts, not commands**: Name them as past-tense facts (`OrderPlaced`, `InvoiceApproved`), not imperative commands (`CreateShipment`).
2. **Thin events with reference IDs**: Don't stuff the entire 500-field ERP record into the event payload. Publish the entity ID + timestamp; let the subscriber fetch what it needs.
3. **One publisher, many subscribers**: If you find yourself publishing the same event from multiple integrations, you have a domain boundary problem—refactor.

### Cross-Project Event Topology:
```
  SYS_FusionERP_Project                 PROC_OrderToCash_Project
  ┌──────────────────┐                  ┌─────────────────────────┐
  │ ERP_BusinessEvent │ ──publishes──►  │ Order_Placed_Event      │
  │ Trigger           │                  │                         │
  └──────────────────┘                  └────┬───────────┬────────┘
                                             │           │
                               subscribes    │           │  subscribes
                                             ▼           ▼
                               PROC_Billing_Project   PROC_Fulfillment_Project
```

---

## 5. AI-Augmented Development in Gen 3 (2025+)

OIC Gen 3 now ships with embedded AI capabilities. Use them:

| Capability | What It Does | When to Use |
| :--- | :--- | :--- |
| **AI Mapping Suggestions** | Suggests field mappings between source and target schemas based on historical patterns. | Every mapping — accept or reject suggestions, but always check them first. |
| **Document Understanding Action** | Extracts structured data (key-value pairs, tables, text) from unstructured documents (invoices, receipts, forms). | Accounts Payable automation, expense processing, contract ingestion. |
| **AI Assistant** | Auto-generates project scaffolding, integration stubs, and documentation from natural language prompts. | Prototyping new integrations, generating boilerplate. |
| **Integration as AI Agent Tool (MCP)** | Exposes OIC integrations as callable tools for AI Agents. | Building agentic workflows where LLMs orchestrate business processes. |

### Document Understanding Recipe:
```
[Schedule Trigger] → [FTP: Download Invoice PDF]
                          │
              [Document Understanding Action]
              (Extract: VendorName, InvoiceNumber,
               LineItems[], TotalAmount, DueDate)
                          │
              [Validation Scope: Business Rules]
                          │
              [Oracle ERP Cloud: Create AP Invoice]
```

---

## 6. OCI-Native Observability Stack

Don't just monitor — observe. Wire OIC Gen 3 into the full OCI observability fabric:

```
┌─────────────────────────────────────────────────────────────────────┐
│                    OCI OBSERVABILITY STACK                          │
│                                                                     │
│  ┌──────────────┐  ┌──────────────────┐  ┌───────────────────────┐ │
│  │ OCI Logging   │  │ OCI Logging      │  │ OCI Monitoring        │ │
│  │ (Activity     │  │ Analytics        │  │ (Metrics + Alarms)    │ │
│  │  Stream Logs) │──►│ (Dashboards,     │  │                       │ │
│  │               │  │  Correlation,    │  │ • Received Messages   │ │
│  └──────────────┘  │  Trend Analysis) │  │ • Failed Messages     │ │
│                     └──────────────────┘  │ • Outbound Requests   │ │
│                                           │ • Processing Latency  │ │
│  ┌──────────────┐  ┌──────────────────┐  └───────┬───────────────┘ │
│  │ OCI Events    │  │ OCI Notifications│          │ Threshold       │
│  │ (Auto-trigger │  │ (Email, Slack,   │◄─────────┘ Breach          │
│  │  remediation) │  │  PagerDuty)      │                            │
│  └──────────────┘  └──────────────────┘                            │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐   │
│  │ OIC Integration Insight (Business KPI Dashboards)            │   │
│  │ • "How many orders are stuck at validation?"                 │   │
│  │ • "Average time from order receipt to ERP posting?"          │   │
│  └──────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

### Observability Setup Checklist:
1. **Enable Activity Stream Logging** → OCI Logging → OCI Logging Analytics
2. **Create OCI Alarms** for: Error rate > 5% over 15 min, Latency P99 > 10s, Failed messages > 0 on critical flows
3. **OCI Notifications Topic** → SNS → Slack/Teams/PagerDuty
4. **OIC Insight Models** for business KPIs (order cycle time, invoice processing SLA)

---

## 7. Deep-Dive Reference Manuals

Detailed implementation guides in the [`references/`](./references/) folder:

- [Anti-Patterns & Remediation Catalog](./references/anti-patterns-catalog.md): Exhaustive catalog of 12 OIC anti-patterns with root cause analysis and fixes.
- [Saga & Compensation Pattern Cookbook](./references/saga-compensation-patterns.md): Step-by-step saga orchestration blueprints with compensation matrices.
- [API-Led Topology & Versioning Strategy](./references/api-led-topology.md): 3-layer project architecture, API versioning, and OCI API Gateway integration.
- [OCI Observability & Operational Runbooks](./references/observability-and-runbooks.md): Full OCI stack wiring, alarm configuration, and incident response runbooks.
- [Production Hardening Checklist (30-Point)](./references/production-hardening-checklist.md): 30-point verification covering architecture, resilience, security, observability, and AI readiness.
