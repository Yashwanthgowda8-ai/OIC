# API-Led Topology & Versioning Strategy for OIC Gen 3

> Your OIC Gen 3 landscape should read like a well-organized library, not a junk drawer. This guide teaches you how to structure your projects into a composable, versionable, API-led architecture.

---

## 1. The Three-Layer Project Topology

### Layer Definitions:

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│  EXPERIENCE LAYER (EXP_*)                                          │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │ Purpose: Consumer-facing APIs tailored for specific clients  │  │
│  │                                                               │  │
│  │ • Mobile app needs 5 fields? Return only 5 fields.           │  │
│  │ • Partner needs XML? Transform to XML here.                  │  │
│  │ • Portal needs combined data? Aggregate from Process layer.  │  │
│  │                                                               │  │
│  │ Rules:                                                        │  │
│  │  ✓ Thin — no business logic, just shaping/filtering          │  │
│  │  ✓ Secured with OAuth 2.0 scopes per consumer                │  │
│  │  ✓ Rate-limited via OCI API Gateway                          │  │
│  │  ✗ Never calls System layer directly (always via Process)    │  │
│  └───────────────────────────────────────────────────────────────┘  │
│                              │ calls                                │
│                              ▼                                      │
│  PROCESS LAYER (PROC_*)                                            │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │ Purpose: Business workflow orchestration                     │  │
│  │                                                               │  │
│  │ • Saga coordination (Order→Payment→Fulfillment)              │  │
│  │ • Data enrichment & cross-system aggregation                 │  │
│  │ • Business rule evaluation & conditional routing             │  │
│  │ • Gen 3 Event publishing for async fan-out                   │  │
│  │                                                               │  │
│  │ Rules:                                                        │  │
│  │  ✓ Contains business logic                                   │  │
│  │  ✓ Orchestrates multiple System layer calls                  │  │
│  │  ✓ Owns saga state and compensation logic                   │  │
│  │  ✗ Never exposed directly to external consumers              │  │
│  └───────────────────────────────────────────────────────────────┘  │
│                              │ calls                                │
│                              ▼                                      │
│  SYSTEM LAYER (SYS_*)                                              │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │ Purpose: Atomic adapters wrapping each backend system        │  │
│  │                                                               │  │
│  │ • One Project per backend: SYS_FusionERP, SYS_Salesforce     │  │
│  │ • Handles pagination, retry, rate-limit backoff internally   │  │
│  │ • Exposes a clean, normalized REST contract upward           │  │
│  │ • Encapsulates system-specific quirks (date formats, etc.)   │  │
│  │                                                               │  │
│  │ Rules:                                                        │  │
│  │  ✓ One integration per entity/operation                      │  │
│  │  ✓ Idempotent by design                                     │  │
│  │  ✗ No business logic — pure CRUD/query abstraction           │  │
│  │  ✗ Never calls other System layer projects                   │  │
│  └───────────────────────────────────────────────────────────────┘  │
│                                                                     │
│  SHARED LAYER (SHARED_*)                                           │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │ Cross-cutting concerns used by all layers:                   │  │
│  │ • SHARED_ErrorHandling_Project (centralized DLQ + alerting)  │  │
│  │ • SHARED_Notifications_Project (email/Slack/Teams dispatch)  │  │
│  │ • SHARED_AuditLog_Project (compliance event trail)           │  │
│  └───────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 2. Project Naming Convention

| Layer | Project Name | Integration Name Example |
| :--- | :--- | :--- |
| Experience | `EXP_MobileApp_Project` | `EXP_MOB_GET_ORDER_STATUS_v1` |
| Experience | `EXP_PartnerPortal_Project` | `EXP_PARTNER_SUBMIT_PO_v2` |
| Process | `PROC_OrderToCash_Project` | `PROC_OTC_ORDER_FULFILLMENT_SAGA` |
| Process | `PROC_ProcureToPay_Project` | `PROC_P2P_INVOICE_APPROVAL_WORKFLOW` |
| System | `SYS_FusionERP_Project` | `SYS_ERP_CREATE_AP_INVOICE_v1` |
| System | `SYS_Salesforce_Project` | `SYS_SFDC_UPSERT_ACCOUNT_v1` |
| System | `SYS_CorpSFTP_Project` | `SYS_SFTP_DOWNLOAD_BANK_FEED` |
| Shared | `SHARED_ErrorHandling_Project` | `SHARED_ERR_DLQ_PROCESSOR` |
| Shared | `SHARED_Notifications_Project` | `SHARED_NOTIFY_DISPATCH_ALERT` |

### Version Suffix Convention:
- Integration names include `_v1`, `_v2` etc. when the REST endpoint version changes.
- Allows running `v1` and `v2` simultaneously during consumer migration windows.

---

## 3. API Versioning Strategy

### Versioning Model: URI Path Versioning
```
/ic/api/integration/v1/flows/rest/EXP_MOB_GET_ORDER_STATUS/1.0/orders/{orderId}
                                                            ^^^
                                                    OIC integration version
```

### Version Lifecycle:

```
┌────────────┐    Breaking change    ┌────────────┐
│  v1 (Live) │ ──────────────────►   │  v2 (Live) │
│  Active    │     Deploy v2,        │  Active    │
│            │     keep v1 active    │            │
└────────────┘                       └────────────┘
      │                                    │
      │  Deprecation window (30–90 days)   │
      │  Consumers migrate to v2           │
      ▼                                    │
┌────────────┐                             │
│  v1 (Depr) │  Sunset after all           │
│  Sunset    │  consumers migrated         │
└────────────┘                             │
```

### Version Change Rules:
| Change Type | Requires New Version? | Example |
| :--- | :--- | :--- |
| Add optional field to response | No | Adding `lastModifiedDate` to order response |
| Add optional query parameter | No | Adding `?includeLineItems=true` |
| Remove or rename a field | **Yes — breaking** | Renaming `customerName` → `clientName` |
| Change field data type | **Yes — breaking** | Changing `orderId` from string to integer |
| Change HTTP method | **Yes — breaking** | Changing `GET /orders` to `POST /orders/query` |
| Add required field to request | **Yes — breaking** | Making `shippingAddress` mandatory |

---

## 4. OCI API Gateway Integration

For external-facing Experience layer APIs, front them with **OCI API Gateway**:

```
[External Client]
       │
       ▼
┌─────────────────────────────────────────────┐
│            OCI API Gateway                   │
│                                              │
│  • Rate Limiting: 100 req/min per client    │
│  • Quota: 10,000 req/day per API key        │
│  • OAuth 2.0 JWT Validation                 │
│  • Request/Response Transformation          │
│  • CORS Policy                              │
│  • WAF (Web Application Firewall)           │
│  • Usage Analytics & Metering               │
│                                              │
│  Route: /v1/orders/* → OIC EXP Integration  │
│  Route: /v2/orders/* → OIC EXP Integration  │
└──────────────────┬──────────────────────────┘
                   │
                   ▼
          [OIC Gen 3 Experience Layer]
```

### Why API Gateway + OIC (Not OIC Alone):
- **OIC is an integration platform, not an API Gateway.** It lacks native rate limiting, quota management, API key rotation, and WAF capabilities.
- **Defense in depth**: API Gateway rejects malformed, unauthorized, or excessive traffic before it reaches OIC, protecting your OPU (Oracle Processing Unit) budget.

---

## 5. Connection Naming for Multi-Layer Architecture

### The Environment-Agnostic Rule:
Connection names must be **identical across DEV, TEST, and PROD** OIC instances. Only the connection *properties* (URL, credentials) change per environment.

```
Connection Name (same everywhere):     ORACLE_ERP_CLOUD
  DEV properties:                      https://dev-erp.oraclecloud.com
  TEST properties:                     https://test-erp.oraclecloud.com
  PROD properties:                     https://prod-erp.oraclecloud.com
```

This ensures that `.par` project archives deploy without requiring connection remapping, using **Deployment Profiles** to swap properties.

---

## 6. Gen 3 Event Naming for Cross-Project Communication

### Convention: `[Entity]_[PastTenseAction]_Event`
Events are **facts** — things that already happened. Never name them as commands.

| ✅ Correct (Fact) | ❌ Wrong (Command) |
| :--- | :--- |
| `Order_Placed_Event` | `Create_Shipment_Event` |
| `Invoice_Approved_Event` | `Post_To_GL_Event` |
| `Employee_Terminated_Event` | `Revoke_Access_Event` |
| `Payment_Failed_Event` | `Retry_Payment_Event` |

### Event Schema Design:
```json
{
  "eventType": "Order_Placed_Event",
  "eventVersion": "1.0",
  "correlationId": "CORR-2026-88291",
  "timestamp": "2026-09-27T01:10:00Z",
  "source": "PROC_OrderToCash_Project",
  "data": {
    "orderId": "ORD-88291",
    "customerId": "CUST-44102",
    "orderTotal": 1250.00,
    "currency": "USD"
  }
}
```

**Key principle**: The `data` block should contain **just enough** for subscribers to decide if they care. Subscribers fetch full details from the System layer if needed.
