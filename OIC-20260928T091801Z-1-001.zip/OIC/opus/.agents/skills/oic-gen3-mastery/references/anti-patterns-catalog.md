# OIC Gen 3 Anti-Patterns & Remediation Catalog

> Every anti-pattern in this catalog was discovered in real production OIC environments. Learn from other teams' pain so you don't repeat it.

---

## Anti-Pattern Index

| # | Name | Severity | Root Cause | Section |
| :--- | :--- | :--- | :--- | :--- |
| 1 | Chatty Loop | 🔴 Critical | N+1 API calls inside For-Each | §1 |
| 2 | Synchronous Chain | 🔴 Critical | Blocking serial calls in sync flow | §2 |
| 3 | God Integration | 🟠 High | Monolithic 200+ action flow | §3 |
| 4 | Unbounded Read Entire File | 🔴 Critical | Stage File OOM on large files | §4 |
| 5 | Global Variable Mutation in Loops | 🔴 Critical | Immutable state snapshots → GC death | §5 |
| 6 | Empty Global Fault Handler | 🟠 High | Silent failure, no diagnostics | §6 |
| 7 | Hardcoded Environment Config | 🟠 High | Broken deployments across envs | §7 |
| 8 | Debug Audit in Production | 🟡 Medium | Disk exhaustion, PII exposure | §8 |
| 9 | Retry Without Classification | 🟠 High | Infinite retry on 400/422 errors | §9 |
| 10 | Orphaned Stage Files | 🟡 Medium | Disk space leak on tenant | §10 |
| 11 | Tight Coupling via Direct Invoke | 🟠 High | Cascading failures between integrations | §11 |
| 12 | Ignoring FBDI Execution Logs | 🟠 High | Silent data loss in ERP imports | §12 |

---

## §1. Chatty Loop (N+1 Problem)

### What It Looks Like:
```
[For-Each Record in 10,000-record payload]
    └── [Invoke: POST /api/customers  ← one HTTP call per record]
```

### Why It's Devastating:
- **10,000 records × ~200ms per HTTP round-trip = 33+ minutes** minimum execution time.
- Target API rate limits (e.g., Oracle Fusion REST: 1,200 requests/minute) will throttle you at record #1,200, adding exponential wait time.
- OIC worker thread is held hostage for the entire duration.

### The Fix:
```
[Stage File: Read File in Segments] (500 records per segment)
    └── [For-Each Segment]
            └── [Mapper: Transform 500 records into batch array]
            └── [Invoke: POST /api/customers/batch  ← one HTTP call per 500 records]
```
- **Result**: 10,000 records ÷ 500 per batch = 20 HTTP calls ≈ 4 seconds.
- If the target API has no batch endpoint, use `Stage File: Write File` (append mode) to build a composite request file, then submit the file.

---

## §2. Synchronous Chain (Cascading Timeout Bomb)

### What It Looks Like:
```
[Client Request]
    → [Call CRM: 2s]
        → [Call ERP: 3s]
            → [Call WMS: 4s]
                → [Call Email Service: 1s]
    ← [Return Response: total 10s+]
```

### Why It's Devastating:
- Total latency = sum of all downstream latencies. Any single service slowdown compounds.
- If WMS is slow (20s instead of 4s), the client sees a 25s response. If it times out, the client gets a 504, but CRM and ERP changes have already committed — **partial transaction with no compensation**.
- API Gateways typically timeout at 30–60s, cutting off the response even if OIC is still working.

### The Fix — Sync Facade + Async Process:
```
[Client Request]
    → [Validate + Generate Correlation ID]
    → [Publish: OrderSubmittedEvent]  ← takes ~50ms
    ← [Return HTTP 202 Accepted + statusUrl]  ← total: ~200ms

[Async Subscriber: OrderSubmittedEvent]
    → [Scope: Call CRM]       ← with local fault handler
    → [Scope: Call ERP]       ← with local fault handler & compensation
    → [Scope: Call WMS]       ← with local fault handler & compensation
    → [Update Status: COMPLETED]
```

---

## §3. God Integration (The Monolith)

### Diagnostic Questions:
- Does this integration have more than 50 actions? → Refactor.
- Does it touch more than 3 external systems? → Break into child integrations.
- Does it have more than 5 levels of nested branching? → Extract branches into separate flows.
- Can you explain what it does in one sentence? → If not, it's a God Integration.

### Decomposition Strategy:
```
BEFORE: One monolith integration
┌─────────────────────────────────────────────────────┐
│ Validate → Enrich → Call ERP → Call CRM → Call WMS  │
│ → Handle errors → Send email → Update status        │
└─────────────────────────────────────────────────────┘

AFTER: Composable child integrations
┌──────────────────────┐    ┌──────────────────────┐
│ SYS_ERP_CreateOrder  │    │ SYS_CRM_UpdateAccount│
└──────────────────────┘    └──────────────────────┘
          ▲                           ▲
          │                           │
┌─────────┴───────────────────────────┴───────────┐
│           PROC_OrderToCash_Orchestrator          │
│  (Calls child integrations, manages saga state) │
└─────────────────────────────────────────────────┘
```

---

## §4. Unbounded Read Entire File

### The Memory Math:
| File Size (on disk) | DOM Expansion in JVM | Typical OIC Pod Heap |
| :--- | :--- | :--- |
| 5 MB | ~25–50 MB | Shared across all active integrations |
| 20 MB | ~100–200 MB | **High risk of OOM** |
| 50 MB | ~250–500 MB | **Guaranteed OOM + pod restart** |
| 100 MB+ | ~500 MB–1 GB | **Catastrophic: kills all integrations on the pod** |

### The Only Safe Pattern:
```
[Stage File: Read File in Segments]
    Segment size: 200 records (conservative) to 500 records (aggressive)
    ↓
[For-Each Segment]
    ↓ Process chunk ↓
    ↓ Write results ↓
[Stage File: Delete File]  ← ALWAYS, even in fault handlers
```

---

## §5. Global Variable Mutation in Loops

### The Invisible Killer:
Every `Assign` action that modifies a variable creates an **immutable copy of the entire integration state**. Inside a loop:
```
Loop iteration 1: state snapshot #1 (contains all variables + context)
Loop iteration 2: state snapshot #2
...
Loop iteration 5000: state snapshot #5000
```
Each snapshot stays in memory until GC runs. With 5,000 snapshots × ~50 KB each = **250 MB** of garbage per loop execution.

### Safe Alternatives:
1. **Stage File Append**: Write results to disk instead of accumulating in a variable.
2. **Gen 3 JavaScript Library**: Process in-memory efficiently (but respect the 5-second timeout).
3. **Scope Variables**: Use variables scoped to the For-Each body — they are released each iteration.

---

## §6–§12: Quick Reference Fixes

| Anti-Pattern | Fix |
| :--- | :--- |
| **§6. Empty Global Fault Handler** | Minimum 4 actions: Log fault → Clean temp files → Publish error event → Return RFC 7807 or rethrow. |
| **§7. Hardcoded Environment Config** | Move all URLs, directories, emails, thresholds to **Gen 3 Configurable Properties** (Project-level or Integration-level). |
| **§8. Debug Audit in Production** | Set `Audit Level: Normal` or `Minimal` in PROD. Reserve `Debug` for active P1 triage only, disable within 1 hour. |
| **§9. Retry Without Classification** | **Transient** (429, 502, 503, 504): Retry with exponential backoff, max 3–5 attempts. **Non-Transient** (400, 401, 404, 422): Fail fast → DLQ. |
| **§10. Orphaned Stage Files** | Add `Delete File` in **both** the happy path and the Global Fault Handler. Run a weekly sweep integration to purge `/tmp/` artifacts. |
| **§11. Tight Coupling via Direct Invoke** | Replace direct `Invoke Integration` calls with Gen 3 Events (Pub/Sub). Publishers and subscribers evolve independently. |
| **§12. Ignoring FBDI Execution Logs** | After every `importBulkData`, download the ESS execution log ZIP. Parse the bad-records CSV. If `rejectedCount > 0`, alert the business. |
