# OCI-Native Observability & Operational Runbooks for OIC Gen 3

> Monitoring tells you *something is wrong*. Observability tells you *why* it's wrong. This guide wires OIC Gen 3 into the full OCI observability stack and provides incident response runbooks.

---

## 1. The Four Pillars of OIC Observability

```
┌─────────────────────────────────────────────────────────────┐
│                    OBSERVABILITY PILLARS                     │
│                                                             │
│   METRICS          LOGS           TRACES        BUSINESS    │
│   (OCI             (OCI           (Correlation  (OIC        │
│    Monitoring)      Logging +      ID chain)     Insight)   │
│                     Analytics)                              │
│                                                             │
│   "How many?"      "What          "Where in     "What does │
│   "How fast?"       happened?"     the chain?"   it mean   │
│   "How often?"     "When?"        "Which hop?"   for the   │
│                    "What error?"                  business?"│
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Wiring OIC Gen 3 → OCI Observability (Step-by-Step)

### Step 1: Enable Activity Stream Logging
```
OCI Console → Integration Instances → [Your Instance] → Logs tab
  → Enable "Activity Stream" → Select Log Group → Enable
```
This pushes all integration execution events (start, complete, fault, activity details) to **OCI Logging**.

### Step 2: Ingest into OCI Logging Analytics
```
OCI Console → Observability → Logging Analytics → Administration
  → Add Log Source → Select OIC Activity Stream logs
  → Map to "Oracle Integration Cloud" source type
```
This enables **search, correlation, trend analysis**, and **custom dashboard creation** over your OIC logs.

### Step 3: Create OCI Monitoring Alarms
Navigate to `OCI Console → Monitoring → Alarms` and create the following critical alarms:

| Alarm Name | Metric | Condition | Notification |
| :--- | :--- | :--- | :--- |
| `OIC-HighErrorRate` | `FailedMessages` | > 5% of `ReceivedMessages` over 15 min | PagerDuty (P2) |
| `OIC-CriticalFailure` | `FailedMessages` | > 0 on critical integration (by name filter) | PagerDuty (P1) |
| `OIC-HighLatency` | `ProcessingTime` (P99) | > 10 seconds over 5 min window | Slack #ops-alerts |
| `OIC-AgentDown` | `ConnectivityAgentStatus` | Status != ACTIVE for > 3 min | PagerDuty (P1) |
| `OIC-MessageSpike` | `ReceivedMessages` | > 200% of baseline over 10 min | Slack #ops-alerts |

### Step 4: Configure OCI Notifications
```
OCI Console → Developer Services → Notifications → Create Topic
  → Subscription: Email, Slack webhook, PagerDuty integration key
  → Link to Alarms from Step 3
```

### Step 5: Set Up OIC Insight Models (Business KPIs)
OIC Insight allows you to define **business-level milestones** across integration flows:

```
Example: Order-to-Cash Business Model

Milestones:
  M1: Order Received       (trigger: OrderSubmittedEvent published)
  M2: Payment Processed    (trigger: Payment scope completed)
  M3: ERP Order Created    (trigger: ERP invoke succeeded)
  M4: Shipment Confirmed   (trigger: WMS response received)

KPIs:
  • Average M1→M4 cycle time (SLA: < 30 minutes)
  • Orders stuck at M2 for > 1 hour (alert threshold)
  • Daily order volume by source channel
```

---

## 3. Operational Runbooks

### Runbook #1: Integration Instance Failure (P1)

```
TRIGGER: OCI Alarm "OIC-CriticalFailure" fires
SEVERITY: P1 — Business-impacting
SLA: Acknowledge within 5 min, Resolve within 1 hour

STEP 1: TRIAGE (5 min)
  □ Open OIC Monitoring → Filter by failed instances (last 30 min)
  □ Identify the failing integration name and version
  □ Check: Is this a single instance or pattern of failures?
  □ Check: Is the downstream system responding? (test connection)

STEP 2: DIAGNOSE (15 min)
  □ Open failed instance → Activity Stream → Find the faulting action
  □ Read $fault.code, $fault.reason, $fault.details
  □ Classify:
    - Transient (429/502/503/504/network)? → Go to STEP 3A
    - Non-transient (400/401/422/schema)? → Go to STEP 3B
    - Infrastructure (OOM/agent down)?    → Go to STEP 3C

STEP 3A: TRANSIENT FAILURE RECOVERY
  □ Check downstream system health independently
  □ If system is recovering: wait 10 min, resubmit failed instances
  □ If system is down: engage downstream team, pause OIC schedule
  □ Post-incident: verify retry/backoff logic is configured

STEP 3B: NON-TRANSIENT FAILURE RECOVERY
  □ Inspect the request payload for data quality issues
  □ Check if API contract changed (schema drift)
  □ If data issue: fix source data, resubmit from DLQ
  □ If contract change: update integration mapping, test, redeploy

STEP 3C: INFRASTRUCTURE FAILURE RECOVERY
  □ OOM: Check recent deployment for Stage File or mapping changes
  □ OOM: Temporarily scale OPUs if available
  □ Agent down: SSH into agent host, check JVM process, restart agent
  □ Agent down: Verify network connectivity (port 443 outbound)

STEP 4: VERIFY & CLOSE
  □ Resubmit 1 test transaction — confirm success
  □ Monitor for 30 min — confirm no recurrence
  □ Update incident ticket with root cause and resolution
  □ If design flaw found: create backlog item for architectural fix
```

---

### Runbook #2: Connectivity Agent Failure

```
TRIGGER: OCI Alarm "OIC-AgentDown" fires
SEVERITY: P1 if on-prem integrations are active, P2 otherwise

STEP 1: VERIFY AGENT STATUS
  □ OIC Console → Agents → Check agent group status
  □ If HA group: is the secondary agent still active?
    - If yes: traffic is auto-rerouted, downgrade to P2
    - If no: both agents down, remain P1

STEP 2: DIAGNOSE AGENT HOST
  □ SSH/RDP into the agent host machine
  □ Check: is the JVM process running?
    Linux: ps -ef | grep "oic-agent"
    Windows: Get-Process | Where Name -like "*agent*"
  □ Check agent logs: <AGENT_HOME>/logs/agent-diagnostics.log
  □ Common causes:
    - JVM OOM → Increase heap: -Xms2048m -Xmx4096m
    - Certificate expiry → Renew agent certificates
    - Network firewall change → Verify port 443 outbound to OIC
    - Host disk full → Clear old logs, temp files

STEP 3: RESTART AGENT
  □ Linux: <AGENT_HOME>/bin/agentstop.sh && <AGENT_HOME>/bin/agentstart.sh
  □ Windows: <AGENT_HOME>\bin\agentstop.bat && <AGENT_HOME>\bin\agentstart.bat
  □ Wait 2–3 minutes for agent to re-register with OIC
  □ Verify status in OIC Console → Agents → Status: ACTIVE

STEP 4: VERIFY & DRAIN QUEUE
  □ Check if any integrations queued messages during downtime
  □ Resubmit or let scheduled integrations pick up on next cycle
  □ Monitor for 30 min
```

---

### Runbook #3: Slow Integration Performance

```
TRIGGER: OCI Alarm "OIC-HighLatency" fires or user report of slow API
SEVERITY: P3 (unless SLA breach, then P2)

STEP 1: IDENTIFY THE BOTTLENECK
  □ OIC Monitoring → Sort by average execution time (desc)
  □ Open the slow integration instance → Activity Stream
  □ Identify which specific action takes the most time:
    - External invoke? → Downstream system is slow
    - Mapper? → Complex XSLT or large payload
    - Stage File? → Large file being read without chunking
    - For-Each loop? → Chatty loop anti-pattern

STEP 2: ROOT CAUSE ANALYSIS
  □ Downstream slow:
    - Test the endpoint independently (Postman/curl)
    - Check if downstream has rate limiting or throttling active
    - Consider: add caching, reduce call frequency, batch requests
  □ Mapper slow:
    - Check for nested For-Each in XSLT (O(N×M) problem)
    - Remedy: Add <xsl:key> lookups in Code View
  □ Stage File slow:
    - Confirm "Read in Segments" is being used
    - Reduce segment size if memory pressure is high
  □ Chatty loop:
    - Refactor to batch/bulk API calls
    - See Anti-Pattern #1 in anti-patterns-catalog.md

STEP 3: IMPLEMENT FIX
  □ Test fix in DEV environment with production-like data volume
  □ Measure before/after execution time
  □ Deploy to PROD via Deployment Channel
  □ Monitor for 24 hours
```

---

### Runbook #4: FBDI Import Partial Failure

```
TRIGGER: ESS Job shows SUCCEEDED but business reports missing records
SEVERITY: P2

STEP 1: RETRIEVE EXECUTION LOG
  □ Integration Activity Stream → Find the FBDI integration instance
  □ Locate the "Import Bulk Data" action → note the ESS Job ID
  □ Fusion ERP → Navigator → Scheduled Processes → Search by Job ID
  □ Download the execution log ZIP file

STEP 2: PARSE RESULTS
  □ Extract ZIP → look for files matching *_bad_records* or *_error*
  □ Count rejected rows vs total rows
  □ Common rejection reasons:
    - Invalid foreign key (e.g., non-existent GL account code)
    - Duplicate primary key (record already imported)
    - Required field missing
    - Date format mismatch

STEP 3: FIX & RESUBMIT
  □ Fix source data for rejected rows
  □ Create a "corrections" CSV containing only the fixed rows
  □ Resubmit via the same FBDI integration
  □ Verify: rejected count = 0 on resubmission

STEP 4: PREVENT RECURRENCE
  □ Add pre-validation logic in OIC (validate FK references before import)
  □ Add automated execution log parsing to the integration:
    Download log → Parse bad records → If count > 0 → Alert business
```

---

## 4. Correlation ID Propagation Pattern

Ensure end-to-end traceability by propagating a Correlation ID through every layer:

```
[Client Request]
  Header: X-Correlation-Id: CORR-2026-88291 (or generate if absent)
       │
       ▼
[Experience Layer]  ── passes header ──►  [Process Layer]
                                               │
                    ── passes header ──►  [System Layer: ERP]
                    ── passes header ──►  [System Layer: CRM]
                                               │
                    ── logs with ID ──►   [Error Handling Service]
                    ── tags with ID ──►   [OCI Logging Analytics]
```

### OIC Gen 3 Implementation:
1. **Inbound**: Extract `X-Correlation-Id` from request headers. If absent, generate: `ora:generateGUID()`.
2. **Assign to Tracking Variable**: Set as Primary or Secondary Business Identifier for OIC Monitoring.
3. **Outbound**: Map the correlation ID into every downstream Invoke action's request headers.
4. **Fault Handler**: Include the correlation ID in every error log and RFC 7807 response.

This makes it possible to search for `CORR-2026-88291` in OCI Logging Analytics and see every integration, every action, every hop that this transaction touched.
