# Saga & Compensation Pattern Cookbook for OIC Gen 3

> In distributed systems, you cannot roll back. You can only compensate. This cookbook teaches you how to design integrations that recover gracefully from partial failures across multiple systems.

---

## 1. Why Sagas? The Distributed Transaction Problem

Traditional database transactions (ACID) don't work when your integration spans:
- Oracle Fusion ERP (create invoice)
- Stripe/PayPal (charge payment)
- Warehouse Management System (reserve inventory)
- Notification Service (send confirmation)

There is no shared transaction coordinator across these systems. If step 3 fails, steps 1 and 2 have already committed. You need **compensating transactions** — new business operations that semantically undo previous steps.

### The Golden Rule of Compensation:
> **Compensation is NOT a database rollback.** It is a new forward-moving business action that undoes the business effect of a previous action.

| Original Action | Compensating Action | NOT This |
| :--- | :--- | :--- |
| Create Invoice | Cancel/Void Invoice | `DELETE FROM invoices` |
| Charge $100 | Issue $100 Refund | `UPDATE balance` |
| Reserve 50 units | Release 50 units | `DELETE FROM reservations` |
| Send Confirmation Email | Send Cancellation Email | Can't unsend email |

---

## 2. Orchestration Saga Blueprint in OIC Gen 3

### Architecture:

```
┌──────────────────────────────────────────────────────────────┐
│              PROC_OrderToCash_Saga (Orchestrator)            │
│                                                              │
│  Variables (Scope-level):                                    │
│    v_sagaState = "STARTED"                                   │
│    v_inventoryReserved = false                               │
│    v_paymentCharged = false                                  │
│    v_erpOrderCreated = false                                 │
│    v_correlationId = ora:generateGUID()                      │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐    │
│  │ STEP 1: Reserve Inventory                            │    │
│  │ [Scope: ReserveInventory]                            │    │
│  │   → Invoke: WMS API /inventory/reserve               │    │
│  │   → Assign: v_inventoryReserved = true               │    │
│  │   → Assign: v_sagaState = "INVENTORY_RESERVED"       │    │
│  │   [Fault Handler]                                    │    │
│  │     → Assign: v_sagaState = "FAILED_AT_INVENTORY"    │    │
│  │     → Rethrow (escalate to Global Fault Handler)     │    │
│  └──────────────────────────────────────────────────────┘    │
│                          │                                    │
│                          ▼                                    │
│  ┌──────────────────────────────────────────────────────┐    │
│  │ STEP 2: Charge Payment                               │    │
│  │ [Scope: ChargePayment]                               │    │
│  │   → Invoke: Payment API /charges (idempotency-key)   │    │
│  │   → Assign: v_paymentCharged = true                  │    │
│  │   → Assign: v_sagaState = "PAYMENT_CHARGED"          │    │
│  │   [Fault Handler]                                    │    │
│  │     → Assign: v_sagaState = "FAILED_AT_PAYMENT"      │    │
│  │     → Rethrow                                        │    │
│  └──────────────────────────────────────────────────────┘    │
│                          │                                    │
│                          ▼                                    │
│  ┌──────────────────────────────────────────────────────┐    │
│  │ STEP 3: Create ERP Order                             │    │
│  │ [Scope: CreateERPOrder]                              │    │
│  │   → Invoke: Fusion ERP REST /ordersV2                │    │
│  │   → Assign: v_erpOrderCreated = true                 │    │
│  │   → Assign: v_sagaState = "COMPLETED"                │    │
│  │   [Fault Handler]                                    │    │
│  │     → Assign: v_sagaState = "FAILED_AT_ERP"          │    │
│  │     → Rethrow                                        │    │
│  └──────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐    │
│  │ GLOBAL FAULT HANDLER (Compensation Controller)       │    │
│  │                                                      │    │
│  │  If v_paymentCharged = true:                         │    │
│  │    → Invoke: Payment API /refunds                    │    │
│  │    → Log: "Compensation: Payment refunded"           │    │
│  │                                                      │    │
│  │  If v_inventoryReserved = true:                      │    │
│  │    → Invoke: WMS API /inventory/release              │    │
│  │    → Log: "Compensation: Inventory released"         │    │
│  │                                                      │    │
│  │  → Publish: Order_Failed_Event (to error service)    │    │
│  │  → Return RFC 7807 error (if sync trigger)           │    │
│  └──────────────────────────────────────────────────────┘    │
└──────────────────────────────────────────────────────────────┘
```

---

## 3. Compensation Decision Matrix

Use this matrix to plan compensation logic before writing the integration:

| Saga Step | Forward Action | Compensating Action | Compensation Idempotent? | Can Compensation Fail? | Fallback If Compensation Fails |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 1. Reserve Inventory | `POST /inventory/reserve` | `POST /inventory/release` | Yes (release is a no-op if already released) | Unlikely | Log to DLQ + manual alert |
| 2. Charge Payment | `POST /charges` | `POST /refunds` | Yes (if idempotency-key matches) | Yes (insufficient funds for refund) | Escalate to Finance team via ServiceNow |
| 3. Create ERP Order | `POST /ordersV2` | `PATCH /ordersV2/{id}` → status: CANCELLED | Yes | Yes (ERP may reject cancellation if order already shipped) | Park in DLQ with status `MANUAL_REVIEW` |

### Critical Design Rule:
> **Compensating transactions must themselves be idempotent.** If the compensation call fails and is retried, it should produce the same result. Always use unique idempotency keys.

---

## 4. Idempotency Implementation

Every downstream API call in a saga must include an **idempotency key** to prevent duplicate processing on retries:

### HTTP Header Pattern:
```
POST /api/orders
Headers:
  Idempotency-Key: OIC-SAGA-{correlationId}-STEP-{stepNumber}
  X-Correlation-Id: {correlationId}
```

### OIC Gen 3 Implementation:
In each Invoke action's request header mapping:
```
Idempotency-Key  →  concat("OIC-SAGA-", $v_correlationId, "-STEP-1")
X-Correlation-Id →  $v_correlationId
```

### At the Target System:
The target API must:
1. Store the `Idempotency-Key` with the result on first invocation.
2. On subsequent calls with the same key, return the cached result without re-executing.

---

## 5. Saga State Persistence for Long-Running Workflows

For sagas that span hours or days (e.g., approval workflows), persist saga state to an **Autonomous Database (ATP)** table:

```sql
CREATE TABLE OIC_SAGA_STATE (
    SAGA_ID           VARCHAR2(100)  PRIMARY KEY,
    CORRELATION_ID    VARCHAR2(100)  NOT NULL,
    PROJECT_NAME      VARCHAR2(100)  NOT NULL,
    INTEGRATION_NAME  VARCHAR2(100)  NOT NULL,
    CURRENT_STEP      VARCHAR2(50),
    SAGA_STATUS       VARCHAR2(20)   DEFAULT 'IN_PROGRESS',
    STEP1_STATUS      VARCHAR2(20),
    STEP1_COMP_KEY    VARCHAR2(200),
    STEP2_STATUS      VARCHAR2(20),
    STEP2_COMP_KEY    VARCHAR2(200),
    STEP3_STATUS      VARCHAR2(20),
    STEP3_COMP_KEY    VARCHAR2(200),
    PAYLOAD_REF       VARCHAR2(500),
    CREATED_AT        TIMESTAMP      DEFAULT SYSTIMESTAMP,
    UPDATED_AT        TIMESTAMP,
    CONSTRAINT chk_status CHECK (SAGA_STATUS IN ('IN_PROGRESS','COMPLETED','COMPENSATING','FAILED','MANUAL_REVIEW'))
);
```

### Recovery Integration:
Build a scheduled integration (`SAGA_RECOVERY_PROCESSOR`) that:
1. Queries `SAGA_STATUS = 'COMPENSATING'` or stale `IN_PROGRESS` records (> 2 hours old).
2. Re-attempts compensation for each incomplete saga.
3. Escalates to `MANUAL_REVIEW` after 3 failed compensation attempts.
