# OIC Gen 3 Production Hardening Checklist (30-Point)

> This checklist goes beyond the basics. It covers architecture, anti-pattern elimination, saga readiness, observability wiring, AI capabilities, and operational preparedness. Complete every item before promoting to Production.

---

## 1. Architecture & Decomposition (6 points)

- [ ] **1. Project Encapsulation**: Every integration belongs to a named Gen 3 Project. No orphaned/unassigned integrations exist on the instance.
- [ ] **2. Layer Separation**: The integration landscape follows the 3-layer API-led topology (Experience → Process → System). No Experience layer integration directly calls a backend adapter.
- [ ] **3. Single Responsibility**: Each integration does exactly one thing. No "God Integrations" with 50+ actions touching 3+ systems.
- [ ] **4. Child Integration Decomposition**: Complex workflows are orchestrated via parent/child integrations. Each child is independently testable and reusable.
- [ ] **5. Event-Driven Decoupling**: Asynchronous fan-out uses Gen 3 Events (Pub/Sub), not direct integration-to-integration invocations. Publishers don't know or depend on their subscribers.
- [ ] **6. Sync Latency Guardrail**: All synchronous REST APIs respond within 3 seconds under normal load. Workflows exceeding this threshold use the Sync Facade + Async Worker pattern.

---

## 2. Anti-Pattern Elimination (6 points)

- [ ] **7. No Chatty Loops**: No `For-Each` loop makes individual API calls per record. All loops use batch/bulk APIs or Stage File accumulation.
- [ ] **8. No Unbounded File Reads**: Every `Stage File: Read File` action on external/variable-size files uses **"Read File in Segments"** (200–500 records). "Read Entire File" is only used on files with guaranteed small, known sizes.
- [ ] **9. No Global Variable Mutation in Loops**: No `Assign` action modifies a global variable inside a `For-Each` loop. Scope variables or Stage File append are used instead.
- [ ] **10. No String Concatenation Accumulation**: No `concat()` loop builds large strings in memory. Output is written to disk via Stage File append.
- [ ] **11. No Hardcoded Values**: Zero environment-specific values (URLs, directories, emails, thresholds, credentials) appear in mappers, assignments, or JavaScript. All use Gen 3 Configurable Properties.
- [ ] **12. No Empty Fault Handlers**: Every Global Fault Handler has at minimum: log → cleanup → alert → return/rethrow. No blank handlers exist.

---

## 3. Error Handling & Resilience (6 points)

- [ ] **13. Scope-Level Fault Handlers**: Every external invocation (REST, SOAP, DB, FTP, ERP Adapter) is wrapped in a Scope with a dedicated fault handler.
- [ ] **14. Transient vs. Non-Transient Classification**: Retry logic with exponential backoff (10s → 20s → 40s, max 3 retries) is configured for transient faults (429, 502, 503, 504). Non-transient faults (400, 401, 404, 422) fail fast without retry.
- [ ] **15. RFC 7807 Error Responses**: All synchronous REST triggers return standardized error responses with `type`, `title`, `status`, `detail`, `correlationId`, and `timestamp`.
- [ ] **16. Dead Letter Queue (DLQ)**: Failed async/batch transactions are persisted to an ATP table or OCI Queue with full payload, error context, and `PENDING_RETRY` status. A scheduled replay integration exists.
- [ ] **17. Saga Compensation Logic**: Multi-system orchestrations implement the Saga pattern with boolean state tracking and reverse-order compensating transactions in the Global Fault Handler.
- [ ] **18. Idempotency Keys**: Every downstream API call includes an `Idempotency-Key` header derived from the correlation ID + step number. Retries do not create duplicate records.

---

## 4. Security & Network (4 points)

- [ ] **19. OAuth 2.0 Inbound Authentication**: All inbound REST triggers enforce OAuth 2.0 (Client Credentials Grant) via OCI Identity Domains. Basic Authentication is disabled.
- [ ] **20. PII/Sensitive Data Masking**: Field masking is enabled for all sensitive fields (SSN, credit card, salary, passwords) in the integration tracking configuration. `Audit Level` is set to `Normal` or `Minimal` in Production.
- [ ] **21. Credential Governance**: All API keys, passwords, and OAuth secrets are stored in OIC Connection definitions or OCI Vault. No credentials appear in Activity Stream logs, mapper expressions, or JavaScript libraries.
- [ ] **22. Network Connectivity**: OCI Private Endpoints are used for ATP/OCI resources. Connectivity Agents for on-prem systems are deployed as HA dual-node clusters with JVM heap: `-Xms2048m -Xmx4096m`.

---

## 5. Observability & Monitoring (5 points)

- [ ] **23. Business Tracking Identifiers**: All 3 tracking slots are populated (Primary: unique business key like `OrderNumber`; Secondary 1: customer/partner ID; Secondary 2: source system/channel).
- [ ] **24. Correlation ID Propagation**: `X-Correlation-Id` is extracted from inbound requests (or generated), propagated through all downstream invocations, and included in all error logs and responses.
- [ ] **25. OCI Activity Stream Logging Enabled**: Activity Stream logs flow to OCI Logging → OCI Logging Analytics for search, correlation, and trend analysis.
- [ ] **26. OCI Monitoring Alarms Configured**: Alarms exist for: high error rate (>5%), critical integration failure (>0), high latency (P99 > 10s), and connectivity agent down.
- [ ] **27. OCI Notifications Wired**: Alarm triggers dispatch to OCI Notification topics → Slack/Teams webhooks, PagerDuty, or email distribution lists.

---

## 6. Governance & Operational Readiness (3 points)

- [ ] **28. Project Archive Versioned in Git**: The complete `.par` project archive is committed to version control (GitHub/GitLab/OCI DevOps) with semantic version tags and release notes.
- [ ] **29. Deployment Profiles Configured**: Gen 3 Deployment Profiles exist for each target environment (DEV, TEST, PROD), pre-mapping connection properties and configurable property values.
- [ ] **30. Operational Runbook Documented**: A runbook exists for each critical integration covering: purpose, trigger type, schedule, upstream/downstream owners, SLA, error escalation path, and recovery steps. Linked to the OCI Notification topic.
