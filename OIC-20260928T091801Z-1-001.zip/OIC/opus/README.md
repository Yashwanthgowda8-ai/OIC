# OIC Gen 3 Architecture Mastery — by Claude Opus

> **Philosophy**: The best integration architecture is invisible. It doesn't draw attention to itself — it just works, recovers from failures gracefully, and scales without human intervention.

---

## 📁 Repository Structure

```text
opus/
├── SKILL.md                                     # Master Gen 3 skill — anti-patterns, sagas, API-led, AI
├── README.md                                    # This file — overview and differentiation summary
├── references/
│   ├── anti-patterns-catalog.md                 # 12 anti-patterns with root cause analysis & OIC Gen 3 fixes
│   ├── saga-compensation-patterns.md            # Saga orchestration blueprints, compensation matrices, idempotency
│   ├── api-led-topology.md                      # 3-layer project architecture, versioning, OCI API Gateway
│   ├── observability-and-runbooks.md            # Full OCI stack wiring, 4 incident response runbooks
│   └── production-hardening-checklist.md        # 30-point verification (vs Gemini's 25)
└── .agents/skills/oic-gen3-mastery/             # Discoverable Antigravity skill bundle
    ├── SKILL.md
    └── references/ (copies)
```

---

## 🧠 What Makes the Opus Approach Different

| Dimension | Gemini's Focus | Opus's Focus |
| :--- | :--- | :--- |
| **Core Framing** | Pattern catalog (what to build) | Anti-pattern catalog (what NOT to build) + patterns |
| **Error Handling** | 3-tier fault + RFC 7807 + backoff | Same foundation + **Saga/Compensation** patterns with decision matrices |
| **Architecture** | Pattern selection matrix (Sync/Async/Batch) | **API-Led 3-Layer Topology** (Experience→Process→System) mapped to Gen 3 Projects |
| **Observability** | Activity Stream mention | Full **OCI Observability Stack** wiring (Logging→Analytics→Alarms→Notifications→Insight) |
| **Operations** | Production readiness checklist (25 items) | **Incident response runbooks** (4 scenarios) + hardened checklist (30 items) |
| **AI Capabilities** | Not covered | **AI Document Understanding, Mapping Suggestions, Agentic AI (MCP)** |
| **Versioning** | Naming conventions | **API versioning lifecycle** + OCI API Gateway integration |
| **Distributed Tx** | Not covered | **Saga orchestrator blueprint** with state persistence DDL |

---

## ⚡ Quick Reference — The Opus Principles

### 1. Think in Layers, Not in Flows
- **Experience Layer** (`EXP_*`): Consumer-facing REST facades — thin, shaped, rate-limited.
- **Process Layer** (`PROC_*`): Business orchestration — sagas, enrichment, event publishing.
- **System Layer** (`SYS_*`): Atomic backend adapters — one per system, idempotent, retry-aware.
- **Shared Layer** (`SHARED_*`): Error handling, notifications, audit logging.

### 2. Start With Anti-Patterns
Before designing anything, verify you're not building:
- 🚫 A chatty loop (N+1 HTTP calls)
- 🚫 A synchronous chain (cascading timeout bomb)
- 🚫 A God Integration (monolith with 200+ actions)
- 🚫 An unbounded Read Entire File (OOM grenade)
- 🚫 A global variable mutator inside a loop (GC killer)
- 🚫 An empty Global Fault Handler (silent failure)

### 3. Design for Failure (Sagas)
- Every multi-system orchestration uses the Saga pattern.
- Track step state with boolean scope variables.
- Compensate in reverse order in the Global Fault Handler.
- Every downstream call carries an idempotency key.

### 4. Observe Everything
- Wire: OIC → OCI Logging → OCI Logging Analytics → OCI Alarms → OCI Notifications.
- Build OIC Insight models for business KPIs (cycle time, stuck orders, SLA breaches).
- Propagate `X-Correlation-Id` through every layer for end-to-end tracing.

### 5. Ship AI-Augmented
- Use AI Mapping Suggestions on every mapping action.
- Use Document Understanding for invoice/receipt processing.
- Expose integrations as AI Agent Tools (MCP) for agentic workflows.

---

## 🔗 Deep-Dive References

| Reference | What You'll Learn |
| :--- | :--- |
| [Anti-Patterns Catalog](./references/anti-patterns-catalog.md) | 12 anti-patterns with severity ratings, memory math, and step-by-step fixes |
| [Saga & Compensation Patterns](./references/saga-compensation-patterns.md) | Orchestration saga blueprints, compensation decision matrices, ATP state table DDL |
| [API-Led Topology & Versioning](./references/api-led-topology.md) | 3-layer project structure, naming, API versioning lifecycle, OCI API Gateway |
| [Observability & Runbooks](./references/observability-and-runbooks.md) | Full OCI stack setup, 4 incident response runbooks, correlation ID propagation |
| [Production Hardening Checklist](./references/production-hardening-checklist.md) | 30-point go-live verification across architecture, resilience, security & ops |
