---
name: oic-gen3-master-architect
description: >-
  The definitive, enterprise-grade Oracle Integration Cloud Gen 3 (OIC Gen 3) Architecture Master Skill.
  Synthesizes industry-leading integration patterns, 3-layer API-led topology, distributed saga and compensation orchestration,
  exhaustive 12 anti-pattern avoidance catalog, 3-tier fault resilience with RFC 7807, JVM memory and platform limits tuning,
  full OCI observability stack wiring with 4 operational runbooks, native AI augmentation (Document Understanding & Agentic MCP),
  and a 35-point production hardening checklist.
---

# Oracle Integration Cloud (OIC Gen 3) Master Architecture Blueprint

> **Enterprise Architecture Doctrine**: An exceptional integration platform is reliable, observable, idempotent, and invisible. It absorbs downstream instability, isolates faults within bounded contexts, auto-compensates distributed transactions, and scales predictably under high volume.

---

## 1. The Core Mental Model: 3-Layer API-Led Project Fabric

In OIC Gen 3, **Projects** (`.par`) are the fundamental boundary of encapsulation, governance, team ownership, and lifecycle delivery. Never build loose or unassigned integrations. Organize all enterprise integration assets into a **3-Layer API-Led Architecture**:

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                           EXPERIENCE LAYER (EXP_*)                            │
│  Consumer-Specific APIs: Visual Builder (VBCS), Mobile Apps, Portals, B2B     │
│  ● Thin REST facades             ● Strict response shaping & filtering       │
│  ● Rate-limited via API Gateway  ● OAuth 2.0 Client Credentials Grant        │
│  ● SLA: Sub-3-second response    ● Never directly invokes System adapters    │
├───────────────────────────────────────────────────────────────────────────────┤
│                                     │ calls via HTTPS REST                    │
│                                     ▼                                         │
│                            PROCESS LAYER (PROC_*)                             │
│  Business Process Orchestration & Distributed Workflow Brains                │
│  ● Distributed Saga Coordinator  ● Reverse-Order Compensating Transactions    │
│  ● Data enrichment & aggregation ● Gen 3 Native Event Mesh (Pub/Sub)         │
│  ● Parallel Fan-out / Fan-in     ● Correlation ID (X-Correlation-Id) tracking │
│  ● State persistence in ATP      ● Never directly exposed to public clients   │
├───────────────────────────────────────────────────────────────────────────────┤
│                                     │ calls via REST / Adapters               │
│                                     ▼                                         │
│                            SYSTEM LAYER (SYS_*)                               │
│  Atomic, Idempotent Adapters Wrapping Core Systems of Record                  │
│  ● Oracle Fusion ERP / HCM / SCM ● Salesforce / ServiceNow / SAP             │
│  ● Autonomous DB (Private EP)    ● SFTP / Object Storage / Kafka             │
│  ● Encapsulates system quirks    ● Internal retries & pagination baked in    │
│  ● Idempotency-Key enforcement   ● Zero business logic (pure CRUD / RPC)     │
├───────────────────────────────────────────────────────────────────────────────┤
│                            SHARED LAYER (SHARED_*)                            │
│  Cross-Cutting Governance Services Used Across All Layers                     │
│  ● SHARED_ErrorHandling_Project  (Centralized DLQ & Alert Notification)       │
│  ● SHARED_AuditLog_Project       (Compliance & Long-term Audit Storage)       │
│  ● SHARED_Notifications_Project  (Slack / Teams / PagerDuty / Email Dispatch)│
└───────────────────────────────────────────────────────────────────────────────┘
```

### Layer Project Naming Standard:
| Layer | Project Prefix | Project Example | Primary Integration Example |
| :--- | :--- | :--- | :--- |
| **Experience** | `EXP_` | `EXP_CustomerPortal_Project` | `EXP_PORTAL_GET_ORDER_STATUS_v1` |
| **Process** | `PROC_` | `PROC_OrderToCash_Project` | `PROC_OTC_ORDER_FULFILLMENT_SAGA` |
| **System** | `SYS_` | `SYS_FusionERP_Project` | `SYS_ERP_CREATE_AP_INVOICE_v1` |
| **Shared** | `SHARED_` | `SHARED_CommonServices_Project`| `SHARED_ERR_DLQ_PROCESSOR` |

---

## 2. Master Architectural Pattern Decision Matrix

```
                                    [Incoming Trigger]
                                             |
                   +-------------------------+-------------------------+
                   |                                                   |
           [Low Latency / Sync]                                [High Volume / Batch / Async]
                   |                                                   |
           Payload < 10 MB?                                    Processing SLA > 5 Seconds?
          /                \                                  /                           \
       [YES]               [NO]                            [YES]                          [NO]
         |                   |                               |                              |
[Pattern 1: Sync REST] [Stream via Object Storage]   Need Client Ack?               Scheduled File?
(SLA < 3s, Max 300s)   (Stage File in Segments)     /                \             /               \
                                                 [YES]               [NO]       [YES]              [NO]
                                                   |                   |          |                  |
                                         [Pattern 2: Sync      [Pattern 3:   [Pattern 4: Batch   [Pattern 6:
                                          Facade + Event Worker] Event Mesh]  Streaming Chunk]   Parallel Action]
```

### The 6 Core Integration Blueprints:
1. **Synchronous REST API**: Low-latency interactive lookups (SLA < 3s). Always wrap in Scopes and return RFC 7807 Problem Details.
2. **Sync Facade + Event Worker**: The ultimate offloading pattern. Return `HTTP 202 Accepted` with a correlation ID and status URL in < 200ms; delegate execution to an asynchronous Event Worker.
3. **Native Gen 3 Event Mesh (Pub/Sub)**: Zero-broker decoupling. Publishers emit past-tense facts (`Order_Placed_Event`); multiple independent subscribers react without tight coupling.
4. **Scheduled Batch Streaming**: Process multi-megabyte / gigabyte files without JVM OOM by using `Stage File: Read File in Segments` (100–500 records per chunk) and strict `Delete File` cleanup.
5. **Oracle Fusion Cloud FBDI & HDL**: End-to-end bulk automation using native Oracle ERP Cloud adapter `importBulkData`, event-driven callbacks, and automatic execution log parsing.
6. **Parallel Action (Fan-Out / Fan-In)**: Execute independent outbound calls concurrently to slash wall-clock latency, joining results before mapping.

---

## 3. The Anti-Pattern Radar (Top 6 Critical Traps)

Before implementing any flow, verify your design eliminates these performance and stability killers:

| Anti-Pattern | Root Cause & Mechanism | Architectural Remedy |
| :--- | :--- | :--- |
| **1. The Chatty Loop** | Making 1 HTTP call per record inside a `For-Each` loop (10,000 records = 10,000 HTTP round-trips = 33+ min). | Batch into segments of 100–500 records and call bulk/batch endpoints. |
| **2. Synchronous Chain** | Cascading serial calls (Client → CRM → ERP → WMS) accumulating latency and risking partial failures. | Sync Facade returns `202 Accepted`; Process layer coordinates downstream calls asynchronously. |
| **3. Monolithic God Flow** | Single integration with 100+ actions handling validation, multi-system posting, and notification. | Decompose into single-responsibility child integrations orchestrated by a parent. |
| **4. Unbounded "Read Entire File"** | Loading unknown/large files into JVM heap memory. A 50 MB CSV expands to 250–500 MB DOM → OOM. | **Always** use `Stage File: Read File in Segments` (100–500 records/chunk). |
| **5. Global Variable Loop Mutation** | Mutating global variables inside a loop creates an immutable state snapshot per iteration → GC death. | Use **Scope-level variables** or write chunked records to disk via Stage File Append. |
| **6. Empty Global Fault Handler** | Blank catch-all causing silent transaction drops without operational logging or alerts. | Minimum 4 actions: (1) Log fault, (2) Clean temp files, (3) Publish error event, (4) Return RFC 7807. |

*(See [Anti-Patterns Catalog](./references/02-anti-patterns-and-remediation.md) for all 12 patterns).*

---

## 4. Distributed Saga & Compensation Architecture

When an integration updates multiple distributed backends (e.g. WMS, Payment Gateway, ERP), traditional ACID two-phase commit is impossible. Implement the **Orchestration Saga Pattern**:

```
                         ┌─────────────────────────────────────────┐
                         │   PROC_OrderToCash_Saga (Orchestrator)  │
                         └────────────────────┬────────────────────┘
                                              │
              FORWARD FLOW                    │              COMPENSATION FLOW (REVERSE)
      ┌───────────────────────────┐           │        ┌──────────────────────────────────┐
      │ Step 1: Reserve Inventory │ ──────────┼──────► │ Undo 1: Release Inventory API    │
      │   v_inventoryReserved=true│           │        │   (Triggered if Step 2 or 3 fails│
      └─────────────┬─────────────┘           │        └──────────────────────────────────┘
                    │                         │                         ▲
                    ▼                         │                         │
      ┌───────────────────────────┐           │        ┌────────────────┴─────────────────┐
      │ Step 2: Authorize Payment │ ──────────┼──────► │ Undo 2: Refund / Void Payment    │
      │   v_paymentCharged=true   │           │        │   (Triggered if Step 3 fails)    │
      └─────────────┬─────────────┘           │        └──────────────────────────────────┘
                    │                         │                         ▲
                    ▼                         │                         │
      ┌───────────────────────────┐           │                         │
      │ Step 3: Create ERP Order  │ ──────────┴─────────────────────────┘
      │   v_erpCreated=true       │        ✘ FAILS! Escalates to Global Fault Handler
      └───────────────────────────┘
```

### Mandatory Saga Guardrails:
1. **Scope Boolean State Flags**: Track forward progress with Scope variables (`v_step1_success`, `v_step2_success`).
2. **Reverse Compensation**: The Global Fault Handler evaluates state flags in reverse sequence and executes compensating API calls.
3. **Idempotency Key Propagation**: Every downstream call carries `Idempotency-Key: OIC-SAGA-{correlationId}-STEP-{n}` to guarantee safe retries.
4. **State Persistence**: For long-running business sagas (> 5 min), persist transaction progress to an Autonomous Database (`OIC_SAGA_STATE`) for automated recovery.

---

## 5. Enterprise Resilience & 3-Tier Fault Framework

```
┌───────────────────────────────────────────────────────────────────────────────┐
│ TIER 3: COMMON ERROR HANDLING SERVICE (SHARED_ErrorHandling_Project)          │
│ ● Subscribed to System_Fault_Occurred_Event or invoked via Async REST         │
│ ● Persists failed payload & error context to Autonomous DB (OIC_ERROR_LOG)   │
│ ● Dispatches alert to PagerDuty / Slack / MS Teams / Email                    │
│ ● Automated re-submission processor integration polls and replays DLQ         │
└───────────────────────────────────────▲───────────────────────────────────────┘
                                        │ Publishes Event or Async REST
┌───────────────────────────────────────┴───────────────────────────────────────┐
│ TIER 2: INTEGRATION GLOBAL FAULT HANDLER (Integration-Level Catch-All)        │
│ ● Traps unhandled faults escaping scopes                                      │
│ ● Executes reverse compensation (Saga rollback) & deletes temporary files    │
│ ● Canonical RFC 7807 Problem Details response for synchronous REST triggers   │
│ ● Dispatches error payload to Tier 3 Common Error Service                     │
└───────────────────────────────────────▲───────────────────────────────────────┘
                                        │ Escalates Unhandled Faults
┌───────────────────────────────────────┴───────────────────────────────────────┐
│ TIER 1: SCOPE-LEVEL FAULT HANDLERS (Localized Component Resilience)           │
│ ● Wraps risky invokes (REST, SOAP, DB, ERP, FTP)                              │
│ ● Classifies transient faults (429, 502, 503, 504) vs non-transient (400, 422)│
│ ● Executes Exponential Backoff with Jitter (10s -> 20s -> 40s, max 3 retries) │
│ ● Swallows benign errors or supplies fallback cached/default values           │
└───────────────────────────────────────────────────────────────────────────────┘
```

### Canonical RFC 7807 Error Response Schema:
```json
{
  "type": "https://api.enterprise.com/errors/ORDER_VALIDATION_FAILED",
  "title": "Unprocessable Entity",
  "status": 422,
  "detail": "Customer credit limit exceeded for AccountNumber 'ACC-88219'.",
  "instance": "/ic/api/integration/v1/flows/rest/EXP_ORDER_FACADE/1.0/instances/992810",
  "code": "OIC-VAL-422",
  "correlationId": "CORR-77a8-44b2-901c",
  "timestamp": "2026-09-27T01:30:00Z"
}
```

---

## 6. Full OCI Observability Stack & Incident Runbooks

Never fly blind. Wire OIC Gen 3 into the complete OCI Observability fabric:

```
[OIC Gen 3 Instance]
        │
        ├── Activity Stream Logs ──► [OCI Logging] ──► [OCI Logging Analytics]
        │                                                     │
        │                                            Custom Dashboards &
        │                                            Fleet Search by Correlation ID
        │
        └── Runtime Service Metrics ─► [OCI Monitoring]
                                              │
                                     Alarms on Thresholds:
                                     • FailedMessages > 5%
                                     • ProcessingTime P99 > 10s
                                     • ConnectivityAgentStatus != ACTIVE
                                              │
                                              ▼
                                   [OCI Notification Topic]
                                              │
                         ┌────────────────────┼────────────────────┐
                         ▼                    ▼                    ▼
                   [PagerDuty P1]      [Slack #ops-alerts]    [Email Ops List]
```

### Master Runbooks Overview:
- **Runbook 1: Critical Integration Instance Failure (P1)**: Triage in 5 min, diagnose fault classification, execute saga rollback, and resubmit from DLQ.
- **Runbook 2: Connectivity Agent Outage & Host Recovery**: Verify HA group status, inspect agent logs (`agent-diagnostics.log`), adjust JVM heap (`-Xms2048m -Xmx4096m`), and re-register.
- **Runbook 3: Integration Performance Degradation & Latency Spikes**: Pinpoint slow actions (external invoke vs XSLT vs Stage File), apply XSLT `<xsl:key>` or batching, deploy fix.
- **Runbook 4: FBDI Bulk Import Partial Rejection Reconciliation**: Extract ESS execution log ZIP, parse bad-records CSV, validate foreign keys, and trigger delta import.

---

## 7. AI-Augmented Integration Capabilities (2025+)

Leverage OIC Gen 3 native AI features directly in the integration canvas:
1. **AI Document Understanding Action**: Native drag-and-drop action to extract structured key-value pairs, line-item tables, and text from unstructured PDF/TIFF invoices and receipts.
2. **Intelligent Mapping Suggestions**: AI-recommended field mappings based on schema semantic similarity and enterprise mapping history.
3. **Natural Language Project Scaffolding**: Generate integration skeletons, connections, and documentation using natural language prompts.
4. **Agentic AI & Model Context Protocol (MCP)**: Expose OIC integration flows as callable tools for autonomous AI agents, with Human-in-the-Loop approval milestones.

---

## 8. Master Reference Manuals Index

Consult the full suite of deep-dive reference manuals in [`master/references/`](./references/):

| Manual | Key Coverage |
| :--- | :--- |
| [01. Architectural Patterns & Topologies](./references/01-enterprise-architectural-patterns.md) | 3-layer topology, 6 complete integration blueprints with ASCII flow diagrams. |
| [02. Anti-Patterns & Remediation Catalog](./references/02-anti-patterns-and-remediation.md) | 12 production anti-patterns with severity, JVM memory math, and code fixes. |
| [03. Distributed Sagas & Compensation](./references/03-distributed-sagas-and-compensation.md) | Orchestration saga blueprints, compensation matrix, ATP state table DDL. |
| [04. Enterprise Fault Handling & Resilience](./references/04-enterprise-fault-handling-and-resilience.md) | 3-tier fault architecture, backoff with jitter, RFC 7807 specs, DLQ schema. |
| [05. Performance, Memory & Platform Limits](./references/05-performance-memory-and-platform-limits.md) | Platform limits matrix, XSLT keys indexing, ES6+ JS libraries, Private Endpoints. |
| [06. Observability, Alarms & Runbooks](./references/06-observability-alarms-and-runbooks.md) | OCI Logging Analytics wiring, alarms, OIC Insight, 4 incident runbooks. |
| [07. Governance, CI/CD & API Management](./references/07-governance-cicd-and-api-management.md) | Project packaging (`.par`), Configurable Properties, API Gateway, REST CI/CD. |
| [08. AI-Augmented Integration & MCP](./references/08-ai-augmented-integration-and-agentic-tools.md) | Document Understanding, AI mapping, Agentic AI tools, approval workflows. |
| [09. Definitive Go-Live Checklist (35-Point)](./references/09-master-production-hardening-checklist.md) | The ultimate 35-point enterprise readiness verification checklist. |
