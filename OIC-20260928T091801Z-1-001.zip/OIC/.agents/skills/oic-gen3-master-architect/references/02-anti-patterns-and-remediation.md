# OIC Gen 3 Anti-Patterns & Remediation Catalog

> An architectural catalog of 12 real-world production integration anti-patterns, analyzing root-cause mechanisms, JVM heap memory mechanics, and concrete OIC Gen 3 remediations.

---

## Anti-Pattern Index & Severity Matrix

| # | Anti-Pattern Name | Severity | Primary Failure Mode | Section |
| :--- | :--- | :--- | :--- | :--- |
| **1** | The Chatty Loop (N+1 Problem) | 🔴 Critical | Network latency multiplication & endpoint rate-limiting | §1 |
| **2** | Synchronous Chain (Timeout Cascade) | 🔴 Critical | Cumulative latency SLA breach & partial uncompensated commits | §2 |
| **3** | The Monolithic God Flow | 🟠 High | Unmaintainable canvas, state bloat, impossible unit testing | §3 |
| **4** | Unbounded "Read Entire File" | 🔴 Critical | JVM Heap exhaustion (`OutOfMemoryError`) & pod restart | §4 |
| **5** | Global Variable Loop Mutation | 🔴 Critical | Immutable state snapshot explosion & Garbage Collection thrashing | §5 |
| **6** | Empty Global Fault Handler | 🟠 High | Silent data drop, zero alerting, untracked failure | §6 |
| **7** | Hardcoded Environment Configuration | 🟠 High | Broken CI/CD promotions across DEV / TEST / PROD | §7 |
| **8** | Debug Audit Level in Production | 🟡 Medium | Tenant scratch disk exhaustion & PII compliance leakage | §8 |
| **9** | Unclassified Blind Retry Loop | 🟠 High | Denial of Service on downstream API during outage | §9 |
| **10** | Orphaned Stage Files | 🟡 Medium | Scratch disk quota exhaustion (50 GB tenant limit) | §10 |
| **11** | Tight Coupling via Direct Invocation | 🟠 High | Cascading downtime & deployment lockstep | §11 |
| **12** | Ignoring FBDI Execution Logs | 🟠 High | Silent business data loss in Fusion ERP interface tables | §12 |

---

## §1. The Chatty Loop (The N+1 Inversion)

### The Code Smell:
```
[For-Each OrderLine in Order (10,000 items)]
    └── [Invoke: POST /api/v1/inventory/check  <-- One HTTP request per line]
```

### The Math:
- 10,000 records × 200ms average round-trip latency = **2,000 seconds (33.3 minutes)** execution time.
- Most enterprise cloud APIs (Oracle Fusion REST, Salesforce, ServiceNow) enforce rate limits (e.g. 1,000–1,200 requests/minute). At record #1,200, the client receives `HTTP 429 Too Many Requests`.

### The Gen 3 Remediation:
1. **Chunking**: Use `Stage File: Read File in Segments` (250–500 records per segment).
2. **Bulk Endpoint**: Map the 500 records into a single bulk array payload (`POST /api/v1/inventory/batch-check`).
3. **Result**: 10,000 records ÷ 500 per batch = 20 HTTP requests ≈ 4 seconds total execution.

---

## §2. Synchronous Chain (The Timeout Cascade)

### The Code Smell:
```
[Client Call] ---> [OIC REST Trigger]
                         |---> [Invoke CRM API: 2.5s]
                         |---> [Invoke ERP API: 3.8s]
                         |---> [Invoke WMS API: 4.2s]
                         |---> [Invoke Billing API: 2.1s]
[Client Call] <--- [Return Response: Total 12.6s]
```

### The Failure Mode:
- Latencies are additive. If WMS experiences a temporary database lock and takes 25 seconds, total latency hits 35+ seconds.
- The calling application or intermediate API Gateway times out at 30 seconds.
- The client receives an `HTTP 504 Gateway Timeout`, but CRM and ERP operations have already committed. You now have a **corrupted distributed state with zero compensation**.

### The Gen 3 Remediation:
- Convert to **Sync Facade + Event Worker (Pattern 2)**.
- Respond with `HTTP 202 Accepted` and a `trackingId` in < 200ms.
- Let the Process layer coordinate the downstream calls asynchronously with full saga compensation.

---

## §3. The Monolithic God Flow

### Diagnostic Indicators:
- Canvas contains 60+ actions with 5+ levels of nested `If-Else` / `Switch` branching.
- Interacts with more than 3 distinct backend systems.
- Takes 45+ seconds just to open in the OIC Gen 3 designer canvas.

### The Gen 3 Remediation:
Decompose into an orchestrator and atomic child integrations:
- **`PROC_OrderToCash_Orchestrator`**: Contains high-level business workflow and saga state logic.
- **`SYS_ERP_CreateOrder`**: Pure system adapter encapsulating ERP payload structure.
- **`SYS_CRM_UpdateStatus`**: Pure system adapter for CRM updates.

---

## §4. Unbounded "Read Entire File"

### The Memory Math:
| File Size on Disk | XML/JSON DOM Expansion in Heap | Impact on OIC Pod Heap |
| :--- | :--- | :--- |
| **5 MB** | ~35 MB – 50 MB | Low overhead |
| **20 MB** | ~140 MB – 200 MB | GC pause, memory pressure warning |
| **50 MB** | ~350 MB – 500 MB | **Severe GC thrashing / High OOM Risk** |
| **100 MB+** | ~700 MB – 1.2 GB | **Guaranteed `OutOfMemoryError` & Pod Crash** |

### The Gen 3 Remediation:
- **Rule**: `Stage File: Read Entire File` is ONLY permitted for static, known files < 5 MB (e.g. metadata templates).
- For all external, SFTP-sourced, or variable-size files, **always use "Read File in Segments"** with segment size set between 100 and 500 records.

---

## §5. Global Variable Mutation Inside Loops

### The Immutable State Trap:
In OIC Gen 3, the engine maintains state immutability for tracking and activity streams. When an `Assign` action modifies a global variable inside a loop:
```
Iteration 1: Engine clones state snapshot (Snapshot #1)
Iteration 2: Engine clones state snapshot (Snapshot #2)
...
Iteration 5,000: Engine clones state snapshot (Snapshot #5,000)
```
5,000 snapshots × ~40 KB each = **200 MB of heap memory** that cannot be garbage collected until the loop finishes!

### The Gen 3 Remediation:
1. **Scope Variables**: Use variables defined at the Scope level inside the loop body. Their memory is freed at the end of each iteration.
2. **Disk Streaming**: Use `Stage File: Write File` with **"Append to existing file"** checked to accumulate output on disk rather than in memory.

---

## §6. Empty Global Fault Handler

### The Failure Mode:
A blank Global Fault Handler swallows exceptions silently. The integration finishes with status `COMPLETED`, but no records were processed, no error was logged, and no alert was sent to the operations team.

### The Gen 3 Remediation (Mandatory 4-Step Handler):
```
[GLOBAL FAULT HANDLER]
   |
   |-- 1. [Assign / Log]: Record $fault.code, $fault.reason, and X-Correlation-Id
   |-- 2. [Stage File]: Execute "Delete File" on all scratch files
   |-- 3. [Action]: Publish "System_Fault_Occurred_Event" to SHARED_ErrorHandling
   |-- 4. [Return / Rethrow]: Return RFC 7807 problem details (sync) or Rethrow (async)
```

---

## §7–§12 Quick Reference Matrix

| # | Anti-Pattern | Root Cause | Architectural Fix |
| :--- | :--- | :--- | :--- |
| **§7. Hardcoded Config** | URLs, directories, or emails typed into mappers or assignments. | Use **Project Configurable Properties** and **Integration Configurable Properties** overridden per environment. |
| **§8. Debug Audit in Prod** | Setting `Audit Level: Debug` in Production environments. | Set to `Audit Level: Normal` or `Minimal`. Restrict `Debug` to active P1 triage and disable within 60 minutes. |
| **§9. Unclassified Retries** | Retrying HTTP 400 Bad Request or 422 Unprocessable Entity 5 times. | Classify faults: **Transient** (429, 502, 503, 504) get backoff retries; **Non-Transient** (400, 401, 422) fail fast to DLQ. |
| **§10. Orphaned Stage Files** | Forgetting to delete temporary files created during Stage File operations. | Place `Stage File: Delete File` in the normal flow **and** inside all Fault Handlers. Run a weekly cleanup integration. |
| **§11. Tight Coupling** | Calling `Invoke Integration` directly between distinct business domains. | Replace point-to-point calls with **Gen 3 Native Event Mesh (Pub/Sub)** to decouple release cycles. |
| **§12. Ignoring FBDI Logs** | Relying solely on ESS Job status `SUCCEEDED` without inspecting results. | Download the ESS execution log ZIP, parse bad-records CSV, and notify business if rejected count > 0. |
