# OIC Gen 3 Master Enterprise Architectural Patterns

> Detailed architectural blueprints, flow diagrams, component wiring, and step-by-step implementation recipes strictly designed for **Oracle Integration Cloud Gen 3 (OIC Gen 3)**.

---

## 1. The 3-Layer API-Led Project Architecture

Organize your entire integration portfolio into three decoupled layers, each contained within dedicated **Gen 3 Projects**:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           EXPERIENCE LAYER (EXP_*)                          │
│                                                                             │
│  Purpose: Consumer-tailored REST APIs for UIs, Mobile Apps, Portals, B2B    │
│  - Response shaping: Returns only what the UI needs (e.g. 5 fields of 200)  │
│  - Protocol mediation: JSON/REST transformation for XML or partner clients  │
│  - Strictly enforced latency: Sub-3-second synchronous turnaround           │
│  - Guardrail: NEVER invokes a System adapter directly                       │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │ calls via HTTPS REST
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            PROCESS LAYER (PROC_*)                           │
│                                                                             │
│  Purpose: Business orchestration, saga coordination, and workflow brains    │
│  - Multi-system coordination: Orchestrates 2+ System APIs (ERP, CRM, WMS)   │
│  - State management: Manages transaction state and compensation logic       │
│  - Asynchronous fan-out: Publishes Gen 3 Events for decoupled subscribers   │
│  - Guardrail: NEVER exposed directly to external client applications        │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │ calls via REST / Adapters
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            SYSTEM LAYER (SYS_*)                             │
│                                                                             │
│  Purpose: Atomic, reusable adapters wrapping enterprise systems of record   │
│  - Encapsulates backend quirks: date formats, pagination, internal codes    │
│  - One Project per backend: SYS_FusionERP, SYS_Salesforce, SYS_Workday      │
│  - Built-in resilience: Retries, idempotency headers, rate-limit backoff    │
│  - Guardrail: Zero business logic (pure CRUD / RPC data abstraction)        │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Pattern 1: Real-Time Synchronous REST API

### Context & When to Use:
- Interactive user interfaces (Oracle Visual Builder / VBCS, custom React/Vue portals, mobile apps).
- Real-time synchronous queries (inventory stock check, address validation, real-time pricing calculation).
- Workflows where end-to-end latency is guaranteed to be **under 3 seconds**.

### Architecture Blueprint:
```
[Client App] ---> (HTTPS REST POST /orders/validate) ---> [Gen 3 REST Trigger]
                                                                |
                                                      [Validation Scope]
                                                      (Validate JSON Schema)
                                                                |
                                                      [Invoke System Layer API]
                                                      (Wrapped in Scope + Catch)
                                                                |
[Client App] <--- (HTTP 200 OK + Filtered JSON) <--- [Mapper to Response]
```

### Implementation Rules:
1. **Hard 300-Second Ceiling**: OIC Gen 3 enforces a hard synchronous timeout of 300 seconds. If downstream systems ever exceed 5 seconds under load, switch immediately to **Pattern 2**.
2. **Strict Payload Sizing**: Keep payloads < 5 MB (hard limit is 10 MB). For multi-record queries, enforce pagination using query parameters (`?limit=50&offset=0`).
3. **Structured RFC 7807 Error Handling**: Trap all downstream faults in a Scope fault handler and map them to standard RFC 7807 Problem Details (`400`, `404`, `422`, `502`). Never expose raw unhandled 500 stack traces.

---

## 3. Pattern 2: Sync Facade + Event Worker (The Offloading Pattern)

### Context & When to Use:
- A client needs immediate confirmation that a request has been received, but backend orchestration takes anywhere from 10 seconds to several hours (e.g., ERP sales order creation, complex payroll adjustments, multi-system onboarding).

### Architecture Blueprint:
```
Step 1: Immediate Handshake (Synchronous Facade - Latency < 200ms)
[Client App] ---> (POST /orders) ---> [Gen 3 REST Trigger]
                                             |
                                   [Generate Correlation ID]
                                   (ora:generateGUID())
                                             |
                                   [Action: Publish Event]
                                   ("Order_Submitted_Event")
                                             |
[Client App] <--- (HTTP 202 Accepted + StatusURL) ---+

Step 2: Asynchronous Orchestration (Process Layer Worker Integration)
[Gen 3 Event Trigger: "Order_Submitted_Event"]
       |
  [Validate Payload] ---> [Invoke SYS_CRM] ---> [Invoke SYS_ERP]
                                                      |
                                             [Update Status Store]
                                             (Status: COMPLETED)
```

### Response Contract (HTTP 202 Accepted):
```json
{
  "status": "ACCEPTED",
  "correlationId": "CORR-2026-99210-AB",
  "message": "Transaction accepted for asynchronous execution.",
  "statusUrl": "https://<oic-host>/ic/api/integration/v1/flows/rest/EXP_ORDER_STATUS_v1/1.0/orders/CORR-2026-99210-AB"
}
```

---

## 4. Pattern 3: Native Gen 3 Event Mesh (Cross-Project Pub/Sub)

### Context & When to Use:
- Decoupling multiple consuming systems from a single core business event without tight point-to-point integration links.
- Example: When an `Order_Placed_Event` is triggered, three independent integrations need to execute in parallel:
  1. Billing Service (Charge customer)
  2. Inventory Service (Reserve warehouse items)
  3. Notification Service (Send SMS / Email confirmation)

### Architecture Blueprint:
```
                       [PROC_OrderToCash_Project]
                                   |
                   [Action: Publish "Order_Placed_Event"]
                                   |
              =============================================
                    OIC GEN 3 NATIVE EVENT MESH BUS
              =============================================
                   /               |               \
                  /                |                \
  [Subscriber 1: Billing] [Subscriber 2: Inventory] [Subscriber 3: Notification]
  (PROC_Billing_Project)  (PROC_WMS_Project)       (SHARED_Notifications_Project)
```

### Architectural Advantages:
- **Zero External Infrastructure**: No need to provision OCI Streaming or Apache Kafka for standard internal workflow decoupling.
- **Independent Project Lifecycles**: Subscribers can be paused, updated, or redeployed without touching the publisher.
- **Guaranteed At-Least-Once Delivery**: The OIC Gen 3 Event runtime guarantees message delivery to all registered project subscribers.

---

## 5. Pattern 4: Scheduled Batch Streaming (Stage File Chunking)

### Context & When to Use:
- Ingesting massive data files (CSV, XML, Fixed-Width) from external SFTP servers or cloud storage ranging from 10 MB up to 1 GB (or 100,000+ records).

### The Golden Rule of Stage File:
> **Never use "Read Entire File" on files of unknown or variable size.** Always use **"Read File in Segments"** (100–500 records per chunk) to protect the JVM heap memory.

### Architecture Blueprint:
```
[Schedule Trigger]
       |
[FTP Adapter: Download File to Scratch Disk]
       |
[Stage File: Read File in Segments] (Chunk size: 250 records)
       |
[For-Each Segment]
       |---> [Mapper: Transform Chunk into Target Batch Payload]
       |---> [Target Adapter: Invoke Bulk Insert / Batch REST API]
       |---> [Assign: Increment Processed Record Counter]
       +--- (Iterate Next Segment)
       |
[Stage File: Delete File] (CRITICAL: In happy path AND Global Fault Handler)
       |
[Dispatch Summary Notification / Log Metrics]
```

---

## 6. Pattern 5: Oracle Fusion Cloud FBDI & HDL Mass Data Load

### Context & When to Use:
- Mass data loading into Oracle Fusion Cloud applications (ERP, HCM, SCM):
  - General Ledger Daily Rates, Journal Entries, AP Invoices, AR Transactions.
  - HCM Worker Data loads via HDL (HCM Data Loader).

### Architecture Blueprint:
```
[Inbound Source: SFTP / DB / Object Storage]
                    |
           [Stage File: Write CSV]
                    |
     [Stage File: Zip CSV + Manifest File]
                    |
 [Oracle ERP Cloud Adapter: "Import Bulk Data"]
                    |
   +----------------+----------------+
   |                                 |
[Option A: Event Callback]  [Option B: ESS Job Polling]
Fusion raises Business Event OIC polls ESS Job status via
when ESS Job completes       While loop (30s interval, max 20x)
   |                                 |
   +----------------+----------------+
                    |
    [Download ERP Execution Logs & Bad-Records CSV]
                    |
    [If Rejected Rows > 0 -> Send Business Alert to Finance]
```

### Critical Rules for FBDI:
1. **Always Check the Execution Log**: An ESS job status of `SUCCEEDED` only confirms the loader process ran. Interface tables may have rejected 50% of the rows due to invalid account codes. Always download the log ZIP and parse the bad-records CSV.
2. **Event Callback over Polling**: For bulk loads taking > 10 minutes, always use Fusion Business Event callbacks rather than holding open an OIC worker thread in a polling loop.

---

## 7. Pattern 6: High-Performance Parallel Action (Fan-Out / Fan-In)

### Context & When to Use:
- An orchestration flow must call 2 or more independent external services that have **no data dependencies** on each other (e.g. concurrently fetching Customer CRM Data, ERP Credit Limit, and Loyalty Tier).

### Architecture Blueprint:
```
                        [Inbound Request]
                                |
                     [Action: Parallel Branch]
                    /           |            \
                   /            |             \
         [Branch 1: CRM]  [Branch 2: ERP]  [Branch 3: Loyalty]
         Fetch Profile    Fetch Balances   Fetch Rewards
                   \            |             /
                    \           |            /
                     [Join & Merge in Mapper]
                                |
                     [Return Combined Response]
```

### Implementation Guardrails:
- Every branch must encapsulate its external invocation inside a **Scope with a dedicated Fault Handler**. A failure in Branch 3 (Loyalty) should be caught and defaulted rather than aborting Branch 1 and 2.
