# OCI Observability, Alarms & Incident Runbooks for OIC Gen 3

> Observability transforms reactive fire-fighting into proactive reliability engineering. This manual details how to wire OIC Gen 3 into the complete OCI Observability fabric and provides 4 production-grade operational runbooks.

---

## 1. The 4 Pillars of OIC Observability

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        THE 4 OBSERVABILITY PILLARS                          │
│                                                                             │
│   1. METRICS          2. LOGS            3. TRACES         4. BUSINESS KPIs │
│   (OCI Monitoring)    (OCI Logging &     (Correlation ID   (OIC Insight)    │
│                        Analytics)         Header)                           │
│                                                                             │
│   • ReceivedMsgs      • Activity Stream  • End-to-end hop  • Order cycle    │
│   • FailedMsgs        • Design Audit       propagation       time SLA       │
│   • Latency (P99)     • Error Stacks     • Fleet search    • Invoices stuck │
│   • Agent Health      • Log correlation    across layers     at approval    │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Wiring OIC Gen 3 into the OCI Observability Stack

### Step 1: Enable Native Activity Stream Logging
1. In the OCI Console, navigate to **Developer Services** → **Integration** → **Integration Instances**.
2. Select your OIC Gen 3 instance, click the **Logs** tab, and toggle **Activity Stream** to **Enabled**.
3. Select an existing OCI Log Group (e.g., `OIC_Production_LogGroup`).

### Step 2: Stream Logs into OCI Logging Analytics
1. Navigate to **Observability & Management** → **Logging Analytics** → **Administration**.
2. Create a Log Source mapped to the `Oracle Integration Cloud` source type.
3. Configure continuous ingestion from your Activity Stream Log Group.
4. Use Log Explorer to run visual SQL-like queries:
   ```sql
   'Log Source' = 'Oracle Integration Cloud' and Status = 'FAILED'
   | stats count() by 'Integration Name', 'Error Code'
   | sort -count
   ```

### Step 3: Configure OCI Monitoring Alarms
Navigate to **Observability & Management** → **Monitoring** → **Alarm Definitions** and create the following production alarms:

| Alarm Name | Metric Name | Metric Condition | Trigger Window | Severity | Notification Target |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **`OIC_HighErrorRate`** | `FailedMessages` | > 5% of `ReceivedMessages` | 15 minutes | 🔴 P2 (Major) | PagerDuty / Slack Webhook |
| **`OIC_CriticalIntegrationDown`** | `FailedMessages` | > 0 on P1 critical integration | 1 minute | 🔴 P1 (Critical) | PagerDuty On-Call (SMS/Voice) |
| **`OIC_LatencySpike`** | `ProcessingTime` | P99 > 10 seconds | 5 minutes | 🟠 P3 (Moderate) | Slack #ops-alerts |
| **`OIC_AgentClusterDegraded`** | `ConnectivityAgentStatus` | Status != ACTIVE | 3 minutes | 🔴 P1 (Critical) | PagerDuty On-Call |

---

## 3. End-to-End Correlation ID Propagation Pattern

To enable seamless tracing across multiple API-led layers, propagate an `X-Correlation-Id` header through every hop:

```
[Inbound Client Request]
  Header: X-Correlation-Id: CORR-2026-99210-AB (or generated via ora:generateGUID())
         │
         ▼
[Experience Layer: EXP_Portal] ─── passes header ──► [Process Layer: PROC_OrderSaga]
                                                              │
                                   ─── passes header ──► [System Layer: SYS_ERP]
                                   ─── passes header ──► [System Layer: SYS_WMS]
                                                              │
                                   ─── logs with ID ───► [SHARED_ErrorHandling]
                                   ─── indexed in ─────► [OCI Logging Analytics]
```

### OIC Gen 3 Tracking Variable Configuration:
In the Integration Tracking screen, map the Correlation ID to **Business Identifier Slot 1 (Primary)**. This makes the transaction immediately searchable by `CORR-2026-99210-AB` in the OIC Console, OCI Logging Analytics, and the ERP audit log.

---

## 4. Production Operational Runbooks

---

### Runbook 1: Critical Integration Instance Failure (P1)

```
INCIDENT TRIGGER: OCI Alarm "OIC_CriticalIntegrationDown" fires
SLA: Acknowledge < 5 minutes | Triage < 15 minutes | Recovery < 1 hour

PHASE 1: RAPID TRIAGE (0–5 Minutes)
  □ Open OIC Console -> Monitoring -> Integrations -> Filter: Status = FAILED.
  □ Locate the failed instance and copy the Instance ID and Primary Tracking ID.
  □ Verify scope of impact: Is it a single transaction or 100% of incoming traffic?

PHASE 2: FAULT ROOT-CAUSE ISOLATION (5–15 Minutes)
  □ Open Instance Activity Stream -> Jump to the failed action icon.
  □ Inspect $fault.code, $fault.reason, and $fault.details:
    - Case A: HTTP 429 / 502 / 503 / 504 -> Transient downstream outage. Check downstream health.
    - Case B: HTTP 400 / 422 -> Data validation or schema drift failure.
    - Case C: ORA-00001 / DB Error -> Database constraint or lock issue.
  □ Check downstream system status page or ping backend team.

PHASE 3: MITIGATION & RECOVERY (15–45 Minutes)
  □ If downstream is hard down: Pause the integration schedule or disable the trigger to prevent queue flooding.
  □ Verify whether compensating transactions were executed by the Global Fault Handler.
  □ If data error: Locate the failed record in the OIC_ERROR_LOG table in ATP.
  □ Correct data in source system or update DLQ payload.
  □ Trigger the DLQ_RETRY_PROCESSOR to resubmit the parked transaction.

PHASE 4: POST-INCIDENT RESOLUTION
  □ Verify successful processing of resubmitted transactions.
  □ Re-enable schedules/triggers if paused.
  □ File post-mortem report and identify whether an anti-pattern caused the failure.
```

---

### Runbook 2: Connectivity Agent Outage & Host Recovery

```
INCIDENT TRIGGER: OCI Alarm "OIC_AgentClusterDegraded" fires
SEVERITY: P1 (if on-premise integrations active) | P2 (if secondary agent handling load)

PHASE 1: AGENT HEALTH ASSESSMENT
  □ OIC Console -> Agents -> Check Agent Group status.
  □ Check active agent count: If 1 of 2 is active, traffic is safely failing over (P2). If 0 active, P1 full outage.

PHASE 2: HOST SYSTEM TRIAGE
  □ SSH / RDP into the affected agent host machine.
  □ Check if agent Java process is running:
    - Linux:   ps -ef | grep "oic-agent"
    - Windows: Get-Process | Where Name -like "*agent*"
  □ Inspect agent log file: <AGENT_HOME>/logs/agent-diagnostics.log
  □ Common Root Causes:
    1. Java OutOfMemory: Heap exhausted due to unbounded SQL query.
    2. SSL Certificate Expiry: Agent unable to authenticate with OIC cloud endpoint.
    3. Host Disk Space Full: Logs or temp files consumed 100% of host partition.
    4. Outbound Firewall Rule Changed: Port 443 blocked to *.oraclecloud.com.

PHASE 3: RECOVERY ACTIONS
  □ If Java OOM: Increase heap in bin/Agent_Settings.sh:
    USER_MEM_ARGS="-Xms2048m -Xmx4096m -XX:+UseG1GC"
  □ If host disk full: Purge archived logs older than 7 days.
  □ Restart Agent:
    - Linux:   <AGENT_HOME>/bin/agentstop.sh && <AGENT_HOME>/bin/agentstart.sh
    - Windows: <AGENT_HOME>\bin\agentstop.bat && <AGENT_HOME>\bin\agentstart.bat
  □ Monitor <AGENT_HOME>/logs/agent-diagnostics.log for: "Agent registered successfully."
  □ Verify OIC Console shows Agent status as ACTIVE.
```

---

### Runbook 3: Integration Performance Degradation & Latency Spikes

```
INCIDENT TRIGGER: OCI Alarm "OIC_LatencySpike" fires (P99 > 10s)

PHASE 1: BOTTLENECK IDENTIFICATION
  □ Open OIC Console -> Monitoring -> Integrations -> Sort by "Average Execution Time" (descending).
  □ Open slow instances and examine Activity Stream execution timestamps per action:
    - Is delay inside an External Invoke? -> Downstream system is slow or rate-limiting.
    - Is delay inside a Mapper action? -> O(N x M) nested loop XSLT issue.
    - Is delay inside a Stage File action? -> Reading large file without segment chunking.
    - Is delay inside a For-Each loop? -> Chatty loop anti-pattern.

PHASE 2: REMEDIATION DEPLOYMENT
  □ Downstream slow: Verify if downstream API is throttling. Add batching or cache responses.
  □ Mapper slow: Open mapper in Code View, implement <xsl:key> indexing (see Manual 05).
  □ Stage File slow: Change "Read Entire File" to "Read File in Segments" (chunk size: 250).
  □ Chatty loop: Refactor to invoke bulk/batch endpoint outside the loop.
  □ Test in TEST environment, export .par, and deploy to PROD via Deployment Channel.
```

---

### Runbook 4: FBDI Bulk Data Import Partial Rejection Reconciliation

```
INCIDENT TRIGGER: ESS Job status is SUCCEEDED, but business reports missing ERP records

PHASE 1: RETRIEVE ESS JOB EXECUTION LOGS
  □ OIC Console -> Monitoring -> Search FBDI integration instance -> Locate ESS Job ID.
  □ In Oracle Fusion ERP -> Tools -> Scheduled Processes -> Search by ESS Job ID.
  □ Download the output ZIP file containing the execution log and error reports.

PHASE 2: PARSE BAD RECORDS
  □ Extract ZIP and open the rejected rows CSV (e.g. `ApInvoicesInterface_bad.csv`).
  □ Check the rejection error codes:
    - Rejection code 1: Invalid GL Account Combination (Segment validation failed).
    - Rejection code 2: Duplicate Invoice Number for Vendor.
    - Rejection code 3: Currency code invalid or missing exchange rate.

PHASE 3: DELTA REMEDIATION & RE-IMPORT
  □ Generate a corrected CSV containing ONLY the rejected rows with valid reference data.
  □ Zip the corrected CSV with the appropriate FBDI manifest (`job.properties`).
  □ Re-run the FBDI integration flow targeting the delta file.
  □ Verify in Fusion ERP that all corrected rows successfully post to the base tables.
```
