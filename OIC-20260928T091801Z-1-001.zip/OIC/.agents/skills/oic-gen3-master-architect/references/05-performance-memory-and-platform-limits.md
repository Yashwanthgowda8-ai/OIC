# OIC Gen 3 Performance, Memory & Platform Limits Tuning

> Understanding JVM heap mechanics, transformation complexity, platform hard boundaries, and network topologies is essential for architecting enterprise-grade, high-throughput OIC Gen 3 solutions.

---

## 1. OIC Gen 3 Platform Limits Reference Matrix

| Platform Metric / Resource | Gen 3 Limit | Architectural Impact & Design Rules |
| :--- | :--- | :--- |
| **Synchronous REST/SOAP Timeout** | **300 seconds** (5 min) | **Hard platform ceiling**. Any flow exceeding 3s under peak load must switch to Sync Facade + Event Worker. |
| **Inline Message Payload (Trigger / Invoke)** | **10 MB** | **Hard platform limit**. Payloads > 10 MB fail instantly. Use Stage File chunking or OCI Object Storage pre-signed URLs. |
| **Stage File Processing Size** | **1 GB** | Maximum file size supported on local scratch disk. **Mandatory**: Use "Read File in Segments" for files > 10 MB. |
| **Direct FTP / SFTP File Streaming** | **100 MB** | Maximum streaming size directly between endpoints without intermediate staging. |
| **Tenant Scratch Storage** | **50 GB** (shared per pod) | Shared across all concurrent integrations. **Mandatory**: Always execute `Delete File` in happy path & fault handlers. |
| **Activity Stream Audit Retention** | **32 days** | Production logs expire after 32 days. Stream to OCI Logging Analytics or external SIEM for compliance. |
| **Tracking Business Identifiers** | **3** (1 Primary, 2 Secondary) | Populate all 3 slots on every integration for fast indexing and query performance in OIC Monitoring. |
| **Custom JavaScript Execution Timeout** | **5 seconds** | Functions must be lightweight, synchronous, and CPU-efficient. No network I/O or long-running computations. |

---

## 2. JVM Memory Footprint & Garbage Collection Optimization

In OIC Gen 3, XML and JSON documents processed by the visual mapper are parsed into an in-memory Document Object Model (DOM) tree.

### The Memory Multiplier Factor:
A raw 10 MB JSON or XML file expands into **50 MB to 100 MB** of active JVM heap memory when parsed with DOM element nodes, namespace scopes, attribute objects, and tracking context.

```
Raw File on Disk:  10 MB
JVM Heap DOM Tree: 50 MB - 100 MB (5x to 10x expansion!)
```

### The 3 Core Memory Optimization Rules:
1. **Mandatory Segment Chunking**:
   - For all files > 10 MB or files of unknown size, configure `Stage File: Read File in Segments` (100–500 records/segment).
   - This ensures that only a tiny fraction of the dataset resides in JVM memory at any single instant.
2. **Scope-Level Variables over Global Variables**:
   - Gen 3 introduces **Scope-level variables**. Unlike global variables (which remain referenced in heap until the entire integration completes), Scope variables are dereferenced and eligible for Garbage Collection as soon as their enclosing scope exits.
3. **Never Accumulate State Inside Loops**:
   - Avoid modifying global strings or arrays using `concat()` inside a loop.
   - Use `Stage File: Write File` with **"Append to existing file"** checked to stream records directly to the scratch disk.

---

## 3. High-Performance XSLT Mapping & Key Indexing

The OIC Gen 3 visual mapper generates standard XSLT stylesheets. In complex multi-line transformations, poor XSLT patterns can introduce devastating performance bottlenecks.

### The $O(N \times M)$ Nested Loop Trap:
Traversing 1,000 Invoice Headers and searching for corresponding Line Items using XPath predicates requires **1,000 × 1,000 = 1,000,000 DOM node evaluations**:
```xml
<!-- POOR PERFORMANCE: O(N x M) evaluations -->
<xsl:for-each select="/n1:InvoiceList/InvoiceHeader">
  <xsl:variable name="currentId" select="HeaderID"/>
  <!-- Linear scan across all lines for EVERY header -->
  <xsl:for-each select="/n1:InvoiceList/InvoiceLine[HeaderID = $currentId]">
    ...
  </xsl:for-each>
</xsl:for-each>
```

### The $O(1)$ XSLT Key Remedy:
Switch to the **Code View** of the mapper and define an `<xsl:key>` index at the top of the stylesheet. This builds a hash-index in memory, reducing lookups to $O(1)$:
```xml
<!-- HIGH PERFORMANCE: O(1) indexed lookup -->
<xsl:key name="kLinesByHeader" match="InvoiceLine" use="HeaderID"/>

<xsl:for-each select="/n1:InvoiceList/InvoiceHeader">
  <!-- Instant hash-table lookup -->
  <xsl:for-each select="key('kLinesByHeader', current()/HeaderID)">
    <xsl:value-of select="ItemDescription"/>
  </xsl:for-each>
</xsl:for-each>
```

---

## 4. Offloading Heavy Compute to Gen 3 JavaScript Libraries

OIC Gen 3 supports native ES6+ JavaScript libraries created directly inside Projects. Use JavaScript libraries rather than complex XSLT hacks for:
- Regular expression pattern matching, string tokenization, and formatting
- Complex date arithmetic, working-day calculations, and timezone adjustments
- Cryptographic hashing (SHA-256), HMAC signing, and Base64 encoding
- In-memory array filtering, sorting, and deduplication

### Production Example: High-Speed Deduplication Library
```javascript
/**
 * Deduplicates an array of objects based on a composite key
 * @param {Array} records - Inbound array of records from source
 * @param {string} keyField - Primary field name for uniqueness check
 * @returns {Array} Deduplicated array
 */
function deduplicateRecords(records, keyField) {
    if (!Array.isArray(records)) {
        return [];
    }
    const seen = new Set();
    return records.filter(item => {
        const value = item[keyField];
        if (value === undefined || value === null || seen.has(value)) {
            return false;
        }
        seen.add(value);
        return true;
    });
}
```

---

## 5. Network Connectivity: OCI Private Endpoints vs. Connectivity Agent

```
┌──────────────────────────────────────┬────────────────────────────────────────┐
│ TARGET INFRASTRUCTURE                │ CONNECTIVITY MECHANISM                 │
├──────────────────────────────────────┼────────────────────────────────────────┤
│ OCI Autonomous Database (ATP / ADW)  │ Native Gen 3 Private Endpoint (Direct) │
│ Oracle Cloud DB Systems / Exadata CS │ Native Gen 3 Private Endpoint (Direct) │
│ Private VMs in OCI VCN Subnets       │ Native Gen 3 Private Endpoint (Direct) │
│ Third-Party Cloud Private VPC        │ OCI FastConnect / VPN + Private EP     │
│ On-Premises Oracle EBS / SAP / DB    │ Connectivity Agent (Dual-Node HA)      │
└──────────────────────────────────────┴────────────────────────────────────────┘
```

### Connectivity Agent Sizing & HA Guidelines (for On-Premises):
When integrating with on-premises legacy systems behind corporate firewalls:
1. **Dual-Node High Availability (HA)**: Always deploy at least 2 Connectivity Agent instances on separate physical or virtual hosts within the same Agent Group. OIC automatically load-balances and fails over between them.
2. **JVM Heap Sizing**: In `bin/Agent_Settings.sh` or `.bat`, configure JVM heap:
   ```bash
   USER_MEM_ARGS="-Xms2048m -Xmx4096m -XX:+UseG1GC -XX:+ExplicitGCInvokesConcurrent"
   ```
3. **Database Adapter Query Protection**: Always enforce row limits (`ROWNUM <= 2000` or `FETCH FIRST 2000 ROWS ONLY`) to prevent unbounded queries from overwhelming the agent's memory.
