# AI-Augmented Integration & Agentic Tools for OIC Gen 3

> In 2025 and 2026, Oracle Integration Cloud Gen 3 evolved from a traditional integration platform into an **intelligent, AI-augmented automation engine**. This manual explores native AI canvas capabilities, Document Understanding, and exposing integrations as AI Agent Tools via the Model Context Protocol (MCP).

---

## 1. Native AI Document Understanding Action

Oracle has embedded **OCI AI Services** directly into the OIC Gen 3 canvas, eliminating the need to write custom Python scripts or provision external middleware for document processing.

### Document Processing Blueprint:
```
[Schedule / SFTP Trigger]
           │
  [Download Vendor Invoice PDF]
           │
  [Action: Document Understanding]
  • Document Type: INVOICE
  • Extract Features:
    - Key-Value Extraction (VendorName, InvoiceDate, TotalAmount, Currency)
    - Table Extraction (LineItems: ItemCode, Description, Quantity, UnitPrice)
    - Raw OCR Text
           │
  [Scope: Validate Business Rules]
  • Verify Vendor exists in Fusion ERP
  • Check line-item totals match header total
           │
  [Oracle ERP Cloud Adapter: Create AP Invoice]
```

### Supported Document Models:
- **Pre-Trained Invoices**: Auto-extracts 30+ canonical invoice fields without training.
- **Pre-Trained Receipts**: Expense report auditing and corporate card reconciliation.
- **Custom Key-Value Models**: Extraction for industry-specific contracts, customs forms, and bills of lading.

---

## 2. Intelligent AI Mapping Suggestions

When mapping complex enterprise data structures (e.g. converting a Salesforce Account object into an Oracle Fusion Customer Party schema):
1. **Semantic Similarity Mapping**: The OIC Gen 3 mapper analyzes field semantics, data types, and structural hierarchies to suggest candidate mappings.
2. **Enterprise Historical Learning**: The platform evaluates historical mappings across your tenant projects to prioritize high-confidence recommendations.
3. **Usage Rule**: Always review AI suggestions before accepting; verify date format conversions (`yyyy-MM-dd` vs `dd-MMM-yyyy`) and nullability constraints.

---

## 3. Natural Language Project & Recipe Auto-Generation

Developers can bootstrap end-to-end integration flows using the Gen 3 AI Assistant:
- **Prompt**: *"Create a project named PROC_ProcureToPay with an integration that reads new POs from Coupa REST API, transforms to Fusion ERP Purchase Order schema, handles exceptions via RFC 7807, and dispatches a Slack notification on error."*
- **Output**: Generates project container, connection stubs, trigger/invoke action sequence, fault handlers, and initial mapper mappings.

---

## 4. Exposing OIC Integrations as AI Agent Tools (Model Context Protocol - MCP)

As enterprise autonomous AI agents (built on LangChain, AutoGen, or OCI Generative AI Agents) become standard, OIC Gen 3 serves as the **safe, enterprise-grade tool execution layer**:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           AUTONOMOUS AI AGENT                               │
│                   (Evaluates user intent & plans steps)                     │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │ Calls MCP Tool Definition
                                       │ (e.g. check_order_inventory(sku, qty))
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           OCI API GATEWAY / MCP HOST                        │
│           • Authenticates Agent JWT        • Enforces Rate Limits           │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          OIC GEN 3 EXPERIENCE API                           │
│  `EXP_AGENT_CHECK_INVENTORY`                                                │
│  ● Strictly typed JSON input contract                                       │
│  ● Orchestrates real-time lookup across ERP and WMS                         │
│  ● Implements guardrails (read-only query vs. transactional write)          │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Human-in-the-Loop Approval Pattern for AI Agents:
For state-modifying actions initiated by AI agents (e.g., *“Refund customer order #99210 for $850”*):
1. The AI agent invokes the OIC Process integration `PROC_Agent_Refund_Request`.
2. OIC creates a pending record and dispatches an **Approval Milestone** (via OIC Process Automation or Slack interactive card).
3. The transaction remains in `PENDING_APPROVAL` status until a human manager approves or rejects.
4. Only upon explicit human approval does OIC execute the payment refund and ERP posting.
