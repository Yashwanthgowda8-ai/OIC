# Distributed Sagas & Compensation Framework for OIC Gen 3

> In enterprise cloud architectures, atomic two-phase commit (2PC) transactions across disparate SaaS and on-premises systems are impossible. You cannot roll back a distributed transaction; you can only **compensate**.

---

## 1. The Distributed Transaction Dilemma

Consider an Order-to-Cash process spanning three systems:
1. **Warehouse (WMS)**: Reserves 50 units of Inventory.
2. **Stripe / CyberSource**: Charges $1,250 on the customer credit card.
3. **Oracle Fusion ERP**: Creates the Sales Order and AR Invoice.

If step 3 fails due to an invalid GL account code, steps 1 and 2 have already committed! 
- Without compensation: The customer is charged, inventory is locked, and no order exists in ERP.
- With compensation: OIC executes semantic undo operations: refunds the payment and releases the inventory reservation.

### The Golden Axiom of Compensation:
> **Compensation is NOT a database rollback.** It is a new, forward-moving business operation designed to semantically neutralize the business impact of a previously completed step.

| Forward Operation | Compensating Operation | Why Database Rollback Fails |
| :--- | :--- | :--- |
| Create Sales Order | Cancel / Void Sales Order | The order ID was already generated and recorded in the database. |
| Charge Credit Card | Issue Refund / Reverse Auth | Money moved through external banking networks. |
| Reserve Warehouse Stock | Release Reservation | Warehouse allocation systems have already flagged inventory. |
| Send Confirmation Email | Send Apology / Cancellation Email | You cannot unsend an email that was delivered to an inbox. |

---

## 2. Orchestration Saga Blueprint in OIC Gen 3

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PROC_OrderToCash_Saga (Process Layer)                    │
│                                                                             │
│  State Tracking Variables (Scope-Level):                                    │
│    v_sagaState          = "STARTED"                                         │
│    v_inventoryReserved  = false                                             │
│    v_paymentCharged     = false                                             │
│    v_erpOrderCreated    = false                                             │
│    v_correlationId      = ora:generateGUID()                                │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ STEP 1: Reserve Inventory (WMS)                                     │    │
│  │ [Scope: Scope_ReserveInventory]                                     │    │
│  │   --> Invoke: SYS_WMS_ReserveInventory (Idempotency-Key: STEP-1)    │    │
│  │   --> Assign: v_inventoryReserved = true                             │    │
│  │   --> Assign: v_sagaState = "INVENTORY_RESERVED"                    │    │
│  │   [Fault Handler]                                                   │    │
│  │     --> Assign: v_sagaState = "FAILED_AT_INVENTORY"                 │    │
│  │     --> Rethrow (bubbles to Global Fault Handler)                   │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ STEP 2: Charge Customer Payment                                     │    │
│  │ [Scope: Scope_ChargePayment]                                        │    │
│  │   --> Invoke: SYS_Payment_Charge (Idempotency-Key: STEP-2)          │    │
│  │   --> Assign: v_paymentCharged = true                               │    │
│  │   --> Assign: v_sagaState = "PAYMENT_CHARGED"                       │    │
│  │   [Fault Handler]                                                   │    │
│  │     --> Assign: v_sagaState = "FAILED_AT_PAYMENT"                   │    │
│  │     --> Rethrow                                                     │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ STEP 3: Create Fusion ERP Sales Order                               │    │
│  │ [Scope: Scope_CreateERPOrder]                                       │    │
│  │   --> Invoke: SYS_ERP_CreateOrder (Idempotency-Key: STEP-3)         │    │
│  │   --> Assign: v_erpOrderCreated = true                              │    │
│  │   --> Assign: v_sagaState = "COMPLETED"                             │    │
│  │   [Fault Handler]                                                   │    │
│  │     --> Assign: v_sagaState = "FAILED_AT_ERP"                       │    │
│  │     --> Rethrow                                                     │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ GLOBAL FAULT HANDLER (Compensation Orchestrator)                    │    │
│  │                                                                     │    │
│  │  1. Check: If v_paymentCharged = true:                              │    │
│  │     --> Invoke: SYS_Payment_Refund (Idempotency-Key: COMP-STEP-2)   │    │
│  │     --> Log: "Compensation: Payment reversed successfully."         │    │
│  │                                                                     │    │
│  │  2. Check: If v_inventoryReserved = true:                           │    │
│  │     --> Invoke: SYS_WMS_ReleaseStock (Idempotency-Key: COMP-STEP-1) │    │
│  │     --> Log: "Compensation: Inventory stock released."              │    │
│  │                                                                     │    │
│  │  3. Publish: "Order_Saga_Failed_Event" to SHARED_ErrorHandling      │    │
│  │  4. Return canonical RFC 7807 Error Response or write to DLQ        │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Compensation Decision Matrix

| Saga Step | Forward Operation | Compensating Operation | Idempotent? | Can Compensation Fail? | Fallback / Escalation |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Step 1: Inventory** | `POST /inventory/reserve` | `POST /inventory/release` | Yes | Unlikely | Dead Letter Queue + P2 Alert |
| **Step 2: Payment** | `POST /v1/charges` | `POST /v1/refunds` | Yes | Yes (settlement timing issue) | Escalate to Finance via ServiceNow |
| **Step 3: ERP Order** | `POST /fscmRestApi/resources/11.13.18.05/orders` | `PATCH /orders/{id}` (Status: CANCELLED) | Yes | Yes (if order already picked) | Mark in DLQ with `MANUAL_REVIEW` |

---

## 4. Distributed Idempotency Key Specification

Retries in distributed networks are inevitable. To ensure that network timeouts or replay attempts do not generate duplicate charges or double orders, **every downstream invocation must pass an Idempotency Key**:

### Standard HTTP Header Pattern:
```http
POST /fscmRestApi/resources/11.13.18.05/orders HTTP/1.1
Host: fa-erp.oraclecloud.com
Idempotency-Key: OIC-SAGA-CORR-2026-88219-STEP-3
X-Correlation-Id: CORR-2026-88219
Content-Type: application/json
```

### OIC Gen 3 Header Expression:
In the Request Header mapping of the Invoke action:
```xpath
concat("OIC-SAGA-", $v_correlationId, "-STEP-", string($v_stepNumber))
```

---

## 5. Long-Running Saga State Persistence in Autonomous Database (ATP)

For sagas that span hours or days (e.g., manager approval workflows, supplier onboarding), persist transaction milestones to an **Autonomous Transaction Processing (ATP)** database table via a native OCI Private Endpoint:

```sql
CREATE TABLE OIC_SAGA_STATE (
    SAGA_ID               VARCHAR2(100)  PRIMARY KEY,
    CORRELATION_ID        VARCHAR2(100)  NOT NULL,
    PROJECT_NAME          VARCHAR2(100)  NOT NULL,
    INTEGRATION_NAME      VARCHAR2(100)  NOT NULL,
    CURRENT_STEP          VARCHAR2(50)   NOT NULL,
    SAGA_STATUS           VARCHAR2(30)   DEFAULT 'IN_PROGRESS',
    STEP1_STATUS          VARCHAR2(20),
    STEP1_COMP_KEY        VARCHAR2(200),
    STEP2_STATUS          VARCHAR2(20),
    STEP2_COMP_KEY        VARCHAR2(200),
    STEP3_STATUS          VARCHAR2(20),
    STEP3_COMP_KEY        VARCHAR2(200),
    PAYLOAD_REFERENCE     VARCHAR2(500),
    CREATED_AT            TIMESTAMP      DEFAULT SYSTIMESTAMP,
    UPDATED_AT            TIMESTAMP      DEFAULT SYSTIMESTAMP,
    CONSTRAINT chk_saga_status CHECK (
        SAGA_STATUS IN ('IN_PROGRESS', 'COMPLETED', 'COMPENSATING', 'COMPENSATED', 'FAILED', 'MANUAL_REVIEW')
    )
);

CREATE INDEX IDX_OIC_SAGA_CORR ON OIC_SAGA_STATE (CORRELATION_ID);
CREATE INDEX IDX_OIC_SAGA_RECOVERY ON OIC_SAGA_STATE (SAGA_STATUS, CREATED_AT);
```

### Automated Saga Recovery Processor:
Build a scheduled integration (`SAGA_RECOVERY_PROCESSOR`) running every 15 minutes that:
1. Queries `SELECT * FROM OIC_SAGA_STATE WHERE SAGA_STATUS = 'COMPENSATING' OR (SAGA_STATUS = 'IN_PROGRESS' AND CREATED_AT < SYSTIMESTAMP - INTERVAL '2' HOUR)`.
2. Inspects which steps committed and triggers their compensating APIs.
3. Upon success, updates `SAGA_STATUS = 'COMPENSATED'`. If compensation fails 3 times, flags as `MANUAL_REVIEW` and pages operations.
