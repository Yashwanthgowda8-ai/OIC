# Master OIC Gen 3 Production Hardening Checklist (35-Point)

> The definitive enterprise go-live verification checklist for Oracle Integration Cloud Gen 3 (OIC Gen 3). Every box must be verified before promoting integrations into a live Production environment.

---

## 1. Architecture, Decomposition & Topology (6 Points)

- [ ] **1. Project Encapsulation**: 100% of integration artifacts belong to named Gen 3 Projects (`EXP_*`, `PROC_*`, `SYS_*`, `SHARED_*`). Zero unassigned/loose integrations exist on the instance.
- [ ] **2. 3-Layer API-Led Adherence**: Experience APIs never directly call System adapters. All inter-system coordination is mediated by the Process layer.
- [ ] **3. Single Responsibility Principle**: No monolithic "God Integrations" with > 50 actions or touching > 3 backend systems. Complex flows are cleanly decomposed into reusable parent/child flows.
- [ ] **4. Event-Driven Decoupling**: Asynchronous fan-out and domain state broadcasts use native Gen 3 Events (Pub/Sub). Publishers and subscribers maintain independent deployment lifecycles.
- [ ] **5. Synchronous Latency SLA**: All synchronous REST triggers execute in < 3 seconds under production load. Any workflow exceeding 5 seconds is refactored into the Sync Facade + Event Worker pattern.
- [ ] **6. Inbound Payload Guardrail**: Strict payload size limits (< 5 MB) are enforced on synchronous REST triggers. Workflows exceeding 10 MB use Stage File chunking or OCI Object Storage.

---

## 2. Anti-Pattern Elimination (6 Points)

- [ ] **7. Zero Chatty Loops**: No `For-Each` loop executes individual API calls per record. All iterative logic utilizes bulk/batch endpoints or disk-staged composite files.
- [ ] **8. Mandatory File Segment Chunking**: Every `Stage File: Read File` action on external or variable-size files uses **"Read File in Segments"** (100–500 records). "Read Entire File" is strictly forbidden on unknown datasets.
- [ ] **9. No Global Variable Mutation in Loops**: No `Assign` action mutates global variables inside a `For-Each` loop. State is accumulated via Scope variables or Stage File Append to prevent immutable snapshot memory leaks.
- [ ] **10. Zero String Concatenation State Bloat**: No large XML or JSON strings are built in memory using `concat()` loops. Data is streamed directly to scratch disk.
- [ ] **11. Zero Hardcoded Configuration**: Zero hardcoded URLs, hostnames, directories, email addresses, or credentials exist in mappers, scripts, or assignments. All use Project or Integration Configurable Properties.
- [ ] **12. Non-Empty Global Fault Handlers**: Every Global Fault Handler implements the mandatory 4-step sequence: (1) Log fault metadata, (2) Clean scratch files, (3) Publish error event, (4) Return RFC 7807 problem details or rethrow.

---

## 3. Fault Resilience, Sagas & Idempotency (6 Points)

- [ ] **13. Scope-Level Exception Traps**: Every external invocation (REST, SOAP, ERP, ATP DB, SFTP) is encapsulated inside a Scope with an explicit fault handler.
- [ ] **14. Transient vs. Non-Transient Classification**: Exponential backoff with jitter (10s -> 20s -> 40s, max 3 retries) is configured strictly for transient faults (429, 502, 503, 504). Non-transient faults (400, 401, 422) fail fast to the DLQ.
- [ ] **15. Canonical RFC 7807 Error Formatting**: All synchronous REST APIs format error responses with `type`, `title`, `status`, `detail`, `instance`, `code`, and `correlationId`.
- [ ] **16. Dead Letter Queue & Replay Service**: Failed asynchronous and batch transactions are parked in an Autonomous Database table (`OIC_ERROR_LOG`) with full payload context. A scheduled replay integration (`DLQ_RETRY_PROCESSOR`) is active.
- [ ] **17. Distributed Saga Compensation**: Multi-system orchestrations implement reverse-order compensating transactions in the Global Fault Handler evaluated against boolean state tracking flags.
- [ ] **18. Distributed Idempotency Keys**: All outbound mutating API requests pass a unique `Idempotency-Key` header derived from the transaction correlation ID and step number to guarantee safe retries.

---

## 4. Performance, Memory & Transformations (5 Points)

- [ ] **19. Temporary Scratch Disk Cleanup**: `Stage File: Delete File` is explicitly called on all temporary files in both the primary success flow **and** inside every Fault Handler.
- [ ] **20. High-Performance XSLT Indexing**: Complex mappers with nested parent-child lookups use `<xsl:key>` hash indexing in Code View, eliminating $O(N \times M)$ traversals.
- [ ] **21. JavaScript Library Execution Safety**: All custom JavaScript libraries complete in < 2 seconds (well below the 5-second platform timeout) and do not contain blocking operations or unbounded loops.
- [ ] **22. Scope Variable Memory Reclamation**: Iterative loop bodies leverage Scope-level variables rather than global variables to enable immediate JVM Garbage Collection upon iteration completion.
- [ ] **23. FBDI Execution Log Inspection**: Integrations invoking the Oracle ERP Cloud `importBulkData` operation download the ESS execution log ZIP and verify that the interface table bad-records count is 0.

---

## 5. Security & Network Topologies (4 Points)

- [ ] **24. OAuth 2.0 Inbound Authentication**: All inbound REST triggers enforce OAuth 2.0 Client Credentials Grant via OCI IAM Identity Domains. Basic Authentication is completely disabled.
- [ ] **25. PII & Sensitive Data Masking**: Field-level data masking is enabled for all sensitive fields (SSN, credit card, salary, password) in tracking configurations. Activity Stream logs are free of credentials.
- [ ] **26. Native OCI Private Endpoints**: Integrations targeting OCI Autonomous Database, DB Systems, or VCN subnets use native Gen 3 Private Endpoints without unnecessary agent middleware.
- [ ] **27. High-Availability Connectivity Agents**: On-premises Connectivity Agents are deployed as dual-node HA clusters on separate host machines with JVM heap tuned to `-Xms2048m -Xmx4096m`.

---

## 6. Observability, Alarms & Operations (4 Points)

- [ ] **28. Primary & Secondary Business Tracking**: All 3 tracking identifier slots are mapped (Primary: unique business key such as `OrderNumber` or `InvoiceId`; Secondary 1: customer/vendor ID; Secondary 2: source channel).
- [ ] **29. End-to-End Correlation ID Propagation**: The `X-Correlation-Id` header is captured (or generated via `ora:generateGUID()`), propagated to all downstream invokes, and indexed in log streams.
- [ ] **30. OCI Activity Stream & Logging Analytics**: Activity Stream logging is enabled and ingested into OCI Logging Analytics for long-term audit trail and centralized querying.
- [ ] **31. Production Alarms & Notification Wiring**: OCI Monitoring alarms are active for High Error Rate (> 5%), Critical Flow Down (> 0 failures), Latency P99 (> 10s), and Agent Offline, routing to PagerDuty or Slack.

---

## 7. Governance, CI/CD & Production Hygiene (4 Points)

- [ ] **32. Production Audit Level Setting**: Production integrations are activated with `Audit Level: Normal` or `Minimal`. `Audit Level: Debug` is strictly prohibited during normal production operations.
- [ ] **33. Environment-Agnostic Connection Names**: Connection names are strictly identical across DEV, TEST, and PROD. Environment-specific URLs and credentials are managed via Deployment Profiles.
- [ ] **34. Version-Controlled Project Archive (`.par`)**: The complete Project Archive (`.par`) is committed to Git with semantic version tags (e.g. `v1.2.0`) and documented release notes.
- [ ] **35. Operational Incident Runbook Documented**: A published runbook exists for the integration suite detailing trigger schedules, downstream owners, escalation paths, and recovery procedures linked to alarm alerts.
