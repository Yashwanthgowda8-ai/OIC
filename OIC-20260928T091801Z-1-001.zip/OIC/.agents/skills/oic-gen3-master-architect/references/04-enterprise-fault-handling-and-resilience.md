# Enterprise Fault Handling & Resilience Framework for OIC Gen 3

> This document defines the enterprise fault-handling architecture, transient classification algorithms, exponential backoff formulas, Dead Letter Queue (DLQ) designs, and RFC 7807 problem details specification for **Oracle Integration Cloud Gen 3 (OIC Gen 3)**.

---

## 1. The 3-Tier Enterprise Fault Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TIER 3: COMMON ERROR HANDLING SERVICE (SHARED_ErrorHandling_Project)        │
│                                                                             │
│ ● Subscribed to "System_Fault_Occurred_Event" or invoked via Async REST     │
│ ● Persists failed payloads & fault context to ATP Database (OIC_ERROR_LOG)  │
│ ● Dispatches operational alerts (PagerDuty, Slack, MS Teams, Email)         │
│ ● Automated ticket creation in ServiceNow / Jira Service Desk               │
│ ● Hosts the DLQ Replay Processor to re-submit failed records                │
└──────────────────────────────────────▲──────────────────────────────────────┘
                                       │ Publishes Gen 3 Event / Calls Async REST
┌──────────────────────────────────────┴──────────────────────────────────────┐
│ TIER 2: INTEGRATION GLOBAL FAULT HANDLER (Integration-Level Catch-All)      │
│                                                                             │
│ ● Traps all unhandled faults escaping scopes                                │
│ ● Executes reverse compensation (Saga rollback)                             │
│ ● Deletes all temporary Stage File scratch artifacts                        │
│ ● Formats canonical RFC 7807 Problem Details response for sync callers      │
│ ● Forwards failure context to Tier 3 Common Error Service                   │
└──────────────────────────────────────▲──────────────────────────────────────┘
                                       │ Escalates Unhandled Faults
┌──────────────────────────────────────┴──────────────────────────────────────┐
│ TIER 1: SCOPE-LEVEL FAULT HANDLERS (Localized Component Resilience)         │
│                                                                             │
│ ● Wraps risky external invokes (REST, SOAP, ERP, ATP DB, SFTP)              │
│ ● Catches specific fault types: APIInvocationFault, TimeoutFault            │
│ ● Classifies transient vs. non-transient faults                             │
│ ● Executes localized Exponential Backoff with Jitter for transient faults   │
│ ● Swallows benign errors or supplies fallback cached values                 │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Fault Classification & Decision Tree

```
                           [Fault Detected in Scope]
                                       |
                   Is error transient or non-transient?
                  /                                    \
         [Transient Error]                     [Non-Transient Error]
   (HTTP 429 Rate Limit, 502 Bad Gateway,    (HTTP 400 Bad Request, 401/403 Auth,
    HTTP 503 Unavailable, 504 Timeout,        HTTP 404 Not Found, 422 Unprocessable,
    TCP Socket Timeout, Connection Reset)      Schema Validation, Missing Fields)
                 |                                      |
     Execute Exponential Backoff              Do NOT retry blindly!
     (10s -> 20s -> 40s + Jitter)             Capture payload & error metadata
           /             \                              |
      [Success]      [Exhausted]               Send to Dead Letter Queue (DLQ)
          |               |                             |
      Continue       Escalate to               Format RFC 7807 Response /
     Normal Flow     Global Fault              Page Support Team for fix
```

---

## 3. OIC Gen 3 Built-In `$fault` Variable Anatomy

Inside any Fault Handler (Scope or Global), OIC Gen 3 automatically instantiates the `$fault` object:

| Variable Element | Data Type | Description | Production Example |
| :--- | :--- | :--- | :--- |
| **`$fault.type`** | String (QName) | Fully qualified fault type name | `APIInvocationFault`, `TimeoutFault` |
| **`$fault.code`** | String | HTTP status code or adapter error code | `504`, `429`, `ORA-00001` |
| **`$fault.reason`** | String | Short human-readable summary | `Gateway Timeout`, `Rate limit exceeded` |
| **`$fault.details`** | Any / String | Raw response payload or remote stack trace | `{"errorCode":"LIMIT_EXCEEDED","message":"Max 1200 req/min"}` |

---

## 4. Exponential Backoff with Jitter Algorithm

Blind retries during a downstream outage create a "thundering herd" that overwhelms recovering services. Implement exponential backoff with full jitter:

### Mathematical Formula:
$$\text{Backoff}(attempt) = \min(\text{MaxWait}, \text{InitialWait} \times 2^{attempt}) \pm \text{Jitter}$$

### Implementation Blueprint in OIC Gen 3:
Define Scope variables:
- `v_retryCount` (integer) = `0`
- `v_maxRetries` (integer) = `3`
- `v_baseWaitSec` (integer) = `10`
- `v_isSuccessful` (boolean) = `false`

```
While (v_isSuccessful = false AND v_retryCount < v_maxRetries)
  |
  +-- [Scope: Scope_Invoke_Remote_API]
        |
        +-- [Invoke Action: Call Target System]
        |     |
        |     +-- [Assign: v_isSuccessful = true]
        |
        +-- [Fault Handler: Catch APIInvocationFault]
              |
              +-- [Assign: v_retryCount = v_retryCount + 1]
              +-- [If v_retryCount < v_maxRetries]:
              |     |
              |     +-- [Calculate: v_sleepTime = (v_baseWaitSec * (2 ^ (v_retryCount - 1))) + ora:random(1, 5)]
              |     +-- [Wait Action: Duration = v_sleepTime seconds]
              |
              +-- [Else (Retries Exhausted)]:
                    |
                    +-- [Rethrow Fault to Global Handler]
```

---

## 5. Dead Letter Queue (DLQ) & Error Parking Schema (Autonomous Database)

For asynchronous, event-driven, or scheduled batch integrations, failed transactions must be parked with full context for replay:

```sql
CREATE TABLE OIC_ERROR_LOG (
    ERROR_ID              VARCHAR2(100)   PRIMARY KEY,
    CORRELATION_ID        VARCHAR2(100)   NOT NULL,
    PROJECT_NAME          VARCHAR2(100)   NOT NULL,
    INTEGRATION_NAME      VARCHAR2(100)   NOT NULL,
    INSTANCE_ID           VARCHAR2(100)   NOT NULL,
    PRIMARY_TRACKING_KEY  VARCHAR2(100),
    PAYLOAD_DATA          CLOB            NOT NULL,
    FAULT_TYPE            VARCHAR2(100),
    FAULT_CODE            VARCHAR2(50),
    FAULT_REASON          VARCHAR2(4000),
    FAULT_DETAILS         CLOB,
    STATUS                VARCHAR2(30)    DEFAULT 'PENDING_RETRY',
    RETRY_COUNT           NUMBER          DEFAULT 0,
    MAX_REPLAY_ATTEMPTS   NUMBER          DEFAULT 3,
    CREATED_TIMESTAMP     TIMESTAMP       DEFAULT SYSTIMESTAMP,
    LAST_UPDATED          TIMESTAMP       DEFAULT SYSTIMESTAMP,
    CONSTRAINT chk_err_status CHECK (
        STATUS IN ('PENDING_RETRY', 'MANUAL_REVIEW', 'REPLAYED', 'DISCARDED')
    )
);

CREATE INDEX IDX_OIC_ERR_STATUS ON OIC_ERROR_LOG (STATUS, CREATED_TIMESTAMP);
CREATE INDEX IDX_OIC_ERR_CORR ON OIC_ERROR_LOG (CORRELATION_ID);
```

### Automated Replay Integration (`DLQ_RETRY_PROCESSOR`):
- Runs every 30 minutes via Schedule Trigger.
- Queries `SELECT * FROM OIC_ERROR_LOG WHERE STATUS = 'PENDING_RETRY' AND RETRY_COUNT < MAX_REPLAY_ATTEMPTS`.
- Publishes the original `PAYLOAD_DATA` back to the Gen 3 Event Bus with an incremented `RETRY_COUNT`.
- Upon successful processing, marks `STATUS = 'REPLAYED'`.

---

## 6. Canonical RFC 7807 Problem Details Standard Specification

All synchronous REST triggers in OIC Gen 3 must conform to **RFC 7807 (Problem Details for HTTP APIs)**:

```json
{
  "type": "https://api.enterprise.com/errors/RESOURCE-NOT-FOUND",
  "title": "Customer Account Not Found",
  "status": 404,
  "detail": "Customer with AccountNumber 'CUST-88192' does not exist in Oracle Fusion ERP.",
  "instance": "/ic/api/integration/v1/flows/rest/EXP_CUSTOMER_FACADE/1.0/instances/3810294",
  "code": "ERP-CUST-404",
  "correlationId": "CORR-2026-88219-AB",
  "timestamp": "2026-09-27T01:30:00Z"
}
```

### REST Trigger Mapping Guidelines:
- In the REST Trigger configuration wizard, configure the Fault response schema with the RFC 7807 fields.
- Set the HTTP response header `Content-Type: application/problem+json`.
- In the Global Fault Handler, map `$fault.code` to `status`, `$fault.reason` to `title`, and `$fault.details` to `detail`.
