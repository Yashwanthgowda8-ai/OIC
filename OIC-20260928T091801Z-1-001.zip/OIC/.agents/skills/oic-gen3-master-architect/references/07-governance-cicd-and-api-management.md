# Governance, CI/CD Lifecycle & API Management for OIC Gen 3

> In OIC Gen 3, enterprise governance shifts from managing fragmented connections and integrations to administering cohesive **Projects**, automated **Deployment Channels**, environment-agnostic **Configurable Properties**, and governed **API Gateways**.

---

## 1. Enterprise Naming Standards

Maintain strict naming consistency to enable automated scripting, clear ownership, and rapid troubleshooting:

### A. Projects (The Unit of Packaging & RBAC)
Format: `[LAYER]_[Domain/Capability]_Project`

| Project Layer | Naming Format | Production Example |
| :--- | :--- | :--- |
| **Experience** | `EXP_[Domain]_Project` | `EXP_CustomerPortal_Project` |
| **Process** | `PROC_[Workflow]_Project` | `PROC_OrderToCash_Project` |
| **System** | `SYS_[Backend]_Project` | `SYS_FusionERP_Project` |
| **Shared** | `SHARED_[Capability]_Project` | `SHARED_ErrorHandling_Project` |

### B. Integrations (Inside Projects)
Format: `[SOURCE]_[TARGET]_[ENTITY]_[ACTION]_[PATTERN]_[VERSION]`

| Pattern | Suffix | Example |
| :--- | :--- | :--- |
| Synchronous REST API | `_SYNC_v1` | `PORTAL_ERP_CUSTOMER_QUERY_SYNC_v1` |
| Asynchronous / Event-Driven | `_ASYNC_v1` | `ERP_WMS_SHIPMENT_DISPATCH_ASYNC_v1` |
| Scheduled Batch File Feed | `_BATCH_v1` | `BANK_ERP_STATEMENT_IMPORT_BATCH_v1` |
| Event Mesh Subscriber | `_SUB_v1` | `EVENT_GL_JOURNAL_POST_SUB_v1` |

### C. Connections (Environment-Agnostic Rule)
> **The Golden Connection Rule**: Connection names must be **strictly identical across DEV, TEST, and PROD** environments. Never append environment suffixes (`_DEV`, `_PROD`) to Connection names. Only the *Connection Properties* (Host URL, credentials) change per environment!

- ✅ Correct: `ORACLE_ERP_CLOUD`, `SALESFORCE_CORE`, `CORP_BANK_SFTP`
- ❌ Prohibited: `ORACLE_ERP_CLOUD_DEV`, `ORACLE_ERP_CLOUD_PROD` (breaking automated CI/CD `.par` deployment)

### D. Gen 3 Events
Format: `[Entity]_[PastTenseAction]_Event`
- ✅ Correct: `Order_Placed_Event`, `Invoice_Approved_Event`, `Employee_Terminated_Event`
- ❌ Prohibited: `Create_Order_Event`, `Approve_Invoice_Event` (Events are facts, not commands)

---

## 2. Configuration Parameterization (Zero-Hardcoding Doctrine)

Gen 3 replaces legacy lookup table hacks with native **Configurable Properties**:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       PROJECT CONFIGURABLE PROPERTIES                       │
│  Defined at Project level; shared across all integrations within Project.   │
│  Examples:                                                                  │
│  ● email.notification.recipient  = "finance-ops@enterprise.com"            │
│  ● sftp.base.inbound.directory   = "/inbound/erp/orders"                    │
│  ● batch.processing.chunk.size   = 250                                      │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │ inherited by
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                     INTEGRATION CONFIGURABLE PROPERTIES                     │
│  Specific to an individual flow; can override project-level defaults.       │
│  Examples:                                                                  │
│  ● api.socket.timeout.seconds    = 15                                       │
│  ● retry.max.attempts            = 3                                        │
│  ● feature.flag.enable.enrichment = true                                    │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Governance Enforcement:
- **Zero Hardcoding**: Hardcoding IP addresses, hostnames, directory paths, email addresses, or API keys in mappers, assignments, or JavaScript is strictly prohibited.
- **Runtime Overrides**: Configurable properties can be updated dynamically at runtime without deactivating or modifying the integration flow.

---

## 3. Semantic API Versioning Strategy & Lifecycle

For all public-facing Experience layer APIs, enforce URI path versioning:

```
/ic/api/integration/v1/flows/rest/EXP_ORDER_FACADE/1.0/orders/{orderId}
                                                    ^^^
                                            OIC Flow Version
```

### Version Promotion Lifecycle:
```
┌──────────────┐      Breaking Change      ┌──────────────┐
│  v1.0 (Live) │ ────────────────────────► │  v2.0 (Live) │
│  Status: Act │   Deploy v2 alongside v1  │  Status: Act │
└──────────────┘                           └──────────────┘
       │                                          │
       │ Deprecation Window (60–90 days)          │
       │ Client consumers migrate to v2           │
       ▼                                          │
┌──────────────┐                                  │
│  v1.0 Sunset │ ◄────────────────────────────────┘
│  Deactivated │
└──────────────┘
```

### Breaking vs. Non-Breaking Change Rules:
| Change Type | Breaking? | Action Required |
| :--- | :--- | :--- |
| Adding an optional response field | No | Deploy minor update in-place (`v1.1`) |
| Adding an optional query parameter | No | Deploy minor update in-place (`v1.1`) |
| Renaming or removing a field | **YES** | Increment major version (`v2.0`); maintain `v1.0` during deprecation |
| Changing field data type (string -> int) | **YES** | Increment major version (`v2.0`) |
| Modifying HTTP method (GET -> POST) | **YES** | Increment major version (`v2.0`) |

---

## 4. OCI API Gateway Integration Architecture

External clients must never connect directly to OIC Experience layer endpoints. Front them with **OCI API Gateway**:

```
[External Consumer] ---> (HTTPS) ---> [OCI API Gateway]
                                             │
                       Policies Enforced:    │
                       • Rate Limiting (e.g. 200 req/min)
                       • Quota Control (100k req/day)
                       • OAuth 2.0 JWT Token Validation
                       • Web Application Firewall (WAF)
                       • CORS Validation
                                             │
                                             ▼ (Private VCN Peering)
                                 [OIC Gen 3 Experience API]
```

### Why API Gateway is Mandatory:
- **DoS / DDoS Protection**: API Gateway throttles abusive clients before requests hit OIC, preserving your Oracle Processing Unit (OPU) allocation.
- **Contract Decoupling**: API Gateway provides clean, vanity public URLs (`https://api.enterprise.com/v1/orders`) abstracted from internal OIC endpoint syntax.

---

## 5. Automated CI/CD Lifecycle via OIC Gen 3 REST APIs

Promote integration packages across environments using the **Project Archive (`.par`)** standard:

```
  [DEV Environment]
         │
         │ 1. Export Project Archive (.par)
         ▼
  [Git Repository] (GitHub / GitLab / OCI DevOps)
         │ Tag: release-v1.4.0
         │
         │ 2. Automated Jenkins / GitHub Actions Pipeline
         ▼
  [TEST Environment] ── Apply TEST Deployment Profile ──► Run Integration Tests
         │
         │ 3. Automated Approval Gate
         ▼
  [PROD Environment] ── Apply PROD Deployment Profile ──► Activate Project
```

### Key OIC Gen 3 REST API Automation Endpoints:
- **Export Project**: `POST /ic/api/integration/v1/projects/{id}/archive`
- **Import Project**: `POST /ic/api/integration/v1/projects/archive` (multipart/form-data)
- **Deploy Project**: `POST /ic/api/integration/v1/projects/{id}/deployments`
- **Activate Project**: `POST /ic/api/integration/v1/projects/{id}/deployments/{depId}/activate`
