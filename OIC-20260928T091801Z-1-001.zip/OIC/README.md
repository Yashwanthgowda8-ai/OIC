# Oracle Integration Cloud Gen 3 (OIC Gen 3) Enterprise Architecture Repository

This repository hosts the **Master Architecture Standard** for Oracle Integration Cloud Gen 3 (OIC Gen 3), synthesized from extensive research, production experience, and cross-model architectural comparisons (Gemini, Claude Opus, and GPT).

---

## 🌟 The Master Architecture Standard (`master/`)

The definitive, production-proven blueprint for enterprise integrations built on OIC Gen 3.

👉 **Start here**: [**Master Architecture Blueprint (`master/SKILL.md`)**](./master/SKILL.md) | [**Master Navigation Guide (`master/README.md`)**](./master/README.md)

### The 9 Reference Manuals in `master/references/`:
1. [**01. Enterprise Architectural Patterns**](./master/references/01-enterprise-architectural-patterns.md): 3-Layer API-Led Fabric (`EXP_`, `PROC_`, `SYS_`, `SHARED_`) and 6 core integration blueprints.
2. [**02. Anti-Patterns & Remediation Catalog**](./master/references/02-anti-patterns-and-remediation.md): 12 production integration anti-patterns with JVM heap math and architectural fixes.
3. [**03. Distributed Sagas & Compensation**](./master/references/03-distributed-sagas-and-compensation.md): Orchestration saga blueprint, compensation decision matrix, and ATP state persistence DDL.
4. [**04. Enterprise Fault Handling & Resilience**](./master/references/04-enterprise-fault-handling-and-resilience.md): 3-tier fault architecture, backoff with jitter, RFC 7807 specs, and DLQ replay schema.
5. [**05. Performance, Memory & Platform Limits**](./master/references/05-performance-memory-and-platform-limits.md): Platform limits matrix, XSLT keys indexing, ES6+ JS libraries, and Private Endpoints.
6. [**06. Observability, Alarms & Runbooks**](./master/references/06-observability-alarms-and-runbooks.md): Full OCI Observability stack wiring, correlation ID propagation, and 4 operational runbooks.
7. [**07. Governance, CI/CD & API Management**](./master/references/07-governance-cicd-and-api-management.md): Project `.par` packaging, Configurable Properties, API Gateway, and REST CI/CD.
8. [**08. AI-Augmented Integration & MCP**](./master/references/08-ai-augmented-integration-and-agentic-tools.md): Native Document Understanding action, AI mapping suggestions, and Agentic AI tools.
9. [**09. Definitive Go-Live Checklist (35-Point)**](./master/references/09-master-production-hardening-checklist.md): 35-point verification covering architecture, resilience, security, and ops.

---

## 📁 Repository Directory Structure

```text
OIC/
├── master/                                      # ★ THE MASTER ARCHITECTURE STANDARD ★
│   ├── SKILL.md                                 # Unified Master Skill (Antigravity ready)
│   ├── README.md                                # Master executive index and navigation
│   └── references/                              # 9 Comprehensive Reference Manuals
│       ├── 01-enterprise-architectural-patterns.md
│       ├── 02-anti-patterns-and-remediation.md
│       ├── 03-distributed-sagas-and-compensation.md
│       ├── 04-enterprise-fault-handling-and-resilience.md
│       ├── 05-performance-memory-and-platform-limits.md
│       ├── 06-observability-alarms-and-runbooks.md
│       ├── 07-governance-cicd-and-api-management.md
│       ├── 08-ai-augmented-integration-and-agentic-tools.md
│       └── 09-master-production-hardening-checklist.md
│
├── .agents/skills/oic-gen3-master-architect/    # Workspace-discoverable Antigravity skill
│
├── gemini/                                      # Gemini's OIC Gen 3 Architectural Perspective
│   ├── SKILL.md                                 # Pattern catalog: Sync, Async, FBDI, Event Mesh
│   ├── README.md                                # Gemini summary & quick reference
│   └── references/                              # 5 reference manuals
│
├── opus/                                        # Claude Opus's OIC Gen 3 Architectural Perspective
│   ├── SKILL.md                                 # Anti-patterns, Sagas, API-led, AI, Observability
│   ├── README.md                                # Opus summary & differentiation comparison
│   └── references/                              # 5 reference manuals
│
├── gpt/                                         # GPT's Synthesized OIC Gen 3 Skill
│   └── .agents/skills/oic-gen3-expert/SKILL.md  # Single-file expert reference
│
└── README.md                                    # This index
```

---

## 🔍 Multi-Model Synthesis & Benchmark Matrix

| Dimension | Gemini Perspective | Opus Perspective | GPT Synthesis | 🌟 Master Standard |
| :--- | :--- | :--- | :--- | :--- |
| **Skill Name** | `oic-architecture-expert` | `oic-gen3-mastery` | `oic-gen3-expert` | **`oic-gen3-master-architect`** |
| **Architectural Focus** | Pattern catalog & platform limits | Anti-patterns & distributed sagas | Condensed reference | **Complete 3-Layer API-Led Fabric + All Patterns** |
| **Anti-Patterns** | Mentioned in guardrails | 12 cataloged items | 5-item cheat sheet | **12-Item Catalog with JVM Heap Math & Fixes** |
| **Distributed Transactions** | Not explicitly covered | Orchestration saga blueprint | Text diagram | **Full Saga Blueprint + ATP Persistence DDL + Recovery Flow** |
| **Fault Resilience** | 3-tier fault + RFC 7807 | Mentioned in checklist | Summary rules | **3-Tier Fault + Backoff with Jitter + DLQ Replay Schema** |
| **Observability** | Tracking IDs & Audit levels | OCI stack + 4 runbooks | Runbook overview | **Full OCI Stack Wiring + Alarms + 4 Production Runbooks** |
| **AI Augmentation** | Not covered | Covered in SKILL | Highlighted | **Dedicated Manual: Doc Understanding, Mapping, Agentic MCP** |
| **API Management** | Naming conventions | API-led & API Gateway | Prefix mapping | **Semantic URI Versioning + OCI API Gateway Architecture** |
| **Checklist Depth** | 25 points | 30 points | 30 points | **35-Point Definitive Go-Live Checklist** |
