# Oracle Integration Cloud (OIC Gen 3) Master Architecture Standard

> **The Definitive, Industry-Grade Architectural Standard for Oracle Integration Cloud Gen 3 (OIC Gen 3)**  
> Synthesizing enterprise patterns, anti-pattern remediation, distributed saga compensation, resilience frameworks, OCI observability, and AI-augmented tools.

---

## 🏛️ Executive Summary

This Master Standard represents the synthesized apex of enterprise integration architecture for OIC Gen 3. It unifies:
1. **API-Led 3-Layer Fabric** (`EXP_`, `PROC_`, `SYS_`, `SHARED_`) mapped natively to OIC Gen 3 Projects.
2. **6 Core Enterprise Integration Blueprints** (Sync REST, Sync Facade + Event Worker, Native Event Mesh, Scheduled Batch Streaming, Oracle Fusion FBDI, and Parallel Actions).
3. **12-Point Anti-Pattern Catalog** analyzing JVM heap memory mechanics, state snapshot explosion, and concrete architectural remedies.
4. **Distributed Saga & Compensation Framework** for cross-system distributed transactions with reverse-order compensation, idempotency keys, and Autonomous DB state persistence.
5. **3-Tier Fault Architecture & Canonical RFC 7807** Problem Details standard.
6. **Full OCI Observability Stack Wiring** (Logging, Logging Analytics, Alarms, Notifications, OIC Insight) and 4 step-by-step incident response runbooks.
7. **Native AI Integration & Agentic Tools** (Document Understanding, AI Mapping Suggestions, and MCP tool endpoints for autonomous LLMs).
8. **35-Point Production Hardening Checklist** for pre-go-live verification.

---

## 📁 Master Architecture Directory Structure

```text
master/
├── SKILL.md                                           # Master Skill Document (Antigravity-ready)
├── README.md                                          # Executive Overview & Architecture Index
└── references/                                        # 9 Deep-Dive Reference Manuals
    ├── 01-enterprise-architectural-patterns.md        # 3-layer topology & 6 core flow blueprints
    ├── 02-anti-patterns-and-remediation.md            # 12 production anti-patterns & JVM math
    ├── 03-distributed-sagas-and-compensation.md       # Distributed transaction orchestrations & DDL
    ├── 04-enterprise-fault-handling-and-resilience.md # 3-tier fault architecture & RFC 7807
    ├── 05-performance-memory-and-platform-limits.md   # Platform limits matrix, XSLT keys, JS libs
    ├── 06-observability-alarms-and-runbooks.md        # OCI stack wiring, alarms & 4 incident runbooks
    ├── 07-governance-cicd-and-api-management.md       # Project .par lifecycle, Configurable Props
    ├── 08-ai-augmented-integration-and-agentic-tools.md # AI Doc Understanding, Mapping & MCP
    └── 09-master-production-hardening-checklist.md    # 35-point enterprise go-live checklist
```

---

## ⚡ Quick Reference Architecture Doctrine

### 1. The Core Golden Rules
- **Encapsulate Everything in Projects**: Never deploy loose or unassigned integrations.
- **Enforce the 3-Layer Rule**: Experience APIs shape and protect; Process orchestrates business sagas; System adapts backends atomically.
- **Never Use "Read Entire File"**: Stream files of variable or large size using `Stage File: Read File in Segments` (100–500 records/segment).
- **Compensate, Don't Rollback**: For multi-system flows, track step state with boolean variables and reverse-compensate in the Global Fault Handler.
- **Idempotency Everywhere**: Propagate `Idempotency-Key` headers on all downstream invocations.
- **Classify Before Retrying**: Transient errors (429, 502, 503, 504) get exponential backoff with jitter; non-transient errors (400, 422) fail fast to the DLQ.
- **Zero Hardcoding**: Use Project and Integration Configurable Properties for all URLs, directories, emails, and thresholds.
- **Observe End-to-End**: Propagate `X-Correlation-Id` across all hops and wire Activity Stream logs to OCI Logging Analytics.

---

## 📚 Deep-Dive Reference Manuals Navigation

| Manual | Primary Topics Covered |
| :--- | :--- |
| [01. Enterprise Architectural Patterns](./references/01-enterprise-architectural-patterns.md) | 3-layer API-led fabric, 6 integration blueprints with ASCII flow diagrams. |
| [02. Anti-Patterns & Remediation Catalog](./references/02-anti-patterns-and-remediation.md) | Chatty loops, sync chains, God flows, DOM heap expansion math, and fixes. |
| [03. Distributed Sagas & Compensation](./references/03-distributed-sagas-and-compensation.md) | Forward execution, reverse compensation, decision matrix, ATP state DDL. |
| [04. Enterprise Fault Handling & Resilience](./references/04-enterprise-fault-handling-and-resilience.md) | 3-tier fault architecture, backoff with jitter, RFC 7807 problem details, DLQ schema. |
| [05. Performance, Memory & Platform Limits](./references/05-performance-memory-and-platform-limits.md) | Hard limits matrix, XSLT keys indexing, ES6+ JS libraries, Private Endpoints. |
| [06. Observability, Alarms & Runbooks](./references/06-observability-alarms-and-runbooks.md) | OCI Logging Analytics wiring, alarm thresholds, correlation ID, 4 runbooks. |
| [07. Governance, CI/CD & API Management](./references/07-governance-cicd-and-api-management.md) | Project `.par` packaging, Configurable Properties, API Gateway, REST CI/CD. |
| [08. AI-Augmented Integration & MCP](./references/08-ai-augmented-integration-and-agentic-tools.md) | Document Understanding, AI mapping suggestions, Agentic AI (MCP) tools. |
| [09. Production Hardening Checklist](./references/09-master-production-hardening-checklist.md) | The definitive 35-point go-live checklist covering all architectural tiers. |
