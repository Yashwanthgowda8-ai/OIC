---
name: oic-gen3-expert
description: >-
  Independent research‑driven OIC Gen 3 expertise skill. Provides a concise yet premium guide covering architecture, anti‑patterns, saga compensation, API‑led design, observability, AI‑augmented development, security, and a production‑readiness checklist. Tailored for developers seeking a self‑contained reference without relying on prior model outputs.
---

# OIC Gen 3 Expert Skill – GPT OSS 120B

> **Goal**: Deliver a high‑impact, premium‑look reference that can be used directly in Antigravity IDE as a reusable skill. The skill is fully self‑contained – all research and recommendations are synthesized here.

---

## 1️⃣ Architecture Overview – 3‑Layer API‑Led Fabric

| Layer | Prefix | Purpose | Typical Artifacts |
| :--- | :--- | :--- | :--- |
| **Experience** | `EXP_` | Consumer‑facing, thin facades. Shape data for UI, mobile, partner APIs. | REST endpoints, response mappers, rate limiting via OCI API Gateway |
| **Process** | `PROC_` | Business orchestration, saga coordination, event publishing. | Integration flows, event schema definitions, compensation logic |
| **System** | `SYS_` | Backend adapters – pure CRUD/lookup against ERP, CRM, DB, SFTP, etc. | Connectors, pagination helpers, idempotent invoke wrappers |
| **Shared** | `SHARED_` | Cross‑cutting concerns (error handling, notifications, audit). | DLQ processors, notification dispatchers, audit log integrations |

> **Design Rule**: **Never** let an Experience integration call a System connector directly – always route through a Process project.

---

## 2️⃣ Core Patterns & Anti‑Patterns

### ✅ Recommended Patterns
- **Sync Facade + Async Worker** – Immediate `202 Accepted`, publish an event, background Process handles the heavy lifting.
- **Event Mesh Pub/Sub** – Loose coupling, fan‑out to multiple Process projects.
- **Batch / Bulk API** – Replace chatty loops with bulk endpoints or staged file uploads.
- **Parallel Action** – Execute independent calls concurrently to reduce wall‑clock time.

### ❌ Anti‑Patterns (quick cheat‑sheet)
1. **Chatty Loop** – N+1 API calls inside a `For‑Each`. Fix: batch or segment.
2. **Monolithic God Flow** – >50 actions, multiple backends. Fix: decompose into child integrations.
3. **Unbounded `Read Entire File`** – OOM risk. Fix: `Read File in Segments`.
4. **Global Variable Mutation in Loops** – Snapshots explode memory. Fix: use scope variables or Stage File.
5. **Empty Global Fault Handler** – Silent failures. Fix: always log, clean, alert, return RFC 7807.

---

## 3️⃣ Distributed Transactions – Saga & Compensation

### Blueprint (text diagram)
```
[Client Request] → Publish **Order_Placed_Event** (sync façade) → 202

[PROC_OrderSaga] (Process project) – orchestrates:
  1️⃣ Reserve Inventory  (WMS)  → set v_inventory=true
  2️⃣ Charge Payment    (Payment) → set v_payment=true
  3️⃣ Create ERP Order  (ERP)   → set v_erp=true

If any step faults → Global Fault Handler runs compensation in reverse order:
  • If v_payment → Refund API (idempotent)
  • If v_inventory → Release Inventory
  • If v_erp → Cancel ERP Order (if supported)
```

#### Idempotency Header
```
Idempotency-Key: OIC-SAGA-{correlationId}-STEP-{stepNumber}
```
All downstream calls must honor this header.

#### State Persistence (ATP table)
```sql
CREATE TABLE OIC_SAGA_STATE (
  SAGA_ID VARCHAR2(100) PRIMARY KEY,
  CORR_ID VARCHAR2(100) NOT NULL,
  CURRENT_STEP VARCHAR2(30),
  STATUS VARCHAR2(20) DEFAULT 'IN_PROGRESS',
  INV_RESERVED CHAR(1) DEFAULT 'N',
  PAYMENT_CHARGED CHAR(1) DEFAULT 'N',
  ERP_CREATED CHAR(1) DEFAULT 'N',
  CREATED_AT TIMESTAMP DEFAULT SYSTIMESTAMP,
  UPDATED_AT TIMESTAMP
);
```
Use this table for long‑running sagas (> 1 hour) and recovery jobs.

---

## 4️⃣ Observability & Operational Runbooks

### OCI Stack Wiring
1. **Enable Activity Stream** → OCI Logging → Logging Analytics.
2. **Create Alarms** for error‑rate > 5 %, latency P99 > 10 s, and agent health.
3. **Notifications** → Slack / Teams / PagerDuty via OCI Notification topics.
4. **Insight Models** – Business KPIs (order‑to‑cash cycle time, stuck‑at‑payment count).
5. **Correlation ID** – Propagate `X‑Correlation‑Id` across all layers; use it for log searches.

### Sample Runbook – Critical Integration Failure (P1)
1. **Acknowledge** alarm, open OIC Monitoring – filter failed instances.
2. **Identify** the faulty scope (system call, mapper, stage file).
3. **Classify** error: transient (429/502/504) → wait/retry; non‑transient (400/401) → fix payload or contract.
4. **Compensate** if needed (invoke saga rollback).
5. **Verify** with a test request; monitor for 30 min.
6. **Close** ticket with root‑cause summary.

---

## 5️⃣ AI‑Augmented Development
- **Document Understanding Action** – drag‑and‑drop to extract key‑value data from invoices.
- **AI Mapping Suggestions** – OIC now suggests field mappings when you open a mapper.
- **AI Assistant** – natural‑language project creation (e.g., *“Create a PO‑to‑Invoice integration using the ERP system.”*).
- **MCP Agentic Tools** – expose integrations as callable LLM tools for autonomous workflows.

---

## 6️⃣ Security & Governance
- **OAuth 2.0** inbound for all Experience APIs.
- **OCI Vault** stores all secrets; never hard‑code credentials.
- **P‑II Masking** – enable field‑level masking in OIC tracking configuration.
- **Private Endpoints** for ATP and OCI services; on‑prem agents in HA mode (heap ‑Xmx4g).

---

## 7️⃣ Production Hardening Checklist (30 points)
> A concise checklist derived from the full reference – tick each item before go‑live.

### Architecture & Decomposition (6)
- [ ] All integrations belong to a **named Project** (EXP_/PROC_/SYS_/SHARED_).
- [ ] Strict **3‑layer separation** (no direct backend calls from Experience).
- [ ] No **God Integration** – each flow ≤ 30 actions, single system per integration.
- [ ] **Child integration decomposition** for complex orchestrations.
- [ ] **Event‑driven decoupling** – all async fan‑out uses Event Mesh.
- [ ] **Sync latency guardrail** – synchronous APIs ≤ 3 s.

### Anti‑Pattern Elimination (6)
- [ ] No **Chatty Loops** – batch or segment.
- [ ] No **Unbounded file reads** – always segment.
- [ ] No **Global variable mutation in loops**.
- [ ] No **String concatenation accumulation**.
- [ ] No **Hard‑coded env values** – use Configurable Properties.
- [ ] No **Empty Global Fault Handlers**.

### Error Handling & Resilience (6)
- [ ] Scope‑level fault handlers with retry/backoff.
- [ ] Transient vs non‑transient classification.
- [ ] RFC 7807 error responses for sync APIs.
- [ ] DLQ + replay integration.
- [ ] Saga compensation logic for all multi‑system flows.
- [ ] Idempotency keys on every external call.

### Security & Network (4)
- [ ] OAuth 2.0 inbound authentication.
- [ ] P‑II masking & audit level set to **Normal** in prod.
- [ ] Secrets stored in **OCI Vault** only.
- [ ] Private endpoints & HA connectivity agents.

### Observability (5)
- [ ] Business tracking identifiers populated (primary, secondary 1, secondary 2).
- [ ] Correlation ID propagation everywhere.
- [ ] Activity Stream → Logging Analytics enabled.
- [ ] Monitoring alarms for error‑rate, latency, agent health.
- [ ] Notifications wired to Slack/Teams/PagerDuty.

### Governance & Ops (3)
- [ ] `.par` project archived in Git with semantic tags.
- [ ] Deployment Profiles for DEV/TEST/PROD with property mapping.
- [ ] Runbooks documented for critical integrations (linked from notifications).

---

## 📚 References (internal copies)
- `anti-patterns-catalog.md`
- `saga-compensation-patterns.md`
- `api-led-topology.md`
- `observability-and-runbooks.md`
- `production-hardening-checklist.md`

---

*End of Skill*
